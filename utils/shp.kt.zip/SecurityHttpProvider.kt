package br.com.portoseguro.usersecurity.auth.security

import br.com.portoseguro.superapp.core.infrastructure.interceptors.AppInterceptor
import br.com.portoseguro.superapp.core.infrastructure.interceptors.LogInterceptor
import br.com.portoseguro.superapp.core.infrastructure.interceptors.NoConnectionInterceptor
import br.com.portoseguro.superapp.core.infrastructure.interceptors.TimeoutInterceptor
import br.com.portoseguro.superapp.core.repository.BaseWebService
import br.com.portoseguro.usersecurity.auth.security.certificate.Certificates
import br.com.portoseguro.usersecurity.auth.security.certificate.find.FindCertificate
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import org.koin.core.component.KoinComponent
import org.koin.core.component.get
import java.security.KeyStore
import java.security.KeyStoreException
import java.security.NoSuchAlgorithmException
import java.util.concurrent.TimeUnit
import javax.net.ssl.SSLContext
import javax.net.ssl.TrustManagerFactory
import javax.net.ssl.X509TrustManager
import br.com.portoseguro.superapp.core.log.Log as LogApp

object SecurityHttpProvider : KoinComponent {

    @Volatile
    private var INSTANCE: OkHttpClient? = null

    private const val PROTOCOL = "TLS"
    private const val DEBUG = "debug"
    private const val QA = "qa"
    private const val DEV = "dev"

    fun getInstance(): OkHttpClient {
        val baseWebService: BaseWebService = get()
        val noConnectionInterceptor: NoConnectionInterceptor = get()
        val sessionExpiredInterceptor: SessionExpiredInterceptor = get()
        val appInterceptor: AppInterceptor = get()
        val securityInterceptor =
            SecurityInterceptor(
                baseWebService.securityAPIKey,
                get(),
                get()
            )
        val logInterceptor: LogInterceptor = get()
        val timeoutInterceptor: TimeoutInterceptor = get()

        if (INSTANCE != null) {
            return INSTANCE as OkHttpClient
        }

        val trustManagerFactory = getTrustManageFactory()
        val contextSSLContext: SSLContext = SSLContext.getInstance(PROTOCOL).apply {
            init(null, trustManagerFactory.trustManagers, null)
        }

        synchronized(this) {
            val okHttpClient = OkHttpClient.Builder()
                .addInterceptor(noConnectionInterceptor)
                .addInterceptor(appInterceptor)
                .addInterceptor(sessionExpiredInterceptor)
                .addInterceptor(securityInterceptor)
                .addInterceptor(logInterceptor)
                .addInterceptor(timeoutInterceptor)
                .connectTimeout(baseWebService.connectTimeout, TimeUnit.MILLISECONDS)
                .readTimeout(baseWebService.readTimeout, TimeUnit.MILLISECONDS)
                .writeTimeout(baseWebService.writeTimeout, TimeUnit.MILLISECONDS)

            if (baseWebService.buildType != DEBUG && baseWebService.buildType != QA) {
                okHttpClient.sslSocketFactory(
                    contextSSLContext.socketFactory,
                    trustManagerFactory.trustManagers[0] as X509TrustManager
                )
            }

            if (baseWebService.buildType == DEBUG || baseWebService.buildType == DEV) {
                val loggingInterceptor: HttpLoggingInterceptor = get()
                loggingInterceptor.level = HttpLoggingInterceptor.Level.BODY
                okHttpClient.addInterceptor(loggingInterceptor)
            }

            INSTANCE = okHttpClient.build()
            return INSTANCE as OkHttpClient
        }
    }

    private fun getTrustManageFactory(): TrustManagerFactory {
        val keyStoreType = KeyStore.getDefaultType()
        val tmfAlgorithm: String = TrustManagerFactory.getDefaultAlgorithm()
        val exception: Exception
        try {
            val keyStore = KeyStore.getInstance(keyStoreType).apply {
                load(null, null)
                loadCertificates()
            }

            return TrustManagerFactory.getInstance(tmfAlgorithm).apply {
                init(keyStore)
            }
        } catch (e: KeyStoreException) {
            logError(e)
            exception = e
        } catch (e: NoSuchAlgorithmException) {
            logError(e)
            exception = e
        } catch (e: NullPointerException) {
            logError(e)
            exception = e
        }

        throw exception
    }

    private fun KeyStore.loadCertificates() {
        val findCertificate: FindCertificate = get()

        Certificates.values().forEach { data ->
            val certificate = findCertificate.getCertificate(data.fileName)
            setCertificateEntry(data.alias, certificate)
        }
    }

    private fun logError(e: Exception) {
        val log: LogApp = get()
        log.logCaughtEx(e)
    }
}
