package br.com.portoseguro.banking.router

import android.content.Context
import android.content.Intent
import br.com.portoseguro.banking.presentation.subhome.help.BankingSubHomeHelpActivity
import br.com.portoseguro.superapp.router.banking.BankingHelpRouter

open class BankingHelpRouterImpl : BankingHelpRouter {

    override fun getSubHomeHelpIntent(context: Context): Intent {
         return BankingSubHomeHelpActivity.getLaunchIntent(context)
    }

}