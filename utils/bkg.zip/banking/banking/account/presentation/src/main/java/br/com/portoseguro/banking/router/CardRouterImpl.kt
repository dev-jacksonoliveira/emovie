package br.com.portoseguro.banking.router

import android.content.Context
import android.content.Intent
import br.com.portoseguro.banking.presentation.card.requestnewcard.RequestNewCardActivity
import br.com.portoseguro.banking.presentation.subhome.cards.SubHomeCardsActivity
import br.com.portoseguro.superapp.router.banking.CardRouter

class CardRouterImpl : CardRouter {
    override fun getRequestCreateCard(context: Context): Intent {
        return RequestNewCardActivity.getLaunchIntent(context, true)
    }

    override fun getSubHomeCardIntent(context: Context): Intent {
         return SubHomeCardsActivity.getLaunchIntent(context)
    }

    override fun getRequestNewCardIntent(context: Context): Intent {
        return RequestNewCardActivity.getLaunchIntent(context, false)
    }
}