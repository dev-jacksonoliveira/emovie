package br.com.portoseguro.banking.di

import android.content.Context
import br.com.portoseguro.banking.BarcodeScannerViewModel
import br.com.portoseguro.banking.business.embeddedtoken.ObligatoryBiometryBankingBusiness
import br.com.portoseguro.banking.business.incentive.CardIncentiveBusiness
import br.com.portoseguro.banking.business.onboard.AnalyzeProductBusiness
import br.com.portoseguro.banking.business.onboard.CreateUserBusiness
import br.com.portoseguro.banking.business.onboard.DigitalAccountBusiness
import br.com.portoseguro.banking.business.onboard.MyRegistrationHomeBusiness
import br.com.portoseguro.banking.business.onboard.MyRegistrationHomeBusinessImpl
import br.com.portoseguro.banking.business.onboard.OfferProductBusiness
import br.com.portoseguro.banking.business.onboard.OnBoardTermsBusiness
import br.com.portoseguro.banking.business.password.AccountPasswordBusiness
import br.com.portoseguro.banking.business.password.AccountPasswordBusinessImpl
import br.com.portoseguro.banking.data.api.BankingAPI
import br.com.portoseguro.banking.data.enums.AccountFeatureToggleKeys
import br.com.portoseguro.banking.data.enums.CardDefinitiveBlockReasonType
import br.com.portoseguro.banking.data.local.LocalBankingProduct
import br.com.portoseguro.banking.data.local.LocalBankingProductImpl
import br.com.portoseguro.banking.data.local.LocalBankingProductImpl.Companion.PORTO_BANKING_PASS_LIST
import br.com.portoseguro.banking.data.local.SummaryShortcutsGenerate
import br.com.portoseguro.banking.data.local.shortcut.AccountShortcutAvailabilityImpl
import br.com.portoseguro.banking.data.local.shortcut.CardShortcutAvailabilityImpl
import br.com.portoseguro.banking.data.local.shortcut.ProvideAccountShortcuts
import br.com.portoseguro.banking.data.local.shortcut.ProvideCardShortcuts
import br.com.portoseguro.banking.data.mapper.AccountSummaryMapper
import br.com.portoseguro.banking.data.mapper.AddressDeliveryMapper
import br.com.portoseguro.banking.data.mapper.CardMapper
import br.com.portoseguro.banking.data.mapper.SummaryShortcutMapper
import br.com.portoseguro.banking.data.mapper.password.AccountPasswordMapper
import br.com.portoseguro.banking.data.mapper.password.AccountPasswordMapperImpl
import br.com.portoseguro.banking.data.mapper.registration.home.MyRegistrationAddressMapper
import br.com.portoseguro.banking.data.mapper.registration.home.MyRegistrationAddressMapperImpl
import br.com.portoseguro.banking.data.mapper.registration.home.MyRegistrationHomeMapper
import br.com.portoseguro.banking.data.mapper.registration.home.MyRegistrationHomeMapperImpl
import br.com.portoseguro.banking.data.mapper.shortcut.AccountShortcutFeatureToggleKeyMapper
import br.com.portoseguro.banking.data.mapper.shortcut.AccountShortcutFeatureToggleKeyMapper.Companion.CASH_OUT
import br.com.portoseguro.banking.data.mapper.shortcut.AccountShortcutFeatureToggleKeyMapper.Companion.DEBIT_CARD
import br.com.portoseguro.banking.data.mapper.shortcut.AccountShortcutFeatureToggleKeyMapper.Companion.EXTRACT
import br.com.portoseguro.banking.data.mapper.shortcut.AccountShortcutFeatureToggleKeyMapper.Companion.HELP
import br.com.portoseguro.banking.data.mapper.shortcut.AccountShortcutFeatureToggleKeyMapper.Companion.MY_REGISTRATION_DATA
import br.com.portoseguro.banking.data.mapper.shortcut.AccountShortcutFeatureToggleKeyMapper.Companion.PAY_BILL
import br.com.portoseguro.banking.data.mapper.shortcut.AccountShortcutFeatureToggleKeyMapper.Companion.PIX
import br.com.portoseguro.banking.data.mapper.shortcut.AccountShortcutFeatureToggleKeyMapper.Companion.SECURITY_ACCOUNT
import br.com.portoseguro.banking.data.mapper.shortcut.AccountShortcutFeatureToggleKeyMapper.Companion.SHOW_PASSWORD
import br.com.portoseguro.banking.data.mapper.shortcut.AccountShortcutFeatureToggleKeyMapper.Companion.TARIFFS
import br.com.portoseguro.banking.data.mapper.shortcut.CardShortcutFeatureToggleMapper
import br.com.portoseguro.banking.data.mapper.shortcut.CardShortcutFeatureToggleMapper.Companion.CARD_CHECK_OR_CHANGE_PASSWORD
import br.com.portoseguro.banking.data.mapper.shortcut.CardShortcutFeatureToggleMapper.Companion.CARD_EXTRACT
import br.com.portoseguro.banking.data.mapper.shortcut.CardShortcutFeatureToggleMapper.Companion.CARD_HELP
import br.com.portoseguro.banking.data.mapper.shortcut.CardShortcutFeatureToggleMapper.Companion.LOCK_UNLOCK
import br.com.portoseguro.banking.data.mapper.shortcut.CardShortcutFeatureToggleMapper.Companion.REQUEST_NEW_CARD
import br.com.portoseguro.banking.data.repository.AccountShortcutRepositoryImpl
import br.com.portoseguro.banking.data.repository.AccountStatusRepository
import br.com.portoseguro.banking.data.repository.CardShortcutRepositoryImpl
import br.com.portoseguro.banking.data.repository.CardsRepositoryImpl
import br.com.portoseguro.banking.data.repository.InvoicePaymentRepositoryImpl
import br.com.portoseguro.banking.data.repository.InvoiceRepositoryImpl
import br.com.portoseguro.banking.data.repository.MyRegistrationHomeRepositoryImpl
import br.com.portoseguro.banking.data.repository.OnboardRepository
import br.com.portoseguro.banking.data.repository.SummaryRepositoryImpl
import br.com.portoseguro.banking.data.repository.password.AccountPasswordRepository
import br.com.portoseguro.banking.data.repository.password.AccountPasswordRepositoryImpl
import br.com.portoseguro.banking.presentation.card.NotificationCardFlow
import br.com.portoseguro.banking.presentation.card.block.definitive.CardDefinitiveBlockViewModel
import br.com.portoseguro.banking.presentation.card.block.definitive.navigation.CardDefinitiveBlockNavViewModel
import br.com.portoseguro.banking.presentation.card.block.definitive.reason.CardDefinitiveBlockReasonViewModel
import br.com.portoseguro.banking.presentation.card.block.definitive.reason.mapper.CardDefinitiveBlockReasonMapper
import br.com.portoseguro.banking.presentation.card.block.definitive.reason.mapper.CardDefinitiveBlockReasonMapperImpl
import br.com.portoseguro.banking.presentation.card.lock_unlock.LockUnlockViewModel
import br.com.portoseguro.banking.presentation.card.lock_unlock.resource.CardLockUnlockResourceProvider
import br.com.portoseguro.banking.presentation.card.lock_unlock.resource.CardLockUnlockResourceProviderImpl
import br.com.portoseguro.banking.presentation.card.navigation.CardSubHomeNavigation
import br.com.portoseguro.banking.presentation.card.navigation.CardSubHomeNavigationImpl
import br.com.portoseguro.banking.presentation.card.navigation.LockUnlockCardNavigation
import br.com.portoseguro.banking.presentation.card.navigation.LockUnlockCardNavigationImpl
import br.com.portoseguro.banking.presentation.card.requestnewcard.RequestNewCardMessagesViewModel
import br.com.portoseguro.banking.presentation.card.requestnewcard.form.RequestNewCardFormViewModel
import br.com.portoseguro.banking.presentation.card.requestnewcard.form.field.ChainFieldViewModel
import br.com.portoseguro.banking.presentation.card.requestnewcard.form.field.ChainInputFieldValidator
import br.com.portoseguro.banking.presentation.card.requestnewcard.form.field.ChainInputFieldValidatorImpl
import br.com.portoseguro.banking.presentation.card.requestnewcard.form.mapper.RequestNewCardFormMapper
import br.com.portoseguro.banking.presentation.card.requestnewcard.form.mapper.RequestNewCardFormMapperImpl
import br.com.portoseguro.banking.presentation.card.requestnewcard.form.resource.RequestNewCardResourceProvider
import br.com.portoseguro.banking.presentation.card.requestnewcard.form.resource.RequestNewCardResourceProviderImpl
import br.com.portoseguro.banking.presentation.card.requestnewcard.form.resource.RequestNewCardTitleResourceProvider
import br.com.portoseguro.banking.presentation.card.requestnewcard.form.resource.RequestNewCardTitleResourceProviderImpl
import br.com.portoseguro.banking.presentation.card.requestnewcard.navigation.RequestNewCardNavViewModel
import br.com.portoseguro.banking.presentation.card.unlock.onboarding.OnboardingNavViewModel
import br.com.portoseguro.banking.presentation.card.unlock.onboarding.SearchCardOrNotViewModel
import br.com.portoseguro.banking.presentation.card.unlock.securitycode.ConfirmSecurityCodeResourceProvider
import br.com.portoseguro.banking.presentation.card.unlock.securitycode.ConfirmSecurityCodeResourceProviderImpl
import br.com.portoseguro.banking.presentation.card.unlock.securitycode.ConfirmSecurityCodeViewModel
import br.com.portoseguro.banking.presentation.entry.EntryViewModel
import br.com.portoseguro.banking.presentation.onboard.createaccount.CreateAccountViewModel
import br.com.portoseguro.banking.presentation.onboard.createaccount.view.TermsLinkSpannable
import br.com.portoseguro.banking.presentation.onboard.home.MyRegistrationHomeViewModel
import br.com.portoseguro.banking.presentation.onboard.home.navigation.redirect.MyRegistrationHomeRedirect
import br.com.portoseguro.banking.presentation.onboard.home.navigation.redirect.MyRegistrationHomeRedirectImpl
import br.com.portoseguro.banking.presentation.onboard.navigation.OnboardNavigation
import br.com.portoseguro.banking.presentation.onboard.navigation.OnboardNavigationImpl
import br.com.portoseguro.banking.presentation.onboard.navigation.params.OnboardCameraParams
import br.com.portoseguro.banking.presentation.onboard.navigation.params.OnboardCameraParamsImpl
import br.com.portoseguro.banking.presentation.onboard.password.confirmation.PasswordConfirmationViewModel
import br.com.portoseguro.banking.presentation.password.biometry.AccountPasswordBiometryViewModel
import br.com.portoseguro.banking.presentation.password.show.AccountShowPasswordViewModel
import br.com.portoseguro.banking.presentation.registration.edit.MyRegistrationEditViewModel
import br.com.portoseguro.banking.presentation.registration.edit.navigation.MyRegistrationEditActivityNavigation
import br.com.portoseguro.banking.presentation.registration.edit.navigation.MyRegistrationEditActivityNavigationImpl
import br.com.portoseguro.banking.presentation.subhome.SubHomeAccountViewModel
import br.com.portoseguro.banking.presentation.subhome.cards.SubHomeCardsViewModel
import br.com.portoseguro.banking.presentation.subhome.help.BankingSubHomeHelpViewModel
import br.com.portoseguro.banking.presentation.subhome.incentive.CardIncentiveViewModel
import br.com.portoseguro.banking.presentation.subhome.invoice_payment.amount_insertion.InvoiceAmountInsertionViewModel
import br.com.portoseguro.banking.presentation.subhome.invoice_payment.barcode_scan.InvoiceScannerViewModel
import br.com.portoseguro.banking.presentation.subhome.invoice_payment.code_insertion.InvoiceCodeInsertionViewModel
import br.com.portoseguro.banking.presentation.subhome.invoice_payment.summary.InvoicePaymentSummaryViewModel
import br.com.portoseguro.banking.presentation.subhome.navigation.AccountSubHomeNavigation
import br.com.portoseguro.banking.presentation.subhome.navigation.AccountSubHomeNavigationImpl
import br.com.portoseguro.banking.presentation.summary.SummaryHeaderResourceImpl
import br.com.portoseguro.banking.presentation.summary.SummaryViewModel
import br.com.portoseguro.banking.presentation.tariffs.TariffsViewModel
import br.com.portoseguro.banking.presentation.tariffs.navigation.TariffsActivityNavigation
import br.com.portoseguro.banking.presentation.tariffs.navigation.TariffsActivityNavigationImpl
import br.com.portoseguro.banking.presentation.tariffs.navigation.TariffsFragmentNavigation
import br.com.portoseguro.banking.presentation.tariffs.navigation.TariffsFragmentNavigationImpl
import br.com.portoseguro.banking.router.BankingAccountRouterImpl
import br.com.portoseguro.banking.router.BankingHelpRouterImpl
import br.com.portoseguro.banking.router.BankingTariffsRouterImpl
import br.com.portoseguro.banking.router.CardRouterImpl
import br.com.portoseguro.banking.router.LockUnlockCardRouterImpl
import br.com.portoseguro.banking.router.MyRegistrationDataRouterImpl
import br.com.portoseguro.banking.router.ShowPasswordRouterImpl
import br.com.portoseguro.banking.router.UnlockCardRouterImpl
import br.com.portoseguro.banking.sharedbanking.business.BankingInvoiceBusiness
import br.com.portoseguro.banking.sharedbanking.business.BankingShortcutBusiness
import br.com.portoseguro.banking.sharedbanking.business.InvoicePaymentBusiness
import br.com.portoseguro.banking.sharedbanking.business.NewCardBusiness
import br.com.portoseguro.banking.sharedbanking.data.mapper.InvoiceMapper
import br.com.portoseguro.banking.sharedbanking.data.mapper.InvoiceMapperImpl
import br.com.portoseguro.banking.sharedbanking.data.mapper.InvoicePaymentMapper
import br.com.portoseguro.banking.sharedbanking.data.mapper.InvoicePaymentMapperImpl
import br.com.portoseguro.banking.sharedbanking.data.mapper.InvoicePaymentResponseMapper
import br.com.portoseguro.banking.sharedbanking.data.mapper.InvoicePaymentResponseMapperImpl
import br.com.portoseguro.banking.sharedbanking.data.mapper.InvoiceTransactionSummaryMapper
import br.com.portoseguro.banking.sharedbanking.data.mapper.InvoiceTransactionSummaryMapperImpl
import br.com.portoseguro.banking.sharedbanking.di.permission
import br.com.portoseguro.banking.sharedbanking.embedded_token.BankingAuthfyConfig
import br.com.portoseguro.banking.sharedbanking.embedded_token.BankingAuthfyConfigImpl
import br.com.portoseguro.banking.sharedbanking.embedded_token.BankingBiometryViewModel
import br.com.portoseguro.banking.sharedbanking.entity.shortcut.AccountShortcuts
import br.com.portoseguro.banking.sharedbanking.entity.shortcut.CardShortcuts
import br.com.portoseguro.banking.sharedbanking.entity.subhome.Card
import br.com.portoseguro.banking.sharedbanking.mapper.BankingShortcutFeatureToggleKeyMapper
import br.com.portoseguro.banking.sharedbanking.mapper.BankingStatusMapper
import br.com.portoseguro.banking.sharedbanking.presentation.header.SummaryHeaderResource
import br.com.portoseguro.banking.sharedbanking.repository.AccountShortcutRepository
import br.com.portoseguro.banking.sharedbanking.repository.BankingRepository
import br.com.portoseguro.banking.sharedbanking.repository.BankingShortcutAvailability
import br.com.portoseguro.banking.sharedbanking.repository.CardShortcutRepository
import br.com.portoseguro.banking.sharedbanking.repository.CardsRepository
import br.com.portoseguro.banking.sharedbanking.repository.MyRegistrationHomeRepository
import br.com.portoseguro.banking.sharedbanking.repository.ProvideBankingShortcutList
import br.com.portoseguro.banking.sharedbanking.repository.SummaryRepository
import br.com.portoseguro.banking.sharedbanking.repository.invoice.InvoicePaymentRepository
import br.com.portoseguro.banking.sharedbanking.repository.invoice.InvoiceRepository
import br.com.portoseguro.banking.sharedbanking.utils.params.BankingSummaryAuthfyParams
import br.com.portoseguro.superapp.core.api.moshi.MoshiHttp
import br.com.portoseguro.superapp.core.api.moshi.create
import br.com.portoseguro.superapp.core.toggle.FeatureToggle
import br.com.portoseguro.superapp.router.banking.BankingAccountRouter
import br.com.portoseguro.superapp.router.banking.BankingHelpRouter
import br.com.portoseguro.superapp.router.banking.BankingTariffsRouter
import br.com.portoseguro.superapp.router.banking.CardRouter
import br.com.portoseguro.superapp.router.banking.LockUnlockCardRouter
import br.com.portoseguro.superapp.router.banking.ShowPasswordRouter
import br.com.portoseguro.superapp.router.banking.UnlockCardRouter
import br.com.portoseguro.superapp.router.myregistrationdata.MyRegistrationDataRouter
import br.com.portoseguro.usersecurity.support.ext.forced.business.BiometryBusiness
import br.com.portoseguro.usersecurity.support.ext.forced.viewmodel.BiometryViewModel
import org.koin.androidx.viewmodel.dsl.viewModel
import org.koin.core.context.loadKoinModules
import org.koin.core.module.Module
import org.koin.core.parameter.parametersOf
import org.koin.core.qualifier.named
import org.koin.dsl.module

fun loadBankingModules() = lazyLoadBankingModules

private val lazyLoadBankingModules by lazy { loadKoinModules(bankingModule) }

private const val CARD_SHORTCUT_PROVIDER = "ProvideCardShortcutsQualifier"
private const val CARD_SHORTCUT_FEATURE_TOGGLE_MAPPER = "CardShortcutFeatureToggleKeyMapper"
private const val CARD_SHORTCUT_AVAILABILITY = "CardShortcutAvailability"

private val bankingModule = module {
    entry()
    story()
    status()
    cards()
    summary()
    home()
    onboard()
    permission()
    invoice()
    password()
    myRegistrationData()
    registration()
    help()
    tariff()
}

private fun Module.entry() {
    viewModel { EntryViewModel(bankingBusiness = get()) }
}

private fun Module.cards() {
    factory { CardIncentiveBusiness(get()) }
    factory { AddressDeliveryMapper() }
    factory { CardMapper() }
    factory<CardsRepository> {
        CardsRepositoryImpl(
            bankingAPI = get(),
            apiCaller = get(),
            mapper = get(),
            addressDeliveryMapper = get()
        )
    }
    factory<ProvideBankingShortcutList<CardShortcuts>>(
        named(CARD_SHORTCUT_PROVIDER)
    ) { ProvideCardShortcuts() }
    factory<BankingShortcutFeatureToggleKeyMapper<CardShortcuts>>(
        named(CARD_SHORTCUT_FEATURE_TOGGLE_MAPPER)
    ) { CardShortcutFeatureToggleMapper() }
    viewModel { (context: Context) ->
        SubHomeCardsViewModel(
            cardBusiness = get(),
            sharedGenerateShortcut = get(),
            cardSubHomeNavigation = get { parametersOf(context) },
            lockUnlockCardNavigation = get { parametersOf(context) },
            subHomeAnalytics = get()
        )
    }
    factory<ConfirmSecurityCodeResourceProvider> {
        ConfirmSecurityCodeResourceProviderImpl(resourceProvider = get())
    }
    factory<CardLockUnlockResourceProvider> {
        CardLockUnlockResourceProviderImpl(resourceProvider = get())
    }
    viewModel { (isHome: Boolean?) ->
        CardIncentiveViewModel(
            isHome = isHome,
            notificationCardFlow = get(),
            cardIncentiveBusiness = get()
        )
    }
    viewModel { OnboardingNavViewModel() }
    viewModel { (card: Card?, cardId: String) ->
        SearchCardOrNotViewModel(
            card = card,
            cardId = cardId,
            cardBusiness = get(),
            errorResourceProvider = get()
        )
    }
    viewModel { (card: Card) ->
        LockUnlockViewModel(
            card = card,
            cardBusiness = get(),
            resourceProvider = get(),
            notificationCard = get()
        )
    }
    viewModel { (cardId: String) ->
        ConfirmSecurityCodeViewModel(
            cardId = cardId,
            cardBusiness = get(),
            confirmSecurityCodeResourceProvider = get(),
            errorGenericResourceProvider = get()
        )
    }
    factory<BankingShortcutAvailability<CardShortcuts>>(named(CARD_SHORTCUT_AVAILABILITY)) {
        CardShortcutAvailabilityImpl(
            featureToggle = get(),
            cardShortcutFeatureToggleKeyMapper = get(named(CARD_SHORTCUT_FEATURE_TOGGLE_MAPPER))
        )
    }
    factory<CardShortcutRepository> {
        CardShortcutRepositoryImpl(
            cardShortcuts = get(named(CARD_SHORTCUT_PROVIDER)),
            cardShortcutAvailability = get(named(CARD_SHORTCUT_AVAILABILITY))
        )
    }
    factory<CardSubHomeNavigation> { params ->
        CardSubHomeNavigationImpl(
            context = params.get(),
            cardRouter = get(),
            extractRouter = get(),
            helpRouter = get()
        )
    }
    factory<LockUnlockCardNavigation> { (context: Context) ->
        LockUnlockCardNavigationImpl(context = context, lockUnlockCardRouter = get())
    }
    factory<LockUnlockCardRouter> { LockUnlockCardRouterImpl() }
    factory<UnlockCardRouter> { UnlockCardRouterImpl() }
    factory<RequestNewCardResourceProvider> {
        RequestNewCardResourceProviderImpl(resourceProvider = get())
    }
    factory<RequestNewCardTitleResourceProvider> {
        RequestNewCardTitleResourceProviderImpl(
            resourceProvider = get()
        )
    }
    viewModel {
        RequestNewCardMessagesViewModel(
            requestNewCardTitleResourceProvider = get(),
            resourceProvider = get()
        )
    }
    viewModel { RequestNewCardNavViewModel() }
    factory { NewCardBusiness(cardsRepository = get(), mapper = get()) }
    factory<ChainInputFieldValidator> { ChainInputFieldValidatorImpl() }
    viewModel { ChainFieldViewModel(chainInputFieldValidator = get()) }
    viewModel {
        RequestNewCardFormViewModel(
            newCardBusiness = get(),
            errorGenericResourceProvider = get(),
            resourceProvider = get(),
            requestNewCardFormMapper = get()
        )
    }
    factory<CardRouter> { CardRouterImpl() }
    factory<RequestNewCardFormMapper> { RequestNewCardFormMapperImpl(resourceProvider = get()) }
    factory<CardDefinitiveBlockReasonMapper> { CardDefinitiveBlockReasonMapperImpl(resourceProvider = get()) }
    viewModel { CardDefinitiveBlockNavViewModel() }
    viewModel { CardDefinitiveBlockReasonViewModel(reasonMapper = get()) }
    viewModel { (cardId: String, type: CardDefinitiveBlockReasonType) ->
        CardDefinitiveBlockViewModel(
            cardId = cardId,
            type = type,
            cardBusiness = get()
        )
    }
}

private fun Module.status() {
    factory { get<MoshiHttp>().create<BankingAPI>() }
    factory<BankingRepository> {
        AccountStatusRepository(
            bankingAPI = get(),
            userDataPersistenceRepository = get(),
            dataRepository = get(),
            localBankingProduct = get()
        )
    }
    factory { BankingStatusMapper() }
}

private fun Module.story() {
    factory<LocalBankingProduct> {

        val toggle: FeatureToggle = get()
        toggle.addDefaultValues(getBankingDefaultFeatureToggle())

        LocalBankingProductImpl(
            resourceProvider = get(),
            featureToggle = toggle
        )
    }
}

private fun Module.summary() {
    factory<BiometryBusiness> {
        ObligatoryBiometryBankingBusiness(repository = get())
    }
    viewModel {
        BiometryViewModel(
            antiFraudSession = get(),
            embeddedTokenBusiness = get(),
            authfyResultCode = get(),
            biometryBusiness = get(),
            params = BankingSummaryAuthfyParams().biometricRegisterFlow()
        )
    }
}

private fun Module.home() {

    single { NotificationCardFlow() }

    factory { AccountSummaryMapper(statusMapper = get(), cardMapper = get()) }
    factory { SummaryShortcutMapper() }
    factory { SummaryShortcutsGenerate(resourceProvider = get()) }
    factory<SummaryRepository> {
        SummaryRepositoryImpl(
            bankingAPI = get(),
            apiCaller = get(),
            summaryMapper = get(),
            shortcutsGenerate = get()
        )
    }
    viewModel {
        SummaryViewModel(
            summaryHeaderResource = get(),
            bankingBusiness = get(),
            shortcutMapper = get(),
            analytics = get(),
            clientHashMemory = get()
        )
    }
    factory<SummaryHeaderResource> { SummaryHeaderResourceImpl(resourceProvider = get()) }
    factory<BankingHelpRouter> { BankingHelpRouterImpl() }
    factory<BankingAccountRouter> { BankingAccountRouterImpl(localBankingProduct = get()) }
    factory { BankingShortcutBusiness(accountShortcutRepository = get()) }
    factory<ProvideBankingShortcutList<AccountShortcuts>> { ProvideAccountShortcuts() }
    factory<BankingShortcutFeatureToggleKeyMapper<AccountShortcuts>> { AccountShortcutFeatureToggleKeyMapper() }
    factory<BankingShortcutAvailability<AccountShortcuts>> {
        AccountShortcutAvailabilityImpl(
            featureToggle = get(),
            accountShortcutFeatureToggleKeyMapper = get()
        )
    }
    factory<AccountShortcutRepository> {
        AccountShortcutRepositoryImpl(
            accountShortcutList = get(),
            bankingShortcutAvailability = get()
        )
    }
    factory<AccountSubHomeNavigation> { (context: Context) ->
        AccountSubHomeNavigationImpl(
            context = context,
            pixRouter = get(),
            cardRouter = get(),
            extractRouter = get(),
            helpRouter = get(),
            showPasswordRouter = get(),
            myRegistrationDataRouter = get(),
            tariffsRouter = get(),
            bankingTransferRouter = get()
        )
    }
    viewModel { (context: Context) ->
        SubHomeAccountViewModel(
            headerResource = get(),
            bankingShortcutBusiness = get(),
            sharedGenerateShortcut = get(),
            accountSubHomeNavigation = get { parametersOf(context) },
            featureToggle = get(),
            subHomeAnalytics = get()
        )
    }
    viewModel { BankingBiometryViewModel(get(), get(), get()) }
    factory<BankingAuthfyConfig> {
        BankingAuthfyConfigImpl(
            antiFraudSession = get(),
            authfyCameraRouter = get()
        )
    }
}

private fun Module.invoice() {
    factory<InvoiceMapper> { InvoiceMapperImpl() }
    factory<InvoicePaymentMapper> { InvoicePaymentMapperImpl(get()) }
    factory<InvoicePaymentResponseMapper> { InvoicePaymentResponseMapperImpl() }
    factory<InvoiceTransactionSummaryMapper> { InvoiceTransactionSummaryMapperImpl(get()) }
    factory<InvoiceRepository> { InvoiceRepositoryImpl(get(), get(), get(), get(), get()) }
    factory<InvoicePaymentRepository> { InvoicePaymentRepositoryImpl(get(), get(), get(), get(), get()) }
    factory { BankingInvoiceBusiness(get()) }
    factory { InvoicePaymentBusiness(get()) }
    viewModel { InvoicePaymentSummaryViewModel(get(), get(), get(), get()) }
    viewModel { InvoiceCodeInsertionViewModel(get()) }
    viewModel { InvoiceAmountInsertionViewModel(get(), get()) }
    viewModel { InvoiceScannerViewModel(get()) }
    viewModel { BarcodeScannerViewModel() }
}

private fun Module.onboard() {
    single { OnboardRepository(get()) }

    factory<OnboardCameraParams> { OnboardCameraParamsImpl() }
    factory<OnboardNavigation> { (context: Context) ->
        OnboardNavigationImpl(
            context,
            get(),
            get()
        )
    }
    factory { (context: Context) -> TermsLinkSpannable(context) }

    factory { OfferProductBusiness(get(), get()) }
    factory { OnBoardTermsBusiness(get(), get(), get()) }
    factory { AnalyzeProductBusiness(get(), get()) }
    factory { CreateUserBusiness(get(), get(), get()) }
    factory { DigitalAccountBusiness(get(), get(), get(), get(), get(), get(), get()) }

    viewModel {
        CreateAccountViewModel(
            get(),
            get(),
            get(),
            get(),
            get(),
            get(),
            get(),
            get(),
            get()
        )
    }
    viewModel { PasswordConfirmationViewModel(get()) }
    factory<MyRegistrationHomeRedirect> {
        MyRegistrationHomeRedirectImpl(
            myRegistrationEditActivityNavigation = get()
        )
    }
}

private fun Module.password() {
    factory<AccountPasswordRepository> {
        AccountPasswordRepositoryImpl(
            bankingAPI = get(),
            safeApiCaller = get(),
            passwordMapper = get()
        )
    }
    factory<AccountPasswordMapper> { AccountPasswordMapperImpl() }
    factory<AccountPasswordBusiness> {
        AccountPasswordBusinessImpl(
            passwordRepository = get(),
            bankCrypto = get()
        )
    }
    viewModel { AccountShowPasswordViewModel(passwordBusiness = get()) }
    factory<ShowPasswordRouter> { ShowPasswordRouterImpl() }
    viewModel {
        AccountPasswordBiometryViewModel(
            embeddedTokenBusiness = get(),
            biometryBusiness = get(),
            authfyResultCode = get()
        )
    }
}

private fun Module.myRegistrationData() {
    factory<MyRegistrationDataRouter> { MyRegistrationDataRouterImpl() }
}

private fun Module.registration() {
    viewModel { MyRegistrationEditViewModel(registrationBusiness = get()) }

    viewModel {
        MyRegistrationHomeViewModel(
            myRegistrationHomeBusiness = get()
        )
    }
    factory<MyRegistrationHomeBusiness> {
        MyRegistrationHomeBusinessImpl(
            myRegistrationHomeRepository = get()
        )
    }
    factory<MyRegistrationHomeRepository> {
        MyRegistrationHomeRepositoryImpl(
            bankingAPI = get(),
            myRegistrationHomeMapper = get(),
            safeApiCaller = get()
        )
    }
    factory<MyRegistrationAddressMapper> {
        MyRegistrationAddressMapperImpl()
    }
    factory<MyRegistrationHomeMapper> {
        MyRegistrationHomeMapperImpl(
            myRegistrationAddressMapper = get()
        )
    }

    factory<MyRegistrationEditActivityNavigation> {
        MyRegistrationEditActivityNavigationImpl()
    }
}

private fun Module.help() {
    viewModel { BankingSubHomeHelpViewModel(helpBusiness = get()) }
}

private fun Module.tariff() {
    viewModel { TariffsViewModel(tariffsBusiness = get()) }
    factory<TariffsActivityNavigation> {
        TariffsActivityNavigationImpl()
    }
    factory<TariffsFragmentNavigation> {
        TariffsFragmentNavigationImpl()
    }
    factory<BankingTariffsRouter> { BankingTariffsRouterImpl() }
}

private fun getBankingDefaultFeatureToggle(): Map<String, Boolean> {
    return mapOf(
        PORTO_BANKING_PASS_LIST to false,
        PAY_BILL to false,
        PIX to false,
        EXTRACT to false,
        CASH_OUT to false,
        SECURITY_ACCOUNT to false,
        HELP to false,
        DEBIT_CARD to false,
        SHOW_PASSWORD to false,
        CARD_EXTRACT to false,
        CARD_HELP to false,
        CARD_CHECK_OR_CHANGE_PASSWORD to false,
        REQUEST_NEW_CARD to false,
        LOCK_UNLOCK to false,
        MY_REGISTRATION_DATA to false,
        TARIFFS to false
    ) + AccountFeatureToggleKeys.getDefaultValueMap()
}
