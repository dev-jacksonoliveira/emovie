package br.com.portoseguro.banking.utils

private const val ZERO = 0
private const val FIVE = 5
private const val TRACE = "-"

internal fun String.maskCep(): String {
    return if (this.length > FIVE) {
        this.substring(ZERO, FIVE) + TRACE + this.substring(FIVE)
    } else {
        this
    }
}
