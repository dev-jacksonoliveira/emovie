package br.com.portoseguro.banking.router

import android.content.Context
import android.os.Parcelable
import br.com.portoseguro.banking.presentation.card.unlock.UnlockCardActivity
import br.com.portoseguro.superapp.router.banking.UnlockCardRouter

class UnlockCardRouterImpl: UnlockCardRouter {
    override fun getIntent(context: Context, cardParcelable: Parcelable) =
        UnlockCardActivity.newInstance(context, cardParcelable)
}