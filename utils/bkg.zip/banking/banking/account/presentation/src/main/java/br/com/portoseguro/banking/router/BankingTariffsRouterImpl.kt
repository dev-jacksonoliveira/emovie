package br.com.portoseguro.banking.router

import android.content.Context
import br.com.portoseguro.banking.presentation.tariffs.TariffsActivity
import br.com.portoseguro.superapp.core.infrastructure.extensions.createIntent
import br.com.portoseguro.superapp.router.banking.BankingTariffsRouter

class BankingTariffsRouterImpl: BankingTariffsRouter {

    override fun getIntent(context: Context) = context.createIntent<TariffsActivity>()
}