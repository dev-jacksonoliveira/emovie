package br.com.portoseguro.banking.router

import androidx.fragment.app.Fragment
import br.com.portoseguro.banking.data.local.LocalBankingProduct
import br.com.portoseguro.banking.presentation.entry.EntryFragment
import br.com.portoseguro.superapp.router.banking.BankingAccountRouter

internal class BankingAccountRouterImpl(private val localBankingProduct: LocalBankingProduct) : BankingAccountRouter {

    override fun getEntryFragment(): Fragment {
        return EntryFragment.newInstance()
    }

    override fun getAccountToggleKey(): String = localBankingProduct.getProductToggleKey()
}