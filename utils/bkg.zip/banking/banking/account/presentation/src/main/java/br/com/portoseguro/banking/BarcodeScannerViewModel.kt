package br.com.portoseguro.banking

import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class BarcodeScannerViewModel : ViewModel() {

    private val _cameraProvider = MutableLiveData<ProcessCameraProvider>()
    val cameraProvider: LiveData<ProcessCameraProvider> = _cameraProvider

    fun setCameraProvider(processCameraProvider: ProcessCameraProvider) {
        _cameraProvider.postValue(processCameraProvider)
    }
}
