package br.com.portoseguro.banking.router

import android.content.Context
import android.content.Intent
import android.os.Parcelable
import br.com.portoseguro.banking.presentation.card.lock_unlock.LockUnlockCardActivity
import br.com.portoseguro.banking.sharedbanking.entity.subhome.Card
import br.com.portoseguro.superapp.router.banking.LockUnlockCardRouter

class LockUnlockCardRouterImpl: LockUnlockCardRouter {
    override fun getIntent(context: Context, cardParcelable: Parcelable): Intent =
        LockUnlockCardActivity.newInstance(context, cardParcelable)
}