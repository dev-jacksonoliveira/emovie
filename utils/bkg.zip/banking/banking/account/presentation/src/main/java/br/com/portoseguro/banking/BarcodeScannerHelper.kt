package br.com.portoseguro.banking

import android.annotation.SuppressLint
import android.content.Context
import android.util.DisplayMetrics
import android.util.Log
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.core.UseCaseGroup
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import com.google.mlkit.vision.barcode.BarcodeScanner
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.common.InputImage

interface CodeListener {
    fun onCodeAcquired(code: String)
}

@SuppressLint("UnsafeExperimentalUsageError", "UnsafeOptInUsageError")
class BarcodeScannerHelper internal constructor(
    private val context: Context,
    private val preview: PreviewView,
    private val viewModel: BarcodeScannerViewModel,
    private val codeListener: CodeListener? = null
) : DefaultLifecycleObserver {

    private lateinit var camera: Camera
    private val cameraSelector by lazy {
        CameraSelector.Builder().requireLensFacing(CameraSelector.LENS_FACING_BACK).build()
    }

    private val screenAspectRatio by lazy {
        val metrics = DisplayMetrics().also { preview.display.getRealMetrics(it) }
        metrics.getAspectRatio()
    }

    private val executor by lazy { ContextCompat.getMainExecutor(context) }

    override fun onResume(owner: LifecycleOwner) {
        super.onResume(owner)
        viewModel.cameraProvider.observe(owner) {
            it?.let {
                bindUseCase(owner)
            }
        }
    }

    internal fun bindUseCase(lifecycleOwner: LifecycleOwner) {

        val barcodeScanner = BarcodeScanning.getClient()

        val previewUseCase = Preview.Builder()
            .setTargetRotation(preview.display.rotation)
            .setTargetAspectRatio(screenAspectRatio)
            .build().also {
                it.setSurfaceProvider(preview.surfaceProvider)
            }

        val analysisUseCase = ImageAnalysis.Builder()
            .setTargetRotation(preview.display.rotation)
            .setTargetAspectRatio(screenAspectRatio)
            .build().also {
                it.setAnalyzer(
                    executor
                ) { imageProxy ->
                    processImageProxy(barcodeScanner, imageProxy)
                }
            }

        val useCaseGroup = UseCaseGroup.Builder()
            .addUseCase(previewUseCase)
            .addUseCase(analysisUseCase)
            .build()

        try {
            viewModel.cameraProvider.value?.bindToLifecycle(
                lifecycleOwner,
                cameraSelector,
                useCaseGroup
            )?.let {
                camera = it
            }
        } catch (e: Exception) {
            Log.e(TAG, "bindUseCase: ${e.localizedMessage}")
        }
    }

    private fun processImageProxy(barcodeScanner: BarcodeScanner, imageProxy: ImageProxy) {
        imageProxy.image?.let { image ->
            val inputImage = InputImage.fromMediaImage(image, imageProxy.imageInfo.rotationDegrees)
            barcodeScanner.process(inputImage)
                .addOnSuccessListener { barcodeList ->
                    if (!barcodeList.isNullOrEmpty()) {
                        barcodeList.first()?.let { digitableLine ->
                            codeListener?.onCodeAcquired(digitableLine.rawValue.toString())
                        }
                    }
                }.addOnFailureListener {
                    Log.e(TAG, "processImageProxy: ${it.localizedMessage}")
                }.addOnCompleteListener {
                    imageProxy.close()
                }
        }
    }

    internal fun releaseCapture(lifecycleOwner: LifecycleOwner){
        unbindProvider()
        bindUseCase(lifecycleOwner)
    }

    internal fun unbindProvider() {
        viewModel.cameraProvider.value?.unbindAll()
    }

    internal fun setupCameraProvider() {
        val cameraProvideFuture = ProcessCameraProvider.getInstance(context)
        cameraProvideFuture.addListener(
            { viewModel.setCameraProvider(cameraProvideFuture.get()) },
            executor
        )
    }

    companion object {
        private const val TAG = "BarcodeScannerHelper"
    }
}