package br.com.portoseguro.banking.router

import android.content.Context
import android.content.Intent
import br.com.portoseguro.banking.presentation.onboard.home.MyRegistrationHomeActivity
import br.com.portoseguro.banking.presentation.password.show.AccountShowPasswordActivity
import br.com.portoseguro.superapp.core.infrastructure.extensions.createIntent
import br.com.portoseguro.superapp.router.myregistrationdata.MyRegistrationDataRouter

internal class MyRegistrationDataRouterImpl : MyRegistrationDataRouter {

    override fun getSubHomeMyRegistrationDataIntent(context: Context) =
        context.createIntent<MyRegistrationHomeActivity>()

    override fun getSubHomeMyRegistrationClearTopDataIntent(context: Context) =
        Intent(context, MyRegistrationHomeActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
        }
}