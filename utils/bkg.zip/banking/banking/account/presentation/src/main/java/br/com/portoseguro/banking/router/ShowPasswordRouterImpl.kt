package br.com.portoseguro.banking.router

import android.content.Context
import android.content.Intent
import br.com.portoseguro.banking.presentation.password.show.AccountShowPasswordActivity
import br.com.portoseguro.superapp.router.banking.ShowPasswordRouter

class ShowPasswordRouterImpl : ShowPasswordRouter {

    override fun getIntent(context: Context): Intent {
        return AccountShowPasswordActivity.getLaunchIntent(context)
    }
}