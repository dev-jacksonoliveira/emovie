package br.com.portoseguro.banking.data

import br.com.portoseguro.banking.sharedbanking.entity.invoice.InvoiceData
import br.com.portoseguro.banking.sharedbanking.entity.invoice.InvoicePaymentData
import br.com.portoseguro.banking.sharedbanking.entity.receipt.ReceiptData
import br.com.portoseguro.banking.sharedbanking.entity.receipt.ReceiptElement
import br.com.portoseguro.banking.sharedbanking.entity.receipt.ReceiptSummary
import br.com.portoseguro.sharedentity.banking.response.InvoiceResponse
import br.com.portoseguro.sharedentity.banking.response.PixPaymentReceiptResponse
import br.com.portoseguro.sharedentity.banking.response.PixPaymentResponse
import br.com.portoseguro.sharedentity.banking.response.PixPaymentSummaryResponse

object MockInvoice {

    internal const val INVOICE_CODE = "19827198273198273918739812739819823719823712"
    internal const val RESPONSE =
        "{ \"erros\": [{\"campo\": \"FIELD\",\"mensagens\": [\"Campo inválido\"]}]}"
    internal const val EXPIRED_INVOICE_RESPONSE = "BOLETO_EXPIRADO"
    internal const val INVALID_CODE_RESPONSE = "BOLETO_CODIGO_INVALIDO"
    internal const val INSUFFICIENT_FUNDS_RESPONSE = "BOLETO_SALDO_INSUFICIENTE"
    internal const val TIME_BOX_OVERTIME = "BOLETO_HORARIO_EXCEDIDO"
    internal const val TRANSACTION_LIMIT_EXCEEDED = "BOLETO_LIMITE_TRANSACOES_EXCEDIDO"
    internal const val INVOICE_PAID = "BOLETO_PAGO"

    internal fun getInvoicePaymentData() =
        InvoicePaymentData(INVOICE_CODE, 5000L, "", 4000000L, "")

    internal fun getPixResponse() = PixPaymentResponse(
        PixPaymentSummaryResponse(paymentData = "", totalValue = "", name = ""),
        listOf(PixPaymentReceiptResponse(title = "", value = "", header = false))
    )

    internal fun getReceiptData() = ReceiptData(
        ReceiptSummary(paymentDate = "", value = "", name = "", statusTransaction = ""),
        listOf(ReceiptElement(title = "", value = "", isHeader = false))
    )

    internal fun getInvoiceResponse(): InvoiceResponse = InvoiceResponse(
        invoiceCode = INVOICE_CODE,
        editable = false,
        expired = false,
        formattedBalance = "R$ 10,00",
        balance = 1000L,
        formattedValue = "R$ 10,00",
        value = 1000L,
        formattedValueTotal = "R$ 10,00",
        totalValue = 1000L,
        formattedMaxValue = "R$ 10,00",
        valueMax = 1000L,
        formattedMinimum = "R$ 10,00",
        minimum = 1000L,
        paymentDate = "10/01/22",
        dueDate = "10/01/22",
        interestLateFee = "R$ 0,00",
        discount = "R$ 0,00",
        recipient = "John Doe",
    )

    internal fun getInvoiceData(): InvoiceData = InvoiceData(
        invoiceCode = INVOICE_CODE,
        editable = true,
        expired = false,
        formattedBalance = "R$ 10,00",
        balance = 1100L,
        formattedValue = "R$ 10,00",
        value = 1000L,
        formattedTotal = "R$ 10,00",
        valueTotal = 1000L,
        formattedMax = "R$ 10,00",
        valueMax = 1000L,
        formattedMinimum = "R$ 9,00",
        minimum = 900L,
        paymentDate = "10/01/22",
        dueDate = "10/01/22",
        interestLateFee = "R$ 0,00",
        discount = "R$ 0,00",
        recipient = "John Doe",
    )

    internal fun getInvoiceDataLateFee(): InvoiceData = InvoiceData(
        invoiceCode = INVOICE_CODE,
        editable = false,
        expired = true,
        formattedBalance = "R$ 10,00",
        balance = 1000L,
        formattedValue = "R$ 10,00",
        value = 1000L,
        formattedTotal = "R$ 10,00",
        valueTotal = 1000L,
        formattedMax = "R$ 10,00",
        valueMax = 1000L,
        formattedMinimum = "R$ 10,00",
        minimum = 1000L,
        paymentDate = "10/01/22",
        dueDate = "10/01/22",
        interestLateFee = "R$ 0,00",
        discount = "R$ 0,00",
        recipient = "John Doe",
    )

    internal fun getInvoiceDataNonEditable(): InvoiceData = InvoiceData(
        invoiceCode = INVOICE_CODE,
        editable = false,
        expired = false,
        formattedBalance = "R$ 1,00",
        balance = 100L,
        formattedValue = "R$ 10,00",
        value = 1000L,
        formattedTotal = "R$ 10,00",
        valueTotal = 1000L,
        formattedMax = "R$ 10,00",
        valueMax = 1000L,
        formattedMinimum = "R$ 10,00",
        minimum = 1000L,
        paymentDate = "10/01/22",
        dueDate = "10/01/22",
        interestLateFee = "R$ 0,00",
        discount = "R$ 0,00",
        recipient = "John Doe",
    )
}
