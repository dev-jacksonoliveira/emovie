package br.com.portoseguro.banking.sharedbanking.repository

import br.com.portoseguro.banking.sharedbanking.data.remote.RefundAPI
import br.com.portoseguro.sharedentity.banking.request.RefundRequest
import br.com.portoseguro.sharedentity.banking.response.PixPaymentResponse
import br.com.portoseguro.superapp.core.entities.WrappedResponse

internal class RefundRepositoryImpl(private val refundAPI: RefundAPI) : RefundRepository {

    override suspend fun refund(
        password: String,
        transactionId: String,
        refundValue: Long,
        description: String?
    ): WrappedResponse<PixPaymentResponse> {
        val body = RefundRequest(
            password = password,
            idTransaction = transactionId,
            refundValue = refundValue,
            description = description
        )
        return refundAPI.refund(body)
    }
}