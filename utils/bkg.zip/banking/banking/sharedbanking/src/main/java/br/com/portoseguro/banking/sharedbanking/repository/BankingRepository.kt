package br.com.portoseguro.banking.sharedbanking.repository

import br.com.portoseguro.banking.sharedbanking.entity.account.AccountStatusType
import br.com.portoseguro.sharedentity.banking.response.AuthorizationAtarResponse
import br.com.portoseguro.superapp.core.entities.WrappedResponse

interface BankingRepository {
    suspend fun getAccountStatus(): WrappedResponse<AuthorizationAtarResponse>
    fun saveStatus(status: AccountStatusType)
    fun getLocalStatus() : String
    fun getBankingProduct(productCode: String): Any
}
