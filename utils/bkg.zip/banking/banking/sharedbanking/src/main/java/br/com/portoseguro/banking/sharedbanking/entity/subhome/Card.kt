package br.com.portoseguro.banking.sharedbanking.entity.subhome

import android.os.Parcelable
import br.com.portoseguro.banking.sharedbanking.entity.cards.CardStatus
import br.com.portoseguro.banking.sharedbanking.entity.cards.CardTracking
import br.com.portoseguro.banking.sharedbanking.entity.cards.CardType
import kotlinx.android.parcel.Parcelize

@Parcelize
data class Card(
    val cardId: String,
    val cardNumber: String,
    val cardNamePresentation: String,
    val cardBin: String,
    val balance: String?,
    val cardStatus: CardStatus?,
    val cardType: CardType?,
    val deliveryStatus: CardTracking?,
    val deliveryStatusDescription: String?
) : SubHomeData, Parcelable {
    fun isInProduction() = deliveryStatus == CardTracking.IN_PRODUCTION
    fun canRequestNewCard() = isInProduction().not()
}