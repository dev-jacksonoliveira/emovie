package br.com.portoseguro.banking.sharedbanking.entity.tariffs

import br.com.portoseguro.superapp.core.infrastructure.exceptions.BackendException

data class TariffException(val code: Int?) : BackendException()
