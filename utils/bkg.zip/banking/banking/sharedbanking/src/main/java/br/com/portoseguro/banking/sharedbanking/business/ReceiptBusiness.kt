package br.com.portoseguro.banking.sharedbanking.business

import br.com.portoseguro.banking.sharedbanking.entity.receipt.ReceiptData
import br.com.portoseguro.banking.sharedbanking.repository.receipt.ReceiptRepository
import kotlinx.coroutines.flow.Flow

class ReceiptBusiness(private val receiptRepository: ReceiptRepository) {

    fun getReceiptById(transactionId: String): Flow<ReceiptData> {
        return receiptRepository.getReceiptById(transactionId)
    }
}