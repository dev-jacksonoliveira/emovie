package br.com.portoseguro.banking.sharedbanking.repository

import br.com.portoseguro.banking.sharedbanking.data.remote.CancelTransactionAPI
import br.com.portoseguro.sharedentity.banking.request.DeleteScheduleRequest
import br.com.portoseguro.sharedentity.core.model.Empty
import br.com.portoseguro.superapp.core.entities.WrappedResponse

internal class CancelTransactionRepositoryImpl(
    private val cancelTransactionAPI: CancelTransactionAPI
) : CancelTransactionRepository {

    override suspend fun cancelTransaction(id: String): WrappedResponse<Empty> {
        return cancelTransactionAPI.cancel(id)
    }

    override suspend fun cancelSchedule(idCancellation: String, category: String): WrappedResponse<Empty> {
        val body = DeleteScheduleRequest(id = idCancellation, category = category)
        return cancelTransactionAPI.cancelSchedule(body)
    }

    override suspend fun cancelInvoiceSchedule(id: String): WrappedResponse<Empty> {
        return cancelTransactionAPI.cancelInvoiceSchedule(id)
    }
}