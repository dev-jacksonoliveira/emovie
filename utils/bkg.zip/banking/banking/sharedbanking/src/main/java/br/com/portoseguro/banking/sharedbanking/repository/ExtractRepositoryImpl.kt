package br.com.portoseguro.banking.sharedbanking.repository

import br.com.portoseguro.banking.sharedbanking.data.remote.ExtractAPI
import br.com.portoseguro.banking.sharedbanking.entity.extract.Extract
import br.com.portoseguro.banking.sharedbanking.entity.extract.ExtractException
import br.com.portoseguro.banking.sharedbanking.mapper.ExtractMapper
import br.com.portoseguro.sharedentity.banking.response.ExtractResponse
import br.com.portoseguro.sharedentity.core.response.BackendWrappedResponse
import br.com.portoseguro.superapp.core.entities.WrappedResponse
import br.com.portoseguro.superapp.core.infrastructure.SafeApiCaller
import br.com.portoseguro.superapp.core.infrastructure.exceptions.BackendException
import br.com.portoseguro.superapp.core.infrastructure.exceptions.UnprocessableEntityBackendException
import br.com.portoseguro.superapp.core.infrastructure.onError
import br.com.portoseguro.superapp.core.infrastructure.onSuccess
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.FlowCollector
import kotlinx.coroutines.flow.flow
import retrofit2.Response

internal class ExtractRepositoryImpl(
    private val extractAPI: ExtractAPI,
    private val apiCaller: SafeApiCaller,
    private val mapper: ExtractMapper
) : ExtractRepository {

    override fun getExtracts(): Flow<List<Extract>> {
        return flow {
            result()
                .onSuccess { result -> onEmit(result) }
                .onError { error ->
                    if (error.exception is UnprocessableEntityBackendException) {
                        onEmit(createEmptyList())
                    } else if (error.exception is BackendException) {
                        throw ExtractException(error.code)
                    }
                }
        }
    }

    private suspend fun FlowCollector<List<Extract>>.onEmit(
        result: WrappedResponse<List<ExtractResponse>>
    ) = mapper.onTryUnwrapSuccessExtract(this, result)

    private fun createEmptyList(): Response<BackendWrappedResponse<List<ExtractResponse>>> {
        return WrappedResponse.success(BackendWrappedResponse(data = emptyList()))
    }

    private suspend fun result() = apiCaller.safeApiCall { extractAPI.getExtracts() }
}