package br.com.portoseguro.banking.sharedbanking.repository

import br.com.portoseguro.sharedentity.core.model.Empty
import br.com.portoseguro.superapp.core.entities.WrappedResponse

interface CancelTransactionRepository {
    suspend fun cancelTransaction(id: String): WrappedResponse<Empty>
    suspend fun cancelSchedule(idCancellation: String, category: String): WrappedResponse<Empty>
    suspend fun cancelInvoiceSchedule(id: String): WrappedResponse<Empty>
}
