package br.com.portoseguro.banking.sharedbanking.repository.help

import br.com.portoseguro.banking.sharedbanking.entity.help.BankingHelpData
import kotlinx.coroutines.flow.Flow

interface BankingHelpRepository {
    fun fetchFAQ(): Flow<List<BankingHelpData>>
}