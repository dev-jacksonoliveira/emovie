package br.com.portoseguro.banking.sharedbanking.repository

interface BankCrypto {
    fun encryptSecurityCode(plainText: String): String
    fun decrypt(plainText: String) : String
}
