package br.com.portoseguro.banking.sharedbanking.repository.invoice

import br.com.portoseguro.banking.sharedbanking.entity.invoice.InvoiceData
import kotlinx.coroutines.flow.Flow

interface InvoiceRepository {
    fun getInvoice(invoiceCode: String): Flow<InvoiceData>
    fun isScheduleInvoiceAvailable(): Boolean
}

