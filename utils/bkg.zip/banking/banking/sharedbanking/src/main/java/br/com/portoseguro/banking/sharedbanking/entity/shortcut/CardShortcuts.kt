package br.com.portoseguro.banking.sharedbanking.entity.shortcut

sealed interface CardShortcuts : BankingShortcutType {

    sealed interface Shortcut : CardShortcuts {
        object LockOrUnLock : Shortcut
        object Extract : Shortcut
    }

    sealed interface MoreFunctionsThisCard : CardShortcuts {
        object RequestNewCard : MoreFunctionsThisCard
        object SeeChangePassword : MoreFunctionsThisCard
        object Help : MoreFunctionsThisCard
    }
}
