package br.com.portoseguro.banking.sharedbanking.business

import br.com.portoseguro.banking.sharedbanking.entity.tariffs.TariffData
import br.com.portoseguro.banking.sharedbanking.repository.tariffs.TariffsRepository
import kotlinx.coroutines.flow.Flow

class TariffsBusinessImpl(private val tariffsRepository: TariffsRepository) :
    TariffsBusiness {

    override fun getTariffs(): Flow<List<TariffData>> = tariffsRepository.getTariffs()

}