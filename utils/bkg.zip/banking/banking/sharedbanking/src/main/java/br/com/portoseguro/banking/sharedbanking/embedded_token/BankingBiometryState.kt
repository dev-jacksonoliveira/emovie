package br.com.portoseguro.banking.sharedbanking.embedded_token

sealed interface BankingBiometryState {
    object Loading : BankingBiometryState
    object Valid : BankingBiometryState
    object StartAuthy : BankingBiometryState
    object Error : BankingBiometryState
}