package br.com.portoseguro.banking.sharedbanking.business

import br.com.portoseguro.banking.sharedbanking.entity.tariffs.TariffData
import br.com.portoseguro.banking.sharedbanking.entity.tariffs.TariffElement
import br.com.portoseguro.banking.sharedbanking.repository.tariffs.TariffsRepository
import kotlinx.coroutines.flow.Flow

interface TariffsBusiness {
    fun getTariffs(): Flow<List<TariffData>>
}