package br.com.portoseguro.banking.sharedbanking.entity.extract

sealed interface ExtractModelType {
    object Item : ExtractModelType
    object Separator : ExtractModelType
}