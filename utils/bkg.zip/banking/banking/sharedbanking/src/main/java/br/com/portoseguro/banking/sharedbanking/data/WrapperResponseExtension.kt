package br.com.portoseguro.banking.sharedbanking.data

import br.com.portoseguro.superapp.core.entities.WrappedResponse

fun <T : Any> WrappedResponse<T>.unwrapDataBody(): T =
    requireNotNull(body()?.data, { String() })