package br.com.portoseguro.banking.sharedbanking.entity.address

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class AddressCepData(
    val cep: String,
    val city: String,
    val uf: String,
    val publicPlace: String?,
    val district: String?
): Parcelable