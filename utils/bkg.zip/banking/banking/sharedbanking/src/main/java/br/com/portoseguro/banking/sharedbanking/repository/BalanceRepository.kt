package br.com.portoseguro.banking.sharedbanking.repository

interface BalanceRepository {
    fun getBalanceVisibility(): Boolean
    fun setBalanceVisibility(isVisible: Boolean)
    fun saveBalance(balance: String)
    fun getBalance(): String?
}