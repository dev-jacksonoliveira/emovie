package br.com.portoseguro.banking.sharedbanking.router

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import br.com.portoseguro.superapp.router.settings.AppSettingsRouter

internal class AppSettingsRouterImpl : AppSettingsRouter {

    override fun getIntent(context: Context): Intent {
        return Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
            data = Uri.fromParts(SCHEME_KEY, context.packageName, null)
        }
    }

    private companion object {
        const val SCHEME_KEY = "package"
    }
}