package br.com.portoseguro.banking.sharedbanking.embedded_token

import android.content.Context
import android.content.Intent
import androidx.activity.result.ActivityResultCaller
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts

class BiometryHelper(
    viewModel: BankingBiometryViewModel,
    currentFlowBiometry : FlowBiometry,
    caller: ActivityResultCaller,
    private val authfyConfig: BankingAuthfyConfig,
    private val defaultResultLauncher: ActivityResultLauncher<Intent> = caller.registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result -> viewModel.onAuthfyReceivedCode(result.resultCode, currentFlowBiometry) }
) {

    fun launch(context: Context) {
        val intent = authfyConfig.invoke(context)
        defaultResultLauncher.launch(intent)
    }
}
