package br.com.portoseguro.banking.sharedbanking.entity.invoice

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class InvoicePaymentData(
    val invoiceCode: String,
    val amount: Long,
    val password: String,
    val schedulingDate: Long?,
    val recipient: String
) : Parcelable
