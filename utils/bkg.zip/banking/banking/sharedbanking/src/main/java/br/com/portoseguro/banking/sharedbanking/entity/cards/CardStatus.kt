package br.com.portoseguro.banking.sharedbanking.entity.cards

enum class CardStatus(val statusCode: String) {
    VALID("1"),
    INITIAL_BLOCKED("2"),
    CANCEL_LOSS("4"),
    CANCEL_THEFT("5"),
    CANCEL_DAMAGED("9"),
    CANCEL_OTHERS("20"),
    TEMPORARY_BLOCKED("37")
}

fun CardStatus.isBlocked() = this == CardStatus.INITIAL_BLOCKED ||
        this == CardStatus.CANCEL_LOSS ||
        this == CardStatus.CANCEL_THEFT ||
        this == CardStatus.CANCEL_DAMAGED ||
        this == CardStatus.CANCEL_OTHERS ||
        this == CardStatus.TEMPORARY_BLOCKED

fun CardStatus.isDefinitiveBlocked() = this == CardStatus.CANCEL_LOSS ||
        this == CardStatus.CANCEL_THEFT ||
        this == CardStatus.CANCEL_DAMAGED ||
        this == CardStatus.CANCEL_OTHERS