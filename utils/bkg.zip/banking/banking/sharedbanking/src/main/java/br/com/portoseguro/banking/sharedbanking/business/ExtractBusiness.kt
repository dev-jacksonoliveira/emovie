package br.com.portoseguro.banking.sharedbanking.business

import br.com.portoseguro.banking.sharedbanking.entity.extract.ExtractAttributeException
import br.com.portoseguro.banking.sharedbanking.entity.extract.ExtractException
import br.com.portoseguro.banking.sharedbanking.entity.extract.ExtractResult
import br.com.portoseguro.banking.sharedbanking.repository.ExtractRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.flow

class ExtractBusiness(private val extractRepository: ExtractRepository) {

    fun getExtracts(): Flow<ExtractResult> {
        return flow {
            extractRepository.getExtracts()
                .catch { error ->
                    emit(when (error) {
                        is ExtractException,
                        ExtractAttributeException -> ExtractResult.Error
                        else -> throw error
                    })
                }.collect { extracts -> emit(ExtractResult.Success(extracts)) }
        }
    }
}
