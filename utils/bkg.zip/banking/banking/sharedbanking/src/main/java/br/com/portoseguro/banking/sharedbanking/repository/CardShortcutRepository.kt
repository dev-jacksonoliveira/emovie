package br.com.portoseguro.banking.sharedbanking.repository

import br.com.portoseguro.banking.sharedbanking.entity.shortcut.CardShortcuts

interface CardShortcutRepository {
    fun getShortcuts() : List<CardShortcuts>
}