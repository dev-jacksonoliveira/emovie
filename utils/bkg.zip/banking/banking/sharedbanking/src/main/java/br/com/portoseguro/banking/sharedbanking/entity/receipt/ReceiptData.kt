package br.com.portoseguro.banking.sharedbanking.entity.receipt

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class ReceiptData(
    val summary: ReceiptSummary,
    val elements: List<ReceiptElement>
) : Parcelable