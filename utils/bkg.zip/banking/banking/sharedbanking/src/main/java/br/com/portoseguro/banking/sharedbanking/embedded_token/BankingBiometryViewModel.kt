package br.com.portoseguro.banking.sharedbanking.embedded_token

import androidx.lifecycle.LiveData
import br.com.portoseguro.banking.sharedbanking.business.BiometryBusiness
import br.com.portoseguro.banking.sharedbanking.tool.BaseAccountViewModel
import br.com.portoseguro.embeddedtoken.domain.business.token.EmbeddedTokenBusiness
import br.com.portoseguro.superapp.core.infrastructure.livedata.single.SingleLiveEvent
import br.com.portoseguro.superapp.router.authfy.result.AuthfyCameraFlowResult
import kotlinx.coroutines.flow.single

open class BankingBiometryViewModel (
    private val embeddedTokenBusiness: EmbeddedTokenBusiness,
    private val biometryBusiness: BiometryBusiness,
    protected val authfyResultCode: AuthfyCameraFlowResult
) : BaseAccountViewModel() {

    val state : LiveData<BankingBiometryState> get() = stateLiveEvent
    private val stateLiveEvent : SingleLiveEvent<BankingBiometryState> = SingleLiveEvent()

    open fun onAuthfyReceivedCode(code: Int, currentFlowBiometry: FlowBiometry?) {
        if (code == authfyResultCode.getSuccessCode()) {
            if (currentFlowBiometry == FlowBiometry.All) {
                provideToken()
            } else if (currentFlowBiometry == FlowBiometry.Facial) {
                sendValid()
            }
        } else {
            state(BankingBiometryState.Error)
        }
    }

    fun verifyEmbeddedToken() {
        if (biometryBusiness.onCheckTokenAvailability()) {
            embeddedToken()
        } else {
            sendValid()
        }
    }

    private fun provideToken() {
        stateLiveEvent(BankingBiometryState.Loading)
        launch {
            try {
                embeddedTokenBusiness.provideToken().single()
                sendValid()
            } catch (e: Exception) {
                sendAuthfy()
            }
        }
    }

    private fun embeddedToken() {
        stateLiveEvent(BankingBiometryState.Loading)
        launch {
            try {
                val isValid = embeddedTokenBusiness.isValidToken().single()
                if (isValid) sendValid() else sendAuthfy()
            } catch (e: Exception) {
                sendAuthfy()
            }
        }
    }

    private fun sendAuthfy() {
        stateLiveEvent(BankingBiometryState.StartAuthy)
    }

    private fun sendValid() {
        stateLiveEvent(BankingBiometryState.Valid)
    }
}
