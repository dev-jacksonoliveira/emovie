package br.com.portoseguro.banking.sharedbanking.business

import br.com.portoseguro.banking.sharedbanking.data.unwrapDataBody
import br.com.portoseguro.banking.sharedbanking.repository.ChatRepository
import br.com.portoseguro.superapp.core.infrastructure.Result
import br.com.portoseguro.superapp.core.infrastructure.SafeApiCaller
import br.com.portoseguro.superapp.core.infrastructure.exceptions.ServerErrorBackendException
import br.com.portoseguro.usersecurity.repository.UserDataPersistenceRepository

class ChatBusiness(
    private val safeApiCaller: SafeApiCaller,
    private val chatRepository: ChatRepository,
    private val userDataPersistenceRepository: UserDataPersistenceRepository
) {

    private val genericException by lazy { ServerErrorBackendException(GENERIC_SERVER_ERROR) }

    suspend fun getChatUrlPix(): String {
        val result = safeApiCaller.safeApiCall {
            getName()?.let { chatRepository.getPixChat(it) } ?: throw IllegalStateException()
        }
        if (result is Result.Success && result.value.isSuccessful) {
            return result.value.unwrapDataBody().url.orEmpty()
        } else if (result is Result.Error) {
            throw result.exception ?: genericException
        } else throw genericException
    }

    private fun getName(): String? {
        return userDataPersistenceRepository.getUserData()?.userInfo?.presentationName
    }

    companion object {
        private const val GENERIC_SERVER_ERROR = "Unexpected data."
    }
}