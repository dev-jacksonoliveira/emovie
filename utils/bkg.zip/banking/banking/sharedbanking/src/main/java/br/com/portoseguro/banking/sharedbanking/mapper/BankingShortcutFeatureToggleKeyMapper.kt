package br.com.portoseguro.banking.sharedbanking.mapper

import br.com.portoseguro.banking.sharedbanking.entity.shortcut.BankingShortcutType

interface BankingShortcutFeatureToggleKeyMapper<T: BankingShortcutType>{
    operator fun invoke(shortcutType: T): String
}