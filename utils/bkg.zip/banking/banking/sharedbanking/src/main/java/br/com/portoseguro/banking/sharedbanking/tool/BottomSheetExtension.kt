package br.com.portoseguro.banking.sharedbanking.tool

import android.app.Activity
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.util.DisplayMetrics
import android.util.Log
import android.widget.FrameLayout
import androidx.fragment.app.DialogFragment
import com.google.android.material.bottomsheet.BottomSheetBehavior

private typealias DialogFragmentGenericException = Exception

internal fun DialogFragment.getExpandedType(): Int? {
    val dialogFrame: FrameLayout? = dialog?.findViewById(
        com.google.android.material.R.id.design_bottom_sheet
    )

    return  dialogFrame?.let {
        val from = BottomSheetBehavior.from(it)
        from.state
    }
}

internal fun DialogFragment.setExpanded(displayMetrics: DisplayMetrics? = null) {
    dialog?.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
    dialog?.setOnShowListener {
        try {
            val metrics = displayMetrics ?: DisplayMetrics()
            (context as Activity).windowManager.defaultDisplay.getMetrics(metrics)

            val dialogFrame: FrameLayout? = dialog?.findViewById(
                com.google.android.material.R.id.design_bottom_sheet
            )

            val layoutParams = dialogFrame?.layoutParams

            layoutParams?.height = metrics.heightPixels

            dialogFrame?.layoutParams = layoutParams

            dialogFrame?.let {
                BottomSheetBehavior.from(it).state = BottomSheetBehavior.STATE_EXPANDED
            }

        } catch (e: DialogFragmentGenericException) {
            e.message?.let {
                Log.e("TransactionSummaryGenericException", it)
            }
        }
    }
}