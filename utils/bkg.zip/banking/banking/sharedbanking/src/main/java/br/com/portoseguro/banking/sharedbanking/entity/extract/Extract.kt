package br.com.portoseguro.banking.sharedbanking.entity.extract

data class Extract(
    val isScheduled: Boolean,
    val scheduleDate: String?,
    val category: ExtractCategory,
    val ticketCode: String?,
    val date: String?,
    val description: String?,
    val document: String?,
    val id: String,
    val idCancellation: String,
    val institution: String?,
    val title: String?,
    val value: String?,
    val resume: ExtractResume?
)

data class ExtractResume(
    val able: Boolean,
    val title: String,
    val description: String
)
