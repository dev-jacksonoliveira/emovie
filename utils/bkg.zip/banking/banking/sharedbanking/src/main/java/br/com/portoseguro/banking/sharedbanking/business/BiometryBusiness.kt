package br.com.portoseguro.banking.sharedbanking.business

import br.com.portoseguro.banking.sharedbanking.repository.biometry.BiometryRepository

class BiometryBusiness(private val biometryRepository: BiometryRepository) {

    fun onCheckTokenAvailability(): Boolean = biometryRepository.authfyIsEnabled()
}