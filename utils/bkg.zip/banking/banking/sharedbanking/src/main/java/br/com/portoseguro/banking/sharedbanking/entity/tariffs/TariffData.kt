package br.com.portoseguro.banking.sharedbanking.entity.tariffs

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class TariffData(
    val title: String,
    val value: String?,
    val isHeader: Boolean
) : Parcelable