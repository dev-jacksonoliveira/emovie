package br.com.portoseguro.banking.sharedbanking.entity.extract

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class ExtractButtonAction(
    val text: String = String(),
    val canCancel: Boolean = false
) : Parcelable
