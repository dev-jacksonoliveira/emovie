package br.com.portoseguro.banking.sharedbanking.mapper

import br.com.portoseguro.banking.sharedbanking.data.unwrapDataBody
import br.com.portoseguro.banking.sharedbanking.entity.extract.Extract
import br.com.portoseguro.banking.sharedbanking.entity.extract.ExtractCategory
import br.com.portoseguro.banking.sharedbanking.entity.extract.ExtractException
import br.com.portoseguro.banking.sharedbanking.entity.extract.ExtractAttributeException
import br.com.portoseguro.banking.sharedbanking.entity.extract.ExtractResume
import br.com.portoseguro.sharedentity.banking.response.ExtractResponse
import br.com.portoseguro.sharedentity.banking.response.ExtractResumeResponse
import br.com.portoseguro.superapp.core.entities.WrappedResponse
import br.com.portoseguro.superapp.core.utils.orFalse
import br.com.portoseguro.superapp.core.utils.orTrue
import kotlinx.coroutines.flow.FlowCollector

class ExtractMapper {

    operator fun invoke(response: ExtractResponse) = Extract(
        isScheduled = response.isScheduled ?: false,
        scheduleDate = response.scheduleDate,
        category = extractCategory(response.category),
        ticketCode = response.ticketCode,
        date = response.date,
        description = response.description,
        document = response.document,
        id = response.id ?: throw IllegalStateException(),
        idCancellation = response.idCancellation.orEmpty(),
        institution = response.institution,
        title = response.title,
        value = response.value,
        resume = extractResume(response.resume)
    )

    suspend fun onTryUnwrapSuccessExtract(
        collector: FlowCollector<List<Extract>>,
        result: WrappedResponse<List<ExtractResponse>>
    ) = if (result.isSuccessful) {
        try {
            collector.emit(result.unwrapDataBody().map { response -> invoke(response) })
        } catch (exception: IllegalArgumentException) {
            throw ExtractAttributeException
        }
    } else {
        throw ExtractException(result.code())
    }

    private fun extractCategory(
        category: String?,
    ) = ExtractCategory.values().find { categoryValue ->
        categoryValue.name.lowercase() == category?.lowercase()
    } ?: ExtractCategory.OTHER

    private fun extractResume(response: ExtractResumeResponse?) = ExtractResume(
        able = response?.able.orTrue(),
        title = response?.title.orEmpty(),
        description = response?.description.orEmpty()
    )
}