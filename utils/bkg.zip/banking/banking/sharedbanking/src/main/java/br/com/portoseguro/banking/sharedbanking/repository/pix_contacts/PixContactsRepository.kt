package br.com.portoseguro.banking.sharedbanking.repository.pix_contacts

import br.com.portoseguro.banking.sharedbanking.entity.pix_contact.PixContactData
import kotlinx.coroutines.flow.Flow

interface PixContactsRepository {
    fun getContacts(): Flow<List<PixContactData>>
}