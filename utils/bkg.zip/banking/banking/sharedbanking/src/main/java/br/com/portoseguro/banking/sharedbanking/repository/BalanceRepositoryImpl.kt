package br.com.portoseguro.banking.sharedbanking.repository

import br.com.portoseguro.superapp.core.repository.DataRepository
import br.com.portoseguro.superapp.core.repository.DataSourceType

internal class BalanceRepositoryImpl(
    private val dataRepository: DataRepository
) : BalanceRepository {

    private val visibilitySourceType = DataSourceType.MEMORY
    private val balanceSourceType = DataSourceType.MEMORY

    override fun getBalanceVisibility(): Boolean {
        return dataRepository.get(BALANCE_VISIBILITY, true, visibilitySourceType)
    }

    override fun setBalanceVisibility(isVisible: Boolean) {
        dataRepository.set(BALANCE_VISIBILITY, isVisible, visibilitySourceType)
    }

    override fun saveBalance(balance: String) {
        dataRepository.set(BALANCE, balance, balanceSourceType)
    }

    override fun getBalance(): String? {
        return dataRepository.get(BALANCE, null, balanceSourceType)
    }

    private companion object {
        const val BALANCE_VISIBILITY = "account_balance_visibility"
        const val BALANCE = "account_balance"
    }
}