package br.com.portoseguro.banking.sharedbanking.repository

import br.com.portoseguro.banking.sharedbanking.data.exception.BlockedPasswordException
import br.com.portoseguro.banking.sharedbanking.data.exception.InvalidPasswordException
import br.com.portoseguro.banking.sharedbanking.data.mapper.registration.MyRegistrationUpdateRequestMapper
import br.com.portoseguro.banking.sharedbanking.data.mapper.registration.MyRegistrationUpdateResponseMapper
import br.com.portoseguro.banking.sharedbanking.data.remote.MyRegistrationAPI
import br.com.portoseguro.banking.sharedbanking.data.unwrapDataBody
import br.com.portoseguro.banking.sharedbanking.entity.onboard.MyRegistrationUpdateRequestData
import br.com.portoseguro.banking.sharedbanking.entity.onboard.MyRegistrationUpdateResponseData
import br.com.portoseguro.banking.sharedbanking.enum.PasswordBusinessErrorType
import br.com.portoseguro.sharedentity.core.response.BackendError
import br.com.portoseguro.superapp.core.infrastructure.ResourceProvider
import br.com.portoseguro.superapp.core.infrastructure.Result
import br.com.portoseguro.superapp.core.infrastructure.SafeApiCaller
import br.com.portoseguro.superapp.core.infrastructure.exceptions.BackendException
import br.com.portoseguro.superapp.core.infrastructure.onError
import br.com.portoseguro.superapp.core.infrastructure.onSuccess
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.transform

class MyRegistrationUpdateRepositoryImpl(
    private val myRegistrationAPI: MyRegistrationAPI,
    private val safeApiCaller: SafeApiCaller,
    private val requestMapper: MyRegistrationUpdateRequestMapper,
    private val responseMapper: MyRegistrationUpdateResponseMapper
) : MyRegistrationUpdateRepository {

    override fun updateMyRegistrationInfo(body: MyRegistrationUpdateRequestData): Flow<MyRegistrationUpdateResponseData> {
        return flow {
            emit(safeApiCaller.safeApiCall {
                myRegistrationAPI.updateRegistrationEditInformation(
                    requestMapper.convert(body)
                )
            })
        }.transform { scope ->
            scope.run {
                onSuccess { response ->
                    emit(
                        responseMapper.convert(
                            response.unwrapDataBody()
                        )
                    )
                }
                onError { response -> launchException(response) }
            }
        }
    }

    private fun launchException(resultError: Result.Error) {
        if (resultError is Result.BackendError) {
            throw throwBusinessError(resultError, resultError.error?.errors?.first())
        } else {
            throw resultError.exception ?: BackendException()
        }
    }

    private fun throwBusinessError(resultError: Result.Error, error: BackendError?): Throwable {
        val message = error?.messages?.first() ?: error.getLocalErrorMessage()
        return when (error?.field) {
            PasswordBusinessErrorType.PASSWORD_INVALID.field -> InvalidPasswordException(message)
            PasswordBusinessErrorType.PASSWORD_BLOCKED.field -> BlockedPasswordException(message)
            else -> throwGenericException(resultError)
        }
    }

    private fun throwGenericException(resultError: Result.Error): Throwable {
        throw resultError.exception ?: BackendException()
    }

    private fun BackendError?.getLocalErrorMessage(): String {
        return when (this?.field) {
            PasswordBusinessErrorType.PASSWORD_INVALID.field -> PASSWORD_INVALID
            PasswordBusinessErrorType.PASSWORD_BLOCKED.field -> PASSWORD_BLOCKED
            else -> String()
        }
    }

    private companion object {
        const val PASSWORD_INVALID = "Senha incorreta. Verifique a senha correta e tente novamente!"
        const val PASSWORD_BLOCKED = "Sua senha foi bloqueada. Para desbloqueá-la, fale com a gente no CHAT."
    }
}
