package br.com.portoseguro.banking.sharedbanking.repository

import br.com.portoseguro.banking.sharedbanking.entity.onboard.MyRegistrationUpdateRequestData
import br.com.portoseguro.banking.sharedbanking.entity.onboard.MyRegistrationUpdateResponseData
import kotlinx.coroutines.flow.Flow

interface MyRegistrationUpdateRepository {
    fun updateMyRegistrationInfo(body: MyRegistrationUpdateRequestData): Flow<MyRegistrationUpdateResponseData>
}