package br.com.portoseguro.banking.sharedbanking.entity.onboard

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class MyRegistrationUpdateRequestData(
    val email: String?,
    val cellphone: String?,
    val addressUpdateRequestData: MyRegistrationUpdateAddressRequestData?,
    val type: String,
    val password: String
) : Parcelable

@Parcelize
data class MyRegistrationUpdateAddressRequestData(
    val cep: String,
    val publicPlace: String,
    val number: String,
    val complement: String?,
    val city: String,
    val district: String,
    val uf: String
) : Parcelable