package br.com.portoseguro.banking.sharedbanking.entity.onboard

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class MyRegistrationUpdateResponseData(
    val title: String,
    val message: String
) : Parcelable