package br.com.portoseguro.banking.sharedbanking.entity.receipt

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class ReceiptElement(
    val title: String,
    val value: String?,
    val isHeader: Boolean = false
): Parcelable