package br.com.portoseguro.banking.sharedbanking.entity.help

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class BankingHelpData(
    val title: String,
    val link: String
) : Parcelable