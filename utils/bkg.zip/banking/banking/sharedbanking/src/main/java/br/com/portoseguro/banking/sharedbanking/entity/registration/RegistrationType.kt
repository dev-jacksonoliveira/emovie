package br.com.portoseguro.banking.sharedbanking.entity.registration

enum class RegistrationType(val type: String) {
    EMAIL("EMAIL"),
    CELLPHONE("CELULAR"),
    ADDRESS("ENDERECO")
}

