package br.com.portoseguro.banking.sharedbanking.business

import br.com.portoseguro.banking.sharedbanking.entity.shortcut.AccountShortcuts
import br.com.portoseguro.banking.sharedbanking.repository.AccountShortcutRepository

class BankingShortcutBusiness(private val accountShortcutRepository: AccountShortcutRepository) {

    fun getAccountShortcuts(): List<AccountShortcuts> = accountShortcutRepository.getShortcuts()
}