package br.com.portoseguro.banking.sharedbanking.analytics

import android.app.Activity

interface BankingAnalytics {
    fun trackScreenView(
        activity: Activity,
        screen: String,
        itemName: String,
        section: String,
        product: String,
        productIdentify: String? = null,
        subSection1: String? = null,
        subSection2: String? = null,
        subSection3: String? = null,
    )

    fun trackAction(
        action: String,
        itemName: String,
        section: String,
        product: String,
        category: String,
        productIdentify: String? = null,
        label: String? = null,
        subSection1: String? = null,
        subSection2: String? = null,
        subSection3: String? = null,
    )

    fun trackAlert(
        action: String,
        alert: String,
        itemName: String,
        section: String,
        product: String,
        category: String,
        productIdentify: String? = null,
        subSection1: String? = null,
        subSection2: String? = null,
        subSection3: String? = null,
    )

    fun trackError(
        error: String,
        action: String,
        itemName: String,
        section: String,
        product: String,
        category: String,
        productIdentify: String? = null,
        subSection1: String? = null,
        subSection2: String? = null,
        subSection3: String? = null,
    )
}