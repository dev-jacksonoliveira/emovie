package br.com.portoseguro.banking.sharedbanking.analytics

import br.com.portoseguro.banking.sharedbanking.analytics.SharedBankingCommonVariables.SharedBanking.DIGITAL_ACCOUNT

object SharedBankingCommonVariables {
    object SharedBanking{
        const val DIGITAL_ACCOUNT = "conta-digital"
    }
    object Screen {
        const val LOGGED_HOME = "home-logada:$DIGITAL_ACCOUNT"
    }
    object Section {
        const val LOGGED_HOME = "home-logada"
    }
}