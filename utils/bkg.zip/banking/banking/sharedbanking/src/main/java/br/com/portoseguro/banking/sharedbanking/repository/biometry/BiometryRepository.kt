package br.com.portoseguro.banking.sharedbanking.repository.biometry

interface BiometryRepository {
    fun authfyIsEnabled() : Boolean
}