package br.com.portoseguro.banking.sharedbanking.business

import br.com.portoseguro.banking.sharedbanking.entity.extract.ExtractCategory
import br.com.portoseguro.banking.sharedbanking.repository.CancelTransactionRepository
import br.com.portoseguro.sharedentity.core.model.Empty
import br.com.portoseguro.sharedentity.core.response.BackendWrappedResponse
import br.com.portoseguro.superapp.core.infrastructure.Result
import br.com.portoseguro.superapp.core.infrastructure.SafeApiCaller
import br.com.portoseguro.superapp.core.infrastructure.onError
import br.com.portoseguro.superapp.core.infrastructure.onSuccess
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import retrofit2.Response

class CancelTransactionBusiness(
    private val apiCaller: SafeApiCaller,
    private val cancelTransactionRepository: CancelTransactionRepository
) {

    fun deleteTransaction(id: String): Flow<Boolean> = flow {
        cancelBuilder(id).onSuccess { emit(it.isSuccessful) }.onError { emit(false) }
    }

    fun deleteScheduleOpenFinance(id: String, category: String, idCancellation: String): Flow<Boolean> = flow {
        if (category == ExtractCategory.PIX_SCHEDULED_OPEN_FINANCE.name) {
            apiCaller.safeApiCall { cancelTransactionRepository.cancelSchedule(idCancellation, category.lowercase()) }
                    .onSuccess { emit(it.isSuccessful) }.onError { emit(false) }
        } else {
                cancelScheduleBuilder(id).onSuccess { emit(it.isSuccessful) }.onError { emit(false) }
            }
        }

    fun deleteSchedule(id: String, category: String): Flow<Boolean> = flow {
        if (category == ExtractCategory.PIX_SCHEDULED.name) {
            apiCaller.safeApiCall { cancelTransactionRepository.cancelSchedule(id, category) }
                    .onSuccess { emit(it.isSuccessful) }.onError { emit(false) }
        } else {
                cancelScheduleBuilder(id).onSuccess { emit(it.isSuccessful) }.onError { emit(false) }
            }
        }

    private suspend fun cancelBuilder(id: String): Result<Response<BackendWrappedResponse<Empty>>> {
        return apiCaller.safeApiCall { cancelTransactionRepository.cancelTransaction(id) }
    }

    private suspend fun cancelScheduleBuilder(id: String): Result<Response<BackendWrappedResponse<Empty>>> {
        return apiCaller.safeApiCall { cancelTransactionRepository.cancelInvoiceSchedule(id) }
    }

}