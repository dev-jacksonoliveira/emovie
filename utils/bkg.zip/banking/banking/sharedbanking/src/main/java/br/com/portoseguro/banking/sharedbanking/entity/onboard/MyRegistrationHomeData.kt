package br.com.portoseguro.banking.sharedbanking.entity.onboard

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class MyRegistrationHomeData(
    val email: String,
    val cellphone: String,
    val address: MyRegistrationAddressData
) : Parcelable