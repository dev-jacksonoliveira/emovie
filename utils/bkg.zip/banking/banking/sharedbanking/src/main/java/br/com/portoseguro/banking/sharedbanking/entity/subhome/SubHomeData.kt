package br.com.portoseguro.banking.sharedbanking.entity.subhome

sealed interface SubHomeData
