package br.com.portoseguro.banking.sharedbanking.mapper

import br.com.portoseguro.banking.sharedbanking.data.unwrapDataBody
import br.com.portoseguro.banking.sharedbanking.entity.extract.ExtractAttributeException
import br.com.portoseguro.banking.sharedbanking.entity.extract.ExtractException
import br.com.portoseguro.banking.sharedbanking.entity.receipt.ReceiptData
import br.com.portoseguro.banking.sharedbanking.entity.receipt.ReceiptElement
import br.com.portoseguro.banking.sharedbanking.entity.receipt.ReceiptSummary
import br.com.portoseguro.sharedentity.banking.response.receipt.ReceiptDataResponse
import br.com.portoseguro.sharedentity.banking.response.receipt.ReceiptItemResponse
import br.com.portoseguro.sharedentity.banking.response.receipt.ReceiptSummaryResponse
import br.com.portoseguro.superapp.core.entities.WrappedResponse
import kotlinx.coroutines.flow.FlowCollector

class ReceiptMapper {

    suspend fun onTryUnwrapSuccessReceipt(
        collector: FlowCollector<ReceiptData>,
        result: WrappedResponse<ReceiptDataResponse>,
    ) = if (result.isSuccessful) {
        try {
            collector.emit(invoke(result.unwrapDataBody()))
        } catch (exception: IllegalArgumentException) {
            throw ExtractAttributeException
        }
    } else {
        throw ExtractException(result.code())
    }

    private operator fun invoke(response: ReceiptDataResponse) = ReceiptData(
        summary = response.summary?.let { receiptSummary(it) } ?: throw IllegalStateException(),
        elements = response.items?.let {
                list -> list.map { item -> receipt(item) }
        } ?: throw IllegalStateException()
    )

    private fun receiptSummary(response: ReceiptSummaryResponse) = ReceiptSummary(
        name = response.name.orEmpty(),
        statusTransaction = response.statusTransaction.orEmpty(),
        paymentDate = response.paymentDate.orEmpty(),
        value = response.totalValue.orEmpty()
    )

    private fun receipt(response: ReceiptItemResponse) = ReceiptElement(
        title = response.title.orEmpty(),
        value = response.value.orEmpty(),
        isHeader = response.isHeader ?: false
    )
}
