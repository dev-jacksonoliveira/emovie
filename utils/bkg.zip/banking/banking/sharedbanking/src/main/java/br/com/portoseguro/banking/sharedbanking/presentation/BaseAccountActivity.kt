package br.com.portoseguro.banking.sharedbanking.presentation

import androidx.annotation.IdRes
import androidx.annotation.StringRes
import androidx.fragment.app.Fragment
import br.com.portoseguro.banking.sharedbanking.R
import br.com.portoseguro.banking.sharedbanking.utils.extension.showBottomSheetSafe
import br.com.portoseguro.banking.sharedbanking.utils.extension.showSuccessfulOperationBottomSheet
import br.com.portoseguro.components.confirmation.Confirmation
import br.com.portoseguro.components.stickheader.StickHeader
import br.com.portoseguro.designsystem.snackbar.Snackbar
import br.com.portoseguro.designsystem.snackbar.SnackbarType
import br.com.portoseguro.superapp.core.ui.BaseActivity
import com.google.android.material.bottomsheet.BottomSheetDialogFragment

abstract class BaseAccountActivity : BaseActivity() {

    override fun onBackPressed() {
        if (supportFragmentManager.backStackEntryCount > 1) {
            super.onBackPressed()
        } else {
            finish()
        }
    }

    abstract fun openDefaultFragment()

    open fun onBack() {
        if (supportFragmentManager.backStackEntryCount > 1) {
            supportFragmentManager.popBackStack()
        } else {
            finish()
        }
    }

    protected fun replaceFragment(@IdRes containerIdRes: Int, fragment: Fragment) {
        if (canMakeFragmentTransaction) {
            supportFragmentManager
                .beginTransaction()
                .replace(containerIdRes, fragment)
                .addToBackStack(null)
                .commit()
        }
    }

    protected fun setupStickHeader(header: StickHeader, @StringRes titleRes: Int) {
        setupStickHeader(header, getString(titleRes))
    }

    protected fun setupStickHeader(header: StickHeader, title: String) = with(header) {
        this.title = title
        defaultAttr()
    }

    fun topSnackBarSuccess(message: String) {
        Snackbar.create(this, message, SnackbarType.SUCCESS).show()
    }

    fun topSnackBarError(message: String) {
        Snackbar.create(this, message, SnackbarType.ERROR).show()
    }

    protected fun showSuccessBottomSheet(confirmation: Confirmation, close: () -> Unit) {
        showSuccessfulOperationBottomSheet(confirmation = confirmation, close = close)
    }

    fun showBottomSheet(bottomSheet: BottomSheetDialogFragment) {
        showBottomSheetSafe(bottomSheet)
    }

    private fun StickHeader.defaultAttr() {
        setBackButtonColor(R.color.porto_seguros_100)
        setBackButtonAction { onBack() }
    }
}