package br.com.portoseguro.banking.sharedbanking.entity.shortcut

/**
* Sealed interface to assign your shortcut to render into sub home
* */
sealed interface BankingShortcutType
