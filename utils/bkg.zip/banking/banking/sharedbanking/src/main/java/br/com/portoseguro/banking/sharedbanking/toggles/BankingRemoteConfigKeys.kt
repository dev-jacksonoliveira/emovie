package br.com.portoseguro.banking.sharedbanking.toggles

enum class BankingRemoteConfigKeys(val key: String){
    FIND_CEP("rc_conta_digital_busca_cep_url"),
}