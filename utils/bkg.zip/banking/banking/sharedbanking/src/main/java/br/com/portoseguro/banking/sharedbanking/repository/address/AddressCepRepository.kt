package br.com.portoseguro.banking.sharedbanking.repository.address

import br.com.portoseguro.banking.sharedbanking.entity.address.AddressCepData
import kotlinx.coroutines.flow.Flow

interface AddressCepRepository {
    fun getAddressWithCep(cep: String): Flow<AddressCepData>
    fun getFindCepUrl(): String
}