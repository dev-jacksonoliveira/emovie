package br.com.portoseguro.banking.sharedbanking.tool

import android.app.Activity
import android.content.Context
import android.os.IBinder
import android.view.View
import android.view.inputmethod.InputMethodManager
import androidx.core.content.getSystemService
import androidx.fragment.app.Fragment

private const val HIDDEN = 0

/**
* Extension to close keyboard
 * @param Activity nullable or not
 * @param IBinder nullable or not; How to access {@link android.view#getWindowToken}
**/

fun Activity?.hideKeyBoard(iBinder: IBinder?) {
    iBinder?.let { iB -> this?.onClose(iB) }
}

/**
 * Extension to close keyboard
 * @param Fragment nullable or not
 * @param IBinder nullable or not; How to access {@link android.view#getWindowToken}
 **/

fun Fragment?.hideKeyBoard(iBinder: IBinder?) {
    iBinder?.let { iB -> this?.activity?.onClose(iB) }
}

/**
 * Extension to show keyboard
 * @param Fragment nullable or not
 * @param View nullable or not
 **/

fun Fragment?.showKeyBoard(view: View) {
    this?.activity?.onShow(view)
}

/**
 * Extension to show keyboard
 * @param Activity nullable or not
 * @param View nullable or not
 **/

fun Activity?.showKeyBoard(view: View) {
    this?.onShow(view)
}

private fun Context.onClose(iBinder: IBinder) {
    this.getSystemService<InputMethodManager>()?.hideSoftInputFromWindow(
        iBinder, HIDDEN
    )
}

private fun Context.onShow(view: View) {
    this.getSystemService<InputMethodManager>()?.showSoftInput(
        view, InputMethodManager.SHOW_IMPLICIT
    )
}