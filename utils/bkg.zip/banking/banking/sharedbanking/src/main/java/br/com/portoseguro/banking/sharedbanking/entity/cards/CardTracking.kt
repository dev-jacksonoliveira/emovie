package br.com.portoseguro.banking.sharedbanking.entity.cards

import androidx.annotation.StringRes
import br.com.portoseguro.banking.sharedbanking.R

enum class CardTracking (val slug: String, @StringRes val resource: Int) {
    IN_PRODUCTION("EM_PRODUCAO", R.string.card_debit_incentive_in_production),
    ON_DELIVERY("EM_ENTREGA", R.string.card_debit_incentive_on_delivery),
    DELIVERED("ENTREGUE", R.string.card_debit_incentive_unlock),
    NOT_DELIVERED("NAO_ENTREGUE", R.string.card_debit_incentive_not_delivery);

    companion object {
        fun getCardTrackingStatus(slug: String?): CardTracking? {
            return values().find { it.slug.lowercase() == slug?.lowercase() }
        }
    }
}