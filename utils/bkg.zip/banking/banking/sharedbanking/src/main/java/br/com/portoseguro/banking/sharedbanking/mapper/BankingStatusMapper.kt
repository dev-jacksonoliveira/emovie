package br.com.portoseguro.banking.sharedbanking.mapper

import br.com.portoseguro.banking.sharedbanking.entity.account.AccountStatusResult
import br.com.portoseguro.banking.sharedbanking.entity.account.AccountStatusType

class BankingStatusMapper {
    operator fun invoke(type: String?): AccountStatusResult {
        return if (type != null) {
            when (type.lowercase()) {
                AccountStatusType.OPEN.slug.lowercase() -> AccountStatusResult.Success(
                    AccountStatusType.OPEN
                )
                AccountStatusType.PENDING_DOCS.slug.lowercase() -> AccountStatusResult.Success(
                    AccountStatusType.PENDING_DOCS
                )
                AccountStatusType.ELIGIBLE.slug.lowercase() -> AccountStatusResult.Success(
                    AccountStatusType.ELIGIBLE
                )
                AccountStatusType.DEBIT_LOCKED.slug.lowercase() -> AccountStatusResult.Success(
                    AccountStatusType.DEBIT_LOCKED
                )
                AccountStatusType.ADMINISTRATIVE_LOCKED.slug.lowercase() -> AccountStatusResult.Success(
                    AccountStatusType.ADMINISTRATIVE_LOCKED
                )
                AccountStatusType.NONE.slug.lowercase() -> AccountStatusResult.Success(
                    AccountStatusType.NONE
                )
                else -> AccountStatusResult.UnrecognizedTypo
            }
        } else {
            AccountStatusResult.NullableTypo
        }
    }
}
