package br.com.portoseguro.banking.sharedbanking.business

import br.com.portoseguro.banking.sharedbanking.repository.BalanceRepository

class BalanceBusiness(private val balanceRepository: BalanceRepository) {

    fun getVisibility(): Boolean = balanceRepository.getBalanceVisibility()

    fun setVisibility(isVisible: Boolean) {
        balanceRepository.setBalanceVisibility(isVisible)
    }

    fun getBalance(): String? = balanceRepository.getBalance()

    fun setBalance(balance: String) = balanceRepository.saveBalance(balance)
}