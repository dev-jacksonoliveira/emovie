package br.com.portoseguro.banking.sharedbanking.tool

import br.com.portoseguro.banking.sharedbanking.R
import br.com.portoseguro.components.genericloadingbutton.GenericLoadingButton

fun GenericLoadingButton.configureEnabled(enabled: Boolean) {
    setButtonState(enabled)
    val (buttonBackgroundResId, buttonTextColorResId) = if (enabled) {
        R.drawable.generic_loading_button_blue_porto_100_background to R.color.white
    } else {
        R.drawable.generic_loading_button_grey_background_disabled to R.color.neutral_color_grey_06
    }
    setBackgroundButton(buttonBackgroundResId)
    setTextColor(buttonTextColorResId)
}

fun GenericLoadingButton.configureLoading(isLoading: Boolean) {
    setLoading(isLoading)
    setButtonState(!isLoading)
}
