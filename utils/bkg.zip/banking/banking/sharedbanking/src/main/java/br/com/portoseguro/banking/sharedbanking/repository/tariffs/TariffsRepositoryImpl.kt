package br.com.portoseguro.banking.sharedbanking.repository.tariffs

import br.com.portoseguro.banking.sharedbanking.data.mapper.tariffs.TariffsMapper
import br.com.portoseguro.banking.sharedbanking.data.remote.TariffsAPI
import br.com.portoseguro.banking.sharedbanking.data.unwrapDataBody
import br.com.portoseguro.banking.sharedbanking.entity.tariffs.TariffData
import br.com.portoseguro.superapp.core.infrastructure.Result
import br.com.portoseguro.superapp.core.infrastructure.SafeApiCaller
import br.com.portoseguro.superapp.core.infrastructure.exceptions.BackendException
import br.com.portoseguro.superapp.core.infrastructure.onError
import br.com.portoseguro.superapp.core.infrastructure.onSuccess
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.transform

internal class TariffsRepositoryImpl(
    private val tariffsAPI: TariffsAPI,
    private val mapper: TariffsMapper,
    private val apiCaller: SafeApiCaller
): TariffsRepository {

    override fun getTariffs(): Flow<List<TariffData>> {
        return flow {
            emit(apiCaller.safeApiCall { tariffsAPI.getTariffs() })
        }.transform { scope ->
            scope.run {
                onSuccess { res ->
                    emit(res.unwrapDataBody().map {
                        mapper.convert(it)
                    })
                }
                onError { launchException(it) }
            }
        }
    }

    private fun launchException(resultError: Result.Error) {
        throw resultError.exception ?: BackendException()
    }
}