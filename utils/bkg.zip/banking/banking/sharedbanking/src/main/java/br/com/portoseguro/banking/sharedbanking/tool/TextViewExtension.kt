package br.com.portoseguro.banking.sharedbanking.tool

import android.text.SpannableString
import android.text.Spanned
import android.text.style.StrikethroughSpan
import android.widget.TextView

fun TextView.setStrikeThrough(message: String?): SpannableString? {
    return if (message == null) null else SpannableString(message).apply {
        setSpan(
            StrikethroughSpan(),
            0,
            message.length,
            Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
        )
    }
}