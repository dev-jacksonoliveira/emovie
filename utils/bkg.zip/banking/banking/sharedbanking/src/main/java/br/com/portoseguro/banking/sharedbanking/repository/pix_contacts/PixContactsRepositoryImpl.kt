package br.com.portoseguro.banking.sharedbanking.repository.pix_contacts

import br.com.portoseguro.banking.sharedbanking.data.mapper.PixContactResponseMapper
import br.com.portoseguro.banking.sharedbanking.data.remote.TransactionLimitAPI
import br.com.portoseguro.banking.sharedbanking.data.unwrapDataBody
import br.com.portoseguro.banking.sharedbanking.entity.pix_contact.PixContactData
import br.com.portoseguro.superapp.core.infrastructure.Result
import br.com.portoseguro.superapp.core.infrastructure.SafeApiCaller
import br.com.portoseguro.superapp.core.infrastructure.exceptions.BackendException
import br.com.portoseguro.superapp.core.infrastructure.onError
import br.com.portoseguro.superapp.core.infrastructure.onSuccess
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.transform

class PixContactsRepositoryImpl(
    private val api: TransactionLimitAPI,
    private val mapper: PixContactResponseMapper,
    private val safeApiCaller: SafeApiCaller
) : PixContactsRepository {

    override fun getContacts(): Flow<List<PixContactData>> {
        return flow {
            emit(safeApiCaller.safeApiCall { api.getPixContacts() })
        }.transform { scope ->
            scope.run {
                onSuccess { res -> emit(res.unwrapDataBody().map { mapper.convert(it) }) }
                onError { launchException(it) }
            }
        }
    }

    private fun launchException(resultError: Result.Error) {
        throw resultError.exception ?: BackendException()
    }
}