package br.com.portoseguro.banking.sharedbanking.enum

enum class BankingHelpRemoteConfigKeys(val key: String) {
    ACCOUNT_URL(BankingHelpRemoteConfigKeys.KEY_ACCOUNT_URL),
    CARD_URL(BankingHelpRemoteConfigKeys.KEY_CARD_URL),
    INSURANCE_URL(BankingHelpRemoteConfigKeys.KEY_INSURANCE_URL),
    PIX_URL(BankingHelpRemoteConfigKeys.KEY_PIX_URL);

    private companion object {
        const val KEY_ACCOUNT_URL = "rc_conta_digital_faq_url"
        const val KEY_CARD_URL = "rc_conta_digital_faq_cartao_debito_url"
        const val KEY_INSURANCE_URL = "rc_conta_digital_faq_seguro_conta_url"
        const val KEY_PIX_URL = "rc_conta_digital_faq_pix_url"
    }
}