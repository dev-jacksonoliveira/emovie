package br.com.portoseguro.banking.sharedbanking.tool

import androidx.lifecycle.LiveDataUpdateListener
import androidx.lifecycle.ViewModel
import dev.kdblib.extensions.LiveDataFactory
import dev.kdblib.extensions.LiveDataSetter
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancelChildren
import kotlinx.coroutines.launch
import kotlin.coroutines.CoroutineContext

open class BaseAccountViewModel(
    private val coroutineContext: CoroutineContext = Dispatchers.Main
) : ViewModel(), LiveDataFactory, LiveDataSetter, LiveDataUpdateListener {

    private val job = Job()
    val viewModelScope = CoroutineScope(coroutineContext + job)

    fun launch(
        context: CoroutineContext = coroutineContext,
        block: suspend CoroutineScope.() -> Unit
    ): Job = viewModelScope.launch(context) { block() }

    override fun onCleared() {
        super.onCleared()
        viewModelScope.coroutineContext.cancelChildren()
    }
}
