package br.com.portoseguro.banking.sharedbanking.repository.tariffs

import br.com.portoseguro.banking.sharedbanking.entity.tariffs.TariffData
import br.com.portoseguro.banking.sharedbanking.entity.tariffs.TariffElement
import kotlinx.coroutines.flow.Flow

interface TariffsRepository {
    fun getTariffs() : Flow<List<TariffData>>
}