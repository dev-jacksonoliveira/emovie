package br.com.portoseguro.banking.sharedbanking.repository

import br.com.portoseguro.banking.sharedbanking.entity.subhome.AccountSummary
import kotlinx.coroutines.flow.Flow

interface SummaryRepository {
    suspend fun getSummary(): Flow<AccountSummary>
    fun getShortcuts(): List<Any>
}