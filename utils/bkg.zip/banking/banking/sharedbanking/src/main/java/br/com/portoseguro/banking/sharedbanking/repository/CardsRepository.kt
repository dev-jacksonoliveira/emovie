package br.com.portoseguro.banking.sharedbanking.repository

import br.com.portoseguro.banking.sharedbanking.entity.cards.delivery.AddressDeliveryCard
import br.com.portoseguro.banking.sharedbanking.entity.subhome.Card
import br.com.portoseguro.superapp.core.infrastructure.Result
import br.com.portoseguro.superapp.core.infrastructure.exceptions.BackendException
import kotlinx.coroutines.flow.Flow

interface CardsRepository {
    fun getCards(): Flow<List<Card>>
    fun getCardById(cardId: String): Flow<Card>
    fun unlockCard(cardId: String, securityCode: String): Flow<Boolean>
    fun unlockCardError(result: Result.Error): Throwable
    fun temporaryLockCard(cardId: String): Flow<Card>
    fun temporaryUnlockCard(cardId: String): Flow<Card>
    fun getAddressDeliveryCard(): Flow<AddressDeliveryCard>
    fun blockCard(cardId: String, statusId: Long): Flow<Boolean>
    fun requestNewCard(password: String, addressDeliveryCard: AddressDeliveryCard): Flow<String>
    fun onRequestCardPasswordError(result: Result.Error): Throwable
}

class RequestCardPasswordInvalid(val errorMessage: String?) : BackendException()

class RequestCardPasswordBlocked(val errorMessage: String?) : BackendException()

class RequestCardFail(val errorMessage: String?) : BackendException()

class RequestCardNew(val errorMessage: String?) : BackendException()

class RequestCardInvalidPassword : BackendException()

class UnlockCard(val errorMessage: String?) : BackendException()

class SetAddressDeliveryCard(val errorMessage: String?) : BackendException()