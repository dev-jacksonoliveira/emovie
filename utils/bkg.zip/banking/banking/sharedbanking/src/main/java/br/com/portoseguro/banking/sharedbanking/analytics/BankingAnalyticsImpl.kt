package br.com.portoseguro.banking.sharedbanking.analytics

import android.app.Activity
import br.com.portoseguro.banking.sharedbanking.presentation.subhome.analytics.SubHomeAnalyticsConstants.Param.SCREEN
import br.com.portoseguro.superapp.core.analytics.Analytics
import br.com.portoseguro.superapp.core.analytics.model.Action
import br.com.portoseguro.superapp.core.analytics.model.ActionAlert
import br.com.portoseguro.superapp.core.analytics.model.ActionError
import br.com.portoseguro.superapp.core.analytics.model.ViewItem
import br.com.portoseguro.superapp.core.analytics.utils.AnalyticsConstants.Param.APP_SUB_SECTION_1
import br.com.portoseguro.superapp.core.analytics.utils.AnalyticsConstants.Param.APP_SUB_SECTION_2
import br.com.portoseguro.superapp.core.analytics.utils.AnalyticsConstants.Param.APP_SUB_SECTION_3
import br.com.portoseguro.superapp.core.analytics.utils.AnalyticsConstants.Param.EV_LABEL
import br.com.portoseguro.superapp.core.analytics.utils.AnalyticsConstants.Param.PRODUCT
import br.com.portoseguro.superapp.core.analytics.utils.AnalyticsConstants.Param.PRODUCT_IDENTIFY
import br.com.portoseguro.superapp.core.analytics.utils.AnalyticsInterface

class BankingAnalyticsImpl(
    private val analytics: Analytics
) : BankingAnalytics {
    override fun trackScreenView(
        activity: Activity,
        screen: String,
        itemName: String,
        section: String,
        product: String,
        productIdentify: String?,
        subSection1: String?,
        subSection2: String?,
        subSection3: String?
    ) {
        val viewItem = ViewItem(
            activity = activity,
            appSection = section,
            itemName = itemName,
        ).apply {
            addExtraParams(
                productIdentify = productIdentify,
                screen = screen,
                subSection1 = subSection1,
                subSection2 = subSection2,
                subSection3 = subSection3,
                product = product
            )
        }
        analytics.trackViewItem(viewItem)
    }

    override fun trackAction(
        action: String,
        itemName: String,
        section: String,
        product: String,
        category: String,
        productIdentify: String?,
        label: String?,
        subSection1: String?,
        subSection2: String?,
        subSection3: String?
    ) {
        val act = Action(
            appSection = section,
            evCategory = category,
            evAction = action,
            itemName = itemName
        ).apply {
            addExtraParams(
                productIdentify = productIdentify,
                label = label,
                subSection1 = subSection1,
                subSection2 = subSection2,
                subSection3 = subSection3,
                product = product
            )
        }

        analytics.trackAction(act)
    }

    override fun trackAlert(
        action: String,
        alert: String,
        itemName: String,
        section: String,
        product: String,
        category: String,
        productIdentify: String?,
        subSection1: String?,
        subSection2: String?,
        subSection3: String?
    ) {
        val actionAlert = ActionAlert(
            evAction = action,
            alert = alert,
            itemName = itemName,
            appSection = section,
            evCategory = category
        ).apply {
            addExtraParams(
                productIdentify = productIdentify,
                subSection1 = subSection1,
                subSection2 = subSection2,
                subSection3 = subSection3,
                product = product
            )
        }

        analytics.trackActionAlert(actionAlert)
    }

    override fun trackError(
        error: String,
        action: String,
        itemName: String,
        section: String,
        product: String,
        category: String,
        productIdentify: String?,
        subSection1: String?,
        subSection2: String?,
        subSection3: String?
    ) {
        val actionError = ActionError(
            appSection = section,
            errorMessage = error,
            evCategory = category,
            evAction = action,
            itemName = itemName
        ).apply {
            addExtraParams(
                productIdentify = productIdentify,
                subSection1 = subSection1,
                subSection2 = subSection2,
                subSection3 = subSection3,
                product = product
            )
        }

        analytics.trackActionError(actionError)
    }

    private fun <T> AnalyticsInterface.Model<T>.addExtraParams(
        screen: String? = null,
        product: String? = null,
        productIdentify: String? = null,
        subSection1: String? = null,
        subSection2: String? = null,
        subSection3: String? = null,
        label: String? = null
    ) {
        screen?.let { add(key = SCREEN, value = it) }
        subSection1?.let { add(key = APP_SUB_SECTION_1, value = it) }
        subSection2?.let { add(key = APP_SUB_SECTION_2, value = it) }
        subSection3?.let { add(key = APP_SUB_SECTION_3, value = it) }
        productIdentify?.let { add(key = PRODUCT_IDENTIFY, value = it) }
        product?.let { add(key = PRODUCT, value = it) }
        label?.let {add(key = EV_LABEL, value = it)  }
    }
}
