package br.com.portoseguro.banking.sharedbanking.enum

enum class PasswordBusinessErrorType(val field: String) {
    PASSWORD_INVALID("SENHA_INVALIDA"),
    PASSWORD_BLOCKED("SENHA_BLOQUEADA")
}