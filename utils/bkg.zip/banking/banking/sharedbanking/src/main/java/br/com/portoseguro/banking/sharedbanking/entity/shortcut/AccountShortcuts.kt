package br.com.portoseguro.banking.sharedbanking.entity.shortcut

sealed interface AccountShortcuts : BankingShortcutType {

    sealed interface Shortcut : AccountShortcuts {
        object Pix : Shortcut
        object Extract : Shortcut
        object PayBill : Shortcut
        object CashOut : Shortcut
    }

    sealed interface OtherService : AccountShortcuts {
        object FirstDebitCard : OtherService
        object DebitCard : OtherService
        object SecurityAccount : OtherService
        object CheckOrChangePassword : OtherService
        object MyRegistrationData : OtherService
        object Tariffs : OtherService
        object Help : OtherService
    }
}