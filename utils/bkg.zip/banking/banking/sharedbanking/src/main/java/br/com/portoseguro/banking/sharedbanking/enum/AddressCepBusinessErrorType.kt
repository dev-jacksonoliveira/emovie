package br.com.portoseguro.banking.sharedbanking.enum

enum class AddressCepBusinessErrorType(val field: String) {
    CEP_NOT_FOUND("CEP_NAO_ENCONTRADO"),
    CEP_INVALID("CEP_INVALIDO")
}