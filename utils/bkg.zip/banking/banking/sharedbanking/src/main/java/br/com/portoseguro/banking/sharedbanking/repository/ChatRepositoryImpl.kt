package br.com.portoseguro.banking.sharedbanking.repository

import br.com.portoseguro.banking.sharedbanking.data.remote.ChatAPI
import br.com.portoseguro.sharedentity.banking.request.ChatPixRequest
import br.com.portoseguro.sharedentity.banking.response.ChatPixResponse
import br.com.portoseguro.sharedentity.core.response.BackendWrappedResponse
import retrofit2.Response

internal class ChatRepositoryImpl(private val chatAPI: ChatAPI) : ChatRepository {

    override suspend fun getPixChat(
        presentationName: String
    ): Response<BackendWrappedResponse<ChatPixResponse>> = ChatPixRequest(
        presentationName
    ).let { body ->
        chatAPI.pixChat(body)
    }
}