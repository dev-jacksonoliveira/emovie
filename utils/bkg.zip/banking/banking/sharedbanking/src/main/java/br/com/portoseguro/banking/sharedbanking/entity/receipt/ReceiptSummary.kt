package br.com.portoseguro.banking.sharedbanking.entity.receipt

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class ReceiptSummary(
    val paymentDate: String,
    val value: String,
    val name: String,
    val statusTransaction: String
): Parcelable
