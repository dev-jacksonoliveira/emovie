package br.com.portoseguro.banking.sharedbanking.enum

enum class BankingBiometryFlowType(val flow: String) {
    HARD_REGISTRATION("CADASTRO_HARD"),
    EMBEDDED_LOGIN_TOKEN("LOGIN_TOKEN_EMBARCADO")
}