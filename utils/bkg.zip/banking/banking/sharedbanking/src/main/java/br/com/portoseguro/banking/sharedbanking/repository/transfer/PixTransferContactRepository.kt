package br.com.portoseguro.banking.sharedbanking.repository.transfer

import br.com.portoseguro.banking.sharedbanking.entity.transfer.PixTransferContactData
import kotlinx.coroutines.flow.Flow


interface PixTransferContactRepository {
    fun getTransferContactsList(): Flow<List<PixTransferContactData>>
}