package br.com.portoseguro.banking.sharedbanking.repository

import br.com.portoseguro.banking.sharedbanking.entity.extract.Extract
import kotlinx.coroutines.flow.Flow

interface ExtractRepository {
    fun getExtracts() : Flow<List<Extract>>
}