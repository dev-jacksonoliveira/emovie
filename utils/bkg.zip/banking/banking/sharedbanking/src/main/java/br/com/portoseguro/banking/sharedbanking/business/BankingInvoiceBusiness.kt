package br.com.portoseguro.banking.sharedbanking.business

import br.com.portoseguro.banking.sharedbanking.entity.invoice.InvoiceData
import br.com.portoseguro.banking.sharedbanking.repository.invoice.InvoiceRepository
import kotlinx.coroutines.flow.Flow

class BankingInvoiceBusiness(
    private val invoiceRepository: InvoiceRepository
) {

    fun getInvoice(invoiceCode: String): Flow<InvoiceData> =
        invoiceRepository.getInvoice(invoiceCode)

    fun isScheduleInvoiceAvailable(): Boolean =
        invoiceRepository.isScheduleInvoiceAvailable()
}