package br.com.portoseguro.banking.sharedbanking.business

import br.com.portoseguro.banking.sharedbanking.entity.cards.CardStatus
import br.com.portoseguro.banking.sharedbanking.entity.cards.block.BlockCardResult
import br.com.portoseguro.banking.sharedbanking.entity.cards.exception.CardsException
import br.com.portoseguro.banking.sharedbanking.entity.cards.exception.IncorrectSecurityCodeException
import br.com.portoseguro.banking.sharedbanking.entity.cards.lock_unlock.TemporaryLockUnlockCardResult
import br.com.portoseguro.banking.sharedbanking.entity.cards.unlock.UnlockCardResult
import br.com.portoseguro.banking.sharedbanking.entity.shortcut.CardShortcuts
import br.com.portoseguro.banking.sharedbanking.entity.subhome.Card
import br.com.portoseguro.banking.sharedbanking.repository.BankCrypto
import br.com.portoseguro.banking.sharedbanking.repository.CardShortcutRepository
import br.com.portoseguro.banking.sharedbanking.repository.CardsRepository
import br.com.portoseguro.superapp.core.infrastructure.exceptions.BackendException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.lastOrNull
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.transform

class CardBusiness(
    private val cardsRepository: CardsRepository,
    private val cardShortcutRepository: CardShortcutRepository,
    private val bankCrypto: BankCrypto
) {

    fun getCards(): Flow<List<Card>> = cardsRepository.getCards()

    fun getFirstCard(): Flow<Card> {
        return getCards().transform { cards -> emit(cards.first()) }
    }

    fun getCardById(cardId: String): Flow<Card> {
        return cardsRepository.getCardById(cardId)
    }

    fun lockUnlockFirstCard(): Flow<TemporaryLockUnlockCardResult> {
        return flow {
            getFirstCard().lastOrNull()?.let { card ->
                when (card.cardStatus) {
                    CardStatus.TEMPORARY_BLOCKED -> {
                        emitAll(cardsRepository.temporaryUnlockCard(card.cardId)
                            .map { TemporaryLockUnlockCardResult.Success(it) })
                    }
                    CardStatus.VALID -> {
                        emitAll(cardsRepository.temporaryLockCard(card.cardId)
                            .map { TemporaryLockUnlockCardResult.Success(it) })
                    }
                    else -> {
                        emit(TemporaryLockUnlockCardResult.TryAgain())
                    }
                }
            } ?: emit(TemporaryLockUnlockCardResult.TryAgain())
        }
    }

    fun unlockCardBySecurityCode(
        cardId: String,
        securityCode: String
    ): Flow<UnlockCardResult> {
        return flow {
            cardsRepository.unlockCard(cardId, bankCrypto.encryptSecurityCode(securityCode))
                .catch { error ->
                    emit(
                        when (error) {
                            is IncorrectSecurityCodeException -> UnlockCardResult.IncorrectSecurityCode(error.cvvErrorMessage)
                            is CardsException,
                            is BackendException -> UnlockCardResult.TryAgain(error.message)
                            else -> throw error
                        }
                    )
                }
                .collect { emit(UnlockCardResult.Success) }
        }
    }

    fun getCardShortcuts(): List<CardShortcuts> = cardShortcutRepository.getShortcuts()

    fun blockCard(
        cardId: String,
        statusId: Long
    ): Flow<BlockCardResult> {
        return flow {
            cardsRepository.blockCard(cardId, statusId)
                .catch { error ->
                    emit(
                        when (error) {
                            is CardsException,
                            is BackendException -> BlockCardResult.TryAgain(error.message)
                            else -> throw error
                        }
                    )
                }
                .collect { emit(BlockCardResult.Success) }
        }
    }
}