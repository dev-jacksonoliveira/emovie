package br.com.portoseguro.banking.sharedbanking.entity.extract

data class ExtractModel(
    val id: String,
    val type: ExtractModelType,
    val category: ExtractCategory,
    val icon: String,
    val title: String?,
    val value: String?,
    val date: String?,
    val description: String?,
    val isScheduled: Boolean = false,
    val isRefunded: Boolean = false,
    val isCancelled: Boolean = false,
    val cancelButton: ExtractButtonAction? = null,
    val scheduleDate: String,
    val document: String?,
    val institutionName: String?,
    val isClickEnabled: Boolean = true,
    val resume: ExtractResume?,
    val idCancellation: String?
)