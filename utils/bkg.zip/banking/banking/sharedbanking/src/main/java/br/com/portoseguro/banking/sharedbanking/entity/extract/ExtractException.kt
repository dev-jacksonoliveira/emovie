package br.com.portoseguro.banking.sharedbanking.entity.extract

import br.com.portoseguro.superapp.core.infrastructure.exceptions.BackendException

data class ExtractException(val code: Int?) : BackendException()