package br.com.portoseguro.banking.sharedbanking.repository.biometry

import br.com.portoseguro.superapp.core.toggle.FeatureToggle

internal class BiometryRepositoryImpl(
    private val featureToggle: FeatureToggle
) : BiometryRepository {

    override fun authfyIsEnabled(): Boolean = featureToggle.getValue(AUTHFY_KEY)

    companion object {
        const val AUTHFY_KEY = "embedded_token_banking_android"
    }
}
