package br.com.portoseguro.banking.sharedbanking.di

import android.app.Activity
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import b.c.p.u.u.b
import br.com.portoseguro.banking.sharedbanking.analytics.BankingAnalytics
import br.com.portoseguro.banking.sharedbanking.analytics.BankingAnalyticsImpl
import br.com.portoseguro.banking.sharedbanking.analytics.summary.SummaryAnalytics
import br.com.portoseguro.banking.sharedbanking.analytics.summary.SummaryAnalyticsImpl
import br.com.portoseguro.banking.sharedbanking.business.BalanceBusiness
import br.com.portoseguro.banking.sharedbanking.business.BankingBusiness
import br.com.portoseguro.banking.sharedbanking.business.BiometryBusiness
import br.com.portoseguro.banking.sharedbanking.business.CancelTransactionBusiness
import br.com.portoseguro.banking.sharedbanking.business.CardBusiness
import br.com.portoseguro.banking.sharedbanking.business.ChatBusiness
import br.com.portoseguro.banking.sharedbanking.business.ExtractBusiness
import br.com.portoseguro.banking.sharedbanking.business.MyRegistrationUpdateBusiness
import br.com.portoseguro.banking.sharedbanking.business.MyRegistrationUpdateBusinessImpl
import br.com.portoseguro.banking.sharedbanking.business.ReceiptBusiness
import br.com.portoseguro.banking.sharedbanking.business.SubHomeHeaderInteractor
import br.com.portoseguro.banking.sharedbanking.business.TariffsBusinessImpl
import br.com.portoseguro.banking.sharedbanking.business.TariffsBusiness
import br.com.portoseguro.banking.sharedbanking.business.help.BankingHelpBusiness
import br.com.portoseguro.banking.sharedbanking.business.help.BankingHelpBusinessImpl
import br.com.portoseguro.banking.sharedbanking.data.mapper.AddressCepMapper
import br.com.portoseguro.banking.sharedbanking.data.mapper.AddressCepMapperImpl
import br.com.portoseguro.banking.sharedbanking.data.mapper.HelpRouterImpl
import br.com.portoseguro.banking.sharedbanking.data.mapper.NewCardMapper
import br.com.portoseguro.banking.sharedbanking.data.mapper.NewCardMapperImpl
import br.com.portoseguro.banking.sharedbanking.data.mapper.help.BankingHelpResponseMapper
import br.com.portoseguro.banking.sharedbanking.data.mapper.help.BankingHelpResponseMapperImpl
import br.com.portoseguro.banking.sharedbanking.data.mapper.registration.MyRegistrationUpdateRequestMapper
import br.com.portoseguro.banking.sharedbanking.data.mapper.registration.MyRegistrationUpdateRequestMapperImpl
import br.com.portoseguro.banking.sharedbanking.data.mapper.registration.MyRegistrationUpdateResponseMapper
import br.com.portoseguro.banking.sharedbanking.data.mapper.registration.MyRegistrationUpdateResponseMapperImpl
import br.com.portoseguro.banking.sharedbanking.data.mapper.tariffs.TariffsMapper
import br.com.portoseguro.banking.sharedbanking.data.mapper.tariffs.TariffsMapperImpl
import br.com.portoseguro.banking.sharedbanking.data.remote.HelpAPI
import br.com.portoseguro.banking.sharedbanking.data.remote.MyRegistrationAPI
import br.com.portoseguro.banking.sharedbanking.entity.receipt.ReceiptData
import br.com.portoseguro.banking.sharedbanking.mapper.ExtractMapper
import br.com.portoseguro.banking.sharedbanking.mapper.ReceiptMapper
import br.com.portoseguro.banking.sharedbanking.presentation.address.AddressViewModel
import br.com.portoseguro.banking.sharedbanking.presentation.balance.BalanceViewModel
import br.com.portoseguro.banking.sharedbanking.presentation.balance.SharedSummaryViewModel
import br.com.portoseguro.banking.sharedbanking.presentation.chat.ChatPixNavigation
import br.com.portoseguro.banking.sharedbanking.presentation.chat.ChatPixNavigationImpl
import br.com.portoseguro.banking.sharedbanking.presentation.chat.ChatPixViewModel
import br.com.portoseguro.banking.sharedbanking.presentation.error.ErrorAttemptViewModel
import br.com.portoseguro.banking.sharedbanking.presentation.error.ErrorResourceProvider
import br.com.portoseguro.banking.sharedbanking.presentation.error.ErrorResourceProviderImpl
import br.com.portoseguro.banking.sharedbanking.presentation.extract.ExtractModelMapper
import br.com.portoseguro.banking.sharedbanking.presentation.extract.ExtractRouterImpl
import br.com.portoseguro.banking.sharedbanking.presentation.extract.ExtractViewModel
import br.com.portoseguro.banking.sharedbanking.presentation.header.card.CardResourceProvider
import br.com.portoseguro.banking.sharedbanking.presentation.header.card.CardResourceProviderImpl
import br.com.portoseguro.banking.sharedbanking.presentation.header.card.HeaderVisaCardViewModel
import br.com.portoseguro.banking.sharedbanking.presentation.permision.CameraPermissionResult
import br.com.portoseguro.banking.sharedbanking.presentation.permission.CameraPermissionResultManager
import br.com.portoseguro.banking.sharedbanking.presentation.permission.CameraPermissionResultManagerImpl
import br.com.portoseguro.banking.sharedbanking.presentation.receipt.ReceiptItemsMapper
import br.com.portoseguro.banking.sharedbanking.presentation.receipt.ReceiptViewModel
import br.com.portoseguro.banking.sharedbanking.presentation.resource.ErrorGenericResourceProvider
import br.com.portoseguro.banking.sharedbanking.presentation.resource.ErrorGenericResourceProviderImpl
import br.com.portoseguro.banking.sharedbanking.presentation.shortcut.SharedGenerateShortcut
import br.com.portoseguro.banking.sharedbanking.presentation.subhome.SubHomeAction
import br.com.portoseguro.banking.sharedbanking.presentation.subhome.analytics.SubHomeAnalytics
import br.com.portoseguro.banking.sharedbanking.presentation.subhome.analytics.SubHomeAnalyticsImpl
import br.com.portoseguro.banking.sharedbanking.presentation.subhome.incentive.resource.IncentiveResourceProvider
import br.com.portoseguro.banking.sharedbanking.presentation.subhome.incentive.resource.IncentiveResourceProviderImpl
import br.com.portoseguro.banking.sharedbanking.presentation.summary.ActionCancelViewModel
import br.com.portoseguro.banking.sharedbanking.presentation.summary.TransactionSummaryViewModel
import br.com.portoseguro.banking.sharedbanking.repository.BalanceRepository
import br.com.portoseguro.banking.sharedbanking.repository.BalanceRepositoryImpl
import br.com.portoseguro.banking.sharedbanking.repository.BankCrypto
import br.com.portoseguro.banking.sharedbanking.repository.BankCryptoImpl
import br.com.portoseguro.banking.sharedbanking.repository.CancelTransactionRepository
import br.com.portoseguro.banking.sharedbanking.repository.CancelTransactionRepositoryImpl
import br.com.portoseguro.banking.sharedbanking.repository.ChatRepository
import br.com.portoseguro.banking.sharedbanking.repository.ChatRepositoryImpl
import br.com.portoseguro.banking.sharedbanking.repository.ExtractRepository
import br.com.portoseguro.banking.sharedbanking.repository.ExtractRepositoryImpl
import br.com.portoseguro.banking.sharedbanking.repository.MyRegistrationUpdateRepository
import br.com.portoseguro.banking.sharedbanking.repository.MyRegistrationUpdateRepositoryImpl
import br.com.portoseguro.banking.sharedbanking.repository.RefundRepository
import br.com.portoseguro.banking.sharedbanking.repository.RefundRepositoryImpl
import br.com.portoseguro.banking.sharedbanking.repository.address.AddressCepRepository
import br.com.portoseguro.banking.sharedbanking.repository.address.AddressCepRepositoryImpl
import br.com.portoseguro.banking.sharedbanking.repository.biometry.BiometryRepository
import br.com.portoseguro.banking.sharedbanking.repository.biometry.BiometryRepositoryImpl
import br.com.portoseguro.banking.sharedbanking.repository.biometry.BiometryRepositoryImpl.Companion.AUTHFY_KEY
import br.com.portoseguro.banking.sharedbanking.repository.help.BankingHelpRepository
import br.com.portoseguro.banking.sharedbanking.repository.help.BankingHelpRepositoryImpl
import br.com.portoseguro.banking.sharedbanking.repository.receipt.ReceiptRepository
import br.com.portoseguro.banking.sharedbanking.repository.receipt.ReceiptRepositoryImpl
import br.com.portoseguro.banking.sharedbanking.repository.tariffs.TariffsRepository
import br.com.portoseguro.banking.sharedbanking.repository.tariffs.TariffsRepositoryImpl
import br.com.portoseguro.banking.sharedbanking.system.permission.plugin.PermissionPlugin
import br.com.portoseguro.banking.sharedbanking.system.permission.plugin.PermissionPluginImpl
import br.com.portoseguro.banking.sharedbanking.system.permission.processor.PermissionProcessorImpl
import br.com.portoseguro.banking.sharedbanking.system.permission.strategy.StartForResultStrategy
import br.com.portoseguro.banking.sharedbanking.system.permission.strategy.StartForResultStrategyImpl
import br.com.portoseguro.banking.sharedbanking.tool.PermissionsViewModel
import br.com.portoseguro.permission.infrastructure.processor.PermissionProcessor
import br.com.portoseguro.superapp.core.api.moshi.MoshiHttp
import br.com.portoseguro.superapp.core.api.moshi.create
import br.com.portoseguro.superapp.core.toggle.FeatureToggle
import br.com.portoseguro.superapp.router.banking.ExtractRouter
import br.com.portoseguro.superapp.router.help.HelpRouter
import org.koin.androidx.viewmodel.dsl.viewModel
import org.koin.core.context.loadKoinModules
import org.koin.core.module.Module
import org.koin.core.parameter.parametersOf
import org.koin.dsl.module

fun loadSharedBankingModules() = lazyLoadSharedBankingModules

private val lazyLoadSharedBankingModules by lazy { loadKoinModules(sharedBankingModule) }

private val sharedBankingModule = module {
    repository()
    business()
    router()
    presentation()
    permission()
    analytics()
    addApis()
    help()
}

fun Module.repository() {

    factory {
        val toggle: FeatureToggle = get()
        toggle.addDefaultValues(getDefaultFeatureToggle())
    }

    factory<ExtractRepository> {
        ExtractRepositoryImpl(
            extractAPI = get<MoshiHttp>().create(),
            apiCaller = get(),
            mapper = ExtractMapper()
        )
    }
    factory<RefundRepository> { RefundRepositoryImpl(refundAPI = get<MoshiHttp>().create()) }
    factory<CancelTransactionRepository> {
        CancelTransactionRepositoryImpl(cancelTransactionAPI = get<MoshiHttp>().create())
    }
    factory<BalanceRepository> { BalanceRepositoryImpl(dataRepository = get()) }
    factory<ReceiptRepository> {
        ReceiptRepositoryImpl(
            receiptAPI = get<MoshiHttp>().create(),
            apiCaller = get(),
            mapper = ReceiptMapper()
        )
    }
    factory<ChatRepository> { ChatRepositoryImpl(chatAPI = get<MoshiHttp>().create()) }
    factory<BiometryRepository> { BiometryRepositoryImpl(featureToggle = get()) }
    factory<AddressCepRepository> {
        AddressCepRepositoryImpl(
            myRegistrationAPI = get(),
            safeApiCaller = get(),
            addressCepMapper = get(),
            provider = get(),
            remoteConfigRepository = get()
        )
    }
    factory<MyRegistrationUpdateRepository> {
        MyRegistrationUpdateRepositoryImpl(
            myRegistrationAPI = get(),
            safeApiCaller = get(),
            requestMapper = get(),
            responseMapper = get()
        )
    }
    factory<TariffsRepository> {
        TariffsRepositoryImpl(
            tariffsAPI = get<MoshiHttp>().create(),
            apiCaller = get(),
            mapper = get()
        )
    }
}

fun Module.business() {
    factory {
        BankingBusiness(
            bankingRepository = get(),
            summaryRepository = get(),
            mapper = get()
        )
    }
    factory { BalanceBusiness(balanceRepository = get()) }
    factory {
        CardBusiness(cardsRepository = get(), cardShortcutRepository = get(), bankCrypto = get())
    }
    factory { SubHomeHeaderInteractor(bankingBusiness = get(), cardBusiness = get()) }
    factory { ExtractBusiness(extractRepository = get()) }
    factory { ReceiptBusiness(receiptRepository = get()) }
    factory { CancelTransactionBusiness(apiCaller = get(), cancelTransactionRepository = get()) }
    factory {
        ChatBusiness(
            safeApiCaller = get(),
            chatRepository = get(),
            userDataPersistenceRepository = get()
        )
    }
    factory { BiometryBusiness(biometryRepository = get()) }
    factory<MyRegistrationUpdateBusiness> {
        MyRegistrationUpdateBusinessImpl(
            repository = get()
        )
    }
    factory<TariffsBusiness> { TariffsBusinessImpl(tariffsRepository = get())}
}

private fun Module.presentation() {
    viewModel { (bundle: Bundle?) ->
        BalanceViewModel(
            savedInstance = bundle,
            balanceBusiness = get(),
            resourceProvider = get()
        )
    }
    viewModel { (bundle: Bundle?) -> ErrorAttemptViewModel(savedInstance = bundle) }
    viewModel { (action: SubHomeAction) ->
        SharedSummaryViewModel(
            subHomeAction = action,
            interactor = get(),
            analytics = get()
        )
    }
    factory<CardResourceProvider> { CardResourceProviderImpl(resourceProvider = get()) }
    viewModel { HeaderVisaCardViewModel(cardResourceProvider = get()) }
    factory<IncentiveResourceProvider> { IncentiveResourceProviderImpl(resourceProvider = get()) }
    factory<ErrorGenericResourceProvider> { ErrorGenericResourceProviderImpl(resourceProvider = get()) }
    factory<ErrorResourceProvider> { ErrorResourceProviderImpl(resourceProvider = get()) }
    factory { SharedGenerateShortcut(resourceProvider = get()) }
    factory<BankCrypto> { BankCryptoImpl(crypto = b()) }
    factory { ExtractModelMapper(resourceProvider = get()) }
    viewModel { ExtractViewModel(extractBusiness = get(), extractModelMapper = get()) }
    viewModel { TransactionSummaryViewModel(resourceProvider = get()) }
    viewModel { (transactionId: String, receiptData: ReceiptData?) ->
        ReceiptViewModel(
            receiptData = receiptData,
            transactionId = transactionId,
            receiptBusiness = get(),
            mapper = ReceiptItemsMapper()
        )
    }
    viewModel { (id: String, category: String, idCancelattion: String? ) ->
        ActionCancelViewModel(
            id = id,
            category = category,
            idCancellation = idCancelattion.orEmpty(),
            cancelTransactionBusiness = get()
        )
    }

    viewModel { ChatPixViewModel(chatBusiness = get(), errorGenericResourceProvider = get()) }
    factory<NewCardMapper> { NewCardMapperImpl(crypto = get()) }
    factory<AddressCepMapper> { AddressCepMapperImpl() }
    factory<MyRegistrationUpdateResponseMapper> {
        MyRegistrationUpdateResponseMapperImpl()
    }
    factory<MyRegistrationUpdateRequestMapper> {
        MyRegistrationUpdateRequestMapperImpl(
            bankCrypto = get()
        )
    }
    viewModel { AddressViewModel(addressCepRepository = get(), business = get()) }
    factory<TariffsMapper>{ TariffsMapperImpl()  }
}

private fun Module.router() {
    factory<ExtractRouter> { ExtractRouterImpl() }
    factory<ChatPixNavigation> { ChatPixNavigationImpl() }
    factory<HelpRouter> { HelpRouterImpl() }
}

fun Module.permission() {
    factory<PermissionPlugin> { (activity: Activity) ->
        PermissionPluginImpl(activity)
    }
    factory<PermissionProcessor> { (activity: Activity) ->
        PermissionProcessorImpl(plugin = get { parametersOf(activity) })
    }
    factory<StartForResultStrategy> { StartForResultStrategyImpl() }
    factory<CameraPermissionResultManager>
    { (
          activity: AppCompatActivity,
          result: CameraPermissionResult
      ) ->
        CameraPermissionResultManagerImpl(
            activity = activity,
            cameraPermissionResult = result,
            startForResultStrategy = get(),
            settingsRouter = get()
        )
    }
    viewModel { PermissionsViewModel() }
}

fun Module.analytics() {
    factory<BankingAnalytics> { BankingAnalyticsImpl(analytics = get()) }
    factory<SubHomeAnalytics> { SubHomeAnalyticsImpl(analytics = get(), clientHashMemory = get()) }
    factory<SummaryAnalytics> { SummaryAnalyticsImpl(analytics = get()) }
}

private fun Module.addApis() {
    single<MyRegistrationAPI> { get<MoshiHttp>().create() }
}

private fun Module.help() {
    factory { get<MoshiHttp>().create<HelpAPI>() }
    factory<BankingHelpRepository> {
        BankingHelpRepositoryImpl(
            safeApiCaller = get(),
            helpAPI = get(),
            helpResponseMapper = get()
        )
    }
    factory<BankingHelpResponseMapper> { BankingHelpResponseMapperImpl() }
    factory<BankingHelpBusiness> { BankingHelpBusinessImpl(helpRepository = get()) }
}

private fun getDefaultFeatureToggle(): Map<String, Boolean> {
    return mapOf(AUTHFY_KEY to false)
}