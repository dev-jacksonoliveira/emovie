package br.com.portoseguro.banking.sharedbanking.entity.shortcut

sealed interface PixShortcuts : BankingShortcutType {

    sealed interface Shortcut : PixShortcuts {
        object Transfer: Shortcut
        object Receive: Shortcut
        object QrCode: Shortcut
        object PixCopyPaste: Shortcut
    }

    sealed interface OtherServices: PixShortcuts {
        object MyLimits : OtherServices
        object MyKeys : OtherServices
        object Help: OtherServices
    }
}