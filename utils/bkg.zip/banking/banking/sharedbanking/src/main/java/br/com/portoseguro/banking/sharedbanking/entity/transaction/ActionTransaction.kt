package br.com.portoseguro.banking.sharedbanking.entity.transaction

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class ActionTransaction(
    val icon: String,
    val title: String,
    val description: String? = null
) : Parcelable
