package br.com.portoseguro.banking.sharedbanking.entity.tariffs

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class TariffElement(
    val elements: List<TariffData>
) : Parcelable
