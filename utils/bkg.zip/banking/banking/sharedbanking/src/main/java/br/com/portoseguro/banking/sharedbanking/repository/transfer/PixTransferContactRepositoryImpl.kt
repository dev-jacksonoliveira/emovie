package br.com.portoseguro.banking.sharedbanking.repository.transfer

import br.com.portoseguro.banking.sharedbanking.data.mapper.PixTransferContactResponseMapper
import br.com.portoseguro.banking.sharedbanking.data.remote.TransactionLimitAPI
import br.com.portoseguro.banking.sharedbanking.data.unwrapDataBody
import br.com.portoseguro.banking.sharedbanking.entity.transfer.PixTransferContactData
import br.com.portoseguro.superapp.core.infrastructure.SafeApiCaller
import br.com.portoseguro.superapp.core.infrastructure.onError
import br.com.portoseguro.superapp.core.infrastructure.onSuccess
import br.com.portoseguro.superapp.core.infrastructure.Result
import br.com.portoseguro.superapp.core.infrastructure.exceptions.BackendException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.transform

class PixTransferContactRepositoryImpl(
    private val api: TransactionLimitAPI,
    private val mapper: PixTransferContactResponseMapper,
    private val safeApiCaller: SafeApiCaller
) : PixTransferContactRepository {

    override fun getTransferContactsList(): Flow<List<PixTransferContactData>> {
        return flow {
            emit(safeApiCaller.safeApiCall { api.getTransferContactList() })
        }.transform { scope ->
            scope.run {
                onSuccess { res -> emit(res.unwrapDataBody().map { mapper.convert(it) }) }
                onError { launchException(it) }
            }
        }
    }

    private fun launchException(resulError: Result.Error ) {
        throw resulError.exception ?: BackendException()
    }
}