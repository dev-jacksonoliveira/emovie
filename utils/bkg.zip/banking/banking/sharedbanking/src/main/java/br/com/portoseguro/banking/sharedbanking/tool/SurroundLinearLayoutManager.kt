package br.com.portoseguro.banking.sharedbanking.tool

import android.content.Context
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

/**
 * Solution exception: java.lang.IndexOutOfBoundsException: Inconsistency detected.
 * Invalid view holder adapter positionViewHolder
 * @link https://issuetracker.google.com/issues/37030377#comment10
 * */
class SurroundLinearLayoutManager(
    val context: Context?
) : LinearLayoutManager(context, RecyclerView.VERTICAL, false) {

    override fun onLayoutChildren(recycler: RecyclerView.Recycler?, state: RecyclerView.State?) {
        try {
            super.onLayoutChildren(recycler, state)
        } catch (e: IndexOutOfBoundsException) {
            // Nothing to do here
        }
    }
}
