package br.com.portoseguro.banking.sharedbanking.embedded_token

import android.content.Context
import android.content.Intent

interface BankingAuthfyConfig {
    operator fun invoke(context: Context): Intent
}
