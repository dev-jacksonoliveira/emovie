package br.com.portoseguro.banking.sharedbanking.presentation

import android.os.Bundle
import android.util.DisplayMetrics
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import br.com.portoseguro.banking.sharedbanking.R
import br.com.portoseguro.banking.sharedbanking.databinding.BottomSheetPasswordRequestBinding
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment

class RequestPasswordBottomSheet : BottomSheetDialogFragment() {

    private var _binding: BottomSheetPasswordRequestBinding? = null
    private val binding: BottomSheetPasswordRequestBinding get() = _binding!!

    var onConfirmPassword: ((password: String) -> Unit)? = null

    override fun getTheme(): Int = R.style.BottomSheetDialogRoundedWithVerticalAnimationTheme

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = BottomSheetPasswordRequestBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupView()
        setupListeners()
    }

    private fun setupView() {
        dialog?.setOnShowListener { it ->
            val dialog = it as BottomSheetDialog
            dialog.behavior.state = BottomSheetBehavior.STATE_EXPANDED
        }
        setupField()
    }

    private fun setupField() = with(binding.inputPasswordField) {
        adjustLayoutWidth(getLayoutWidth())
        resetFieldsRequestFocus()
        setFocus()
        configureFieldBackground(false)
        setOnFinishWriting { successColor() }
        setPasswordTransformation()
    }

    private fun setupListeners() {
        binding.passwordPortoButtonText.clickAction = {
            onConfirmPassword?.invoke(binding.inputPasswordField.getText())
            dismiss()
        }
        binding.icClose.setOnClickListener {
            dismiss()
        }
    }

    private fun getLayoutWidth(): Int {
        val displayMetrics = DisplayMetrics()
        val layoutTotalLeftRightMargin =
            resources.getDimensionPixelSize(R.dimen.code_field_nano_width)
        requireActivity().window?.windowManager?.defaultDisplay?.getMetrics(displayMetrics)
        return displayMetrics.widthPixels - layoutTotalLeftRightMargin
    }

    override fun onDestroy() {
        super.onDestroy()
        _binding = null
    }

    companion object {
        fun newInstance() = RequestPasswordBottomSheet()
    }
}