package br.com.portoseguro.banking.sharedbanking.entity.account

enum class AccountStatusType(val slug: String) {
    OPEN("aberto"),
    NONE("inexistente"),
    PENDING_DOCS("pendenteDocumentos"),
    ELIGIBLE("elegivel"),
    DEBIT_LOCKED("debit-locked"),
    ADMINISTRATIVE_LOCKED("bloqueio-administrativo")
}
