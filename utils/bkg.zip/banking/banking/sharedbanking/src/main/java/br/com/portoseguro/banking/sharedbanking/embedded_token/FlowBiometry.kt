package br.com.portoseguro.banking.sharedbanking.embedded_token

sealed interface FlowBiometry {
    object Facial : FlowBiometry
    object All : FlowBiometry
}