package br.com.portoseguro.banking.sharedbanking.entity.extract

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class ExtractDetail(
    val id: String,
    val icon: String,
    val title: String?,
    val value: String?,
    val date: String?,
    val description: String?,
    val isScheduled: Boolean = false,
    val isRefunded: Boolean = false,
    val isCancelled: Boolean = false,
    val cancelButton: ExtractButtonAction? = null
) : Parcelable
