package br.com.portoseguro.banking.sharedbanking.entity.cards

enum class CardType(val slug: String) {
    DEBIT("DEBITO"),
    CREDIT("CREDITO"),
    MULTI("MULTI")
}