package br.com.portoseguro.banking.sharedbanking.tool

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.View
import androidx.collection.LruCache
import androidx.recyclerview.widget.RecyclerView


fun RecyclerView?.screenShoot(): Bitmap? {
    val adapter = this?.adapter
    var bigBitmap: Bitmap? = null
    if (this != null && adapter != null) {
        val size = adapter.itemCount - 1
        val cache: LruCache<String, Bitmap> = instanceLruCache()
        val height = getMaxHeight(this, adapter, cache, size)
        bigBitmap = createBitmapOptional(this, height)
        val bigCanvas = Canvas(bigBitmap)
        bigCanvas.drawColor(Color.WHITE)
        restore(cache, bigCanvas, size)
    }
    return bigBitmap
}

private fun getMaxHeight(
    recyclerView: RecyclerView,
    adapter: RecyclerView.Adapter<RecyclerView.ViewHolder>,
    cache: LruCache<String, Bitmap>,
    size: Int,
): Int {
    var height = 0
    for (i in 0 until size) {
        val holder = adapter.createViewHolder(recyclerView, adapter.getItemViewType(i))
        adapter.onBindViewHolder(holder, i)
        measure(holder, recyclerView)
        val drawingCache = holder.itemView.drawingCache
        if (drawingCache != null) {
            cache.put(i.toString(), drawingCache)
        }
        height += holder.itemView.measuredHeight
    }
    return height
}

private fun restore(cache: LruCache<String, Bitmap>, canvas: Canvas, size: Int) {
    val left = 0f
    var height = 0
    val paint = Paint()
    for (index in 0 until size) {
        cache.get(index.toString())?.let { bitmap ->
            canvas.drawBitmap(bitmap, left, height.toFloat(), paint)
            height += bitmap.height
            bitmap.recycle()
        }
    }
}

private fun measure(holder: RecyclerView.ViewHolder, view: RecyclerView) {
    val size = 0
    val left = 0
    val top = 0
    holder.itemView.measure(View.MeasureSpec.makeMeasureSpec(view.width,
        View.MeasureSpec.EXACTLY),
        View.MeasureSpec.makeMeasureSpec(size, View.MeasureSpec.UNSPECIFIED))
    holder.itemView.layout(left,
        top,
        holder.itemView.measuredWidth,
        holder.itemView.measuredHeight)
    holder.itemView.isDrawingCacheEnabled = true
    holder.itemView.buildDrawingCache()
}

private fun createBitmapOptional(
    view: RecyclerView,
    height: Int,
) = Bitmap.createBitmap(view.measuredWidth, height, Bitmap.Config.ARGB_8888)

private fun instanceLruCache(): LruCache<String, Bitmap> {
    val maxMemoryBase = 1024
    val cacheBase = 8
    val maxMemory = (Runtime.getRuntime().maxMemory() / maxMemoryBase).toInt()
    val cacheSize = maxMemory / cacheBase
    return LruCache(cacheSize)
}