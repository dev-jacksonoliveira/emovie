package br.com.portoseguro.banking.sharedbanking.entity.transaction

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
open class SummaryModel(
    open val id: String,
    open val icon: String,
    open val title: String,
    open val value: String,
    open val beneficiary: String?,
    open val dateTransaction: String,
    open val canCancelTransaction: Boolean = false,
    open val hasReceipt: Boolean = true,
    open val category: String
) : Parcelable {

    @Parcelize
    data class RefundTransactionModel(
        override val id: String,
        override val icon: String,
        override val title: String,
        override val value: String,
        override val beneficiary: String?,
        override val dateTransaction: String,
        override val canCancelTransaction: Boolean = false,
        val beneficiaryDocument: String = String(),
        val institutionName: String = String(),
        override val hasReceipt: Boolean = true
    ) : SummaryModel(
        id, icon, title, value, beneficiary, dateTransaction, canCancelTransaction, hasReceipt, String()
    ), Parcelable

    @Parcelize
    data class ScheduleTransactionSummaryModel(
        override val id: String,
        override val icon: String,
        override val title: String,
        override val value: String,
        override val beneficiary: String?,
        override val dateTransaction: String,
        override val canCancelTransaction: Boolean = false,
        val scheduleDateTransaction: String,
        override val hasReceipt: Boolean = true,
        override val category: String
    ) : SummaryModel(
        id, icon, title, value, beneficiary, dateTransaction, canCancelTransaction, hasReceipt, category
    ), Parcelable

    @Parcelize
    data class TransactionSummaryModel(
        override val id: String,
        override val icon: String,
        override val title: String,
        override val value: String,
        override val beneficiary: String?,
        override val dateTransaction: String,
        override val canCancelTransaction: Boolean = false,
        override val hasReceipt: Boolean = true
    ) : SummaryModel(
        id, icon, title, value, beneficiary, dateTransaction, canCancelTransaction, hasReceipt, String()
    ), Parcelable

    @Parcelize
    data class ScheduleOpenFinanceSummaryModel(
        override val id: String,
        override val icon: String,
        override val title: String,
        override val value: String,
        override val beneficiary: String?,
        override val dateTransaction: String,
        override val canCancelTransaction: Boolean = false,
        val scheduleDateTransaction: String,
        override val category: String,
        override val hasReceipt: Boolean = true,
        val able: Boolean = true,
        val titleResume: String?,
        val description: String?,
        val idCancellation: String
    ) : SummaryModel(
        id, icon, title, value, beneficiary, dateTransaction,
        canCancelTransaction, hasReceipt, category
    ), Parcelable
}
