package br.com.portoseguro.banking.sharedbanking.entity.extract

object ExtractAttributeException : IllegalStateException()