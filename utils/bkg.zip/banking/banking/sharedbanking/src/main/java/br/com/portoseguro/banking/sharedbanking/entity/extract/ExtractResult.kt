package br.com.portoseguro.banking.sharedbanking.entity.extract

sealed interface ExtractResult {
    object Error : ExtractResult
    data class Success(val extracts: List<Extract>) : ExtractResult
}
