package br.com.portoseguro.banking.sharedbanking.repository.receipt

import br.com.portoseguro.banking.sharedbanking.data.remote.ReceiptAPI
import br.com.portoseguro.banking.sharedbanking.entity.receipt.ReceiptData
import br.com.portoseguro.banking.sharedbanking.entity.receipt.ReceiptException
import br.com.portoseguro.banking.sharedbanking.mapper.ReceiptMapper
import br.com.portoseguro.superapp.core.infrastructure.SafeApiCaller
import br.com.portoseguro.superapp.core.infrastructure.onError
import br.com.portoseguro.superapp.core.infrastructure.onSuccess
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow

class ReceiptRepositoryImpl(
    private val receiptAPI: ReceiptAPI,
    private val apiCaller: SafeApiCaller,
    private val mapper: ReceiptMapper
) : ReceiptRepository {

    override fun getReceiptById(transactionId: String): Flow<ReceiptData> {
        return flow {
            result(transactionId).onSuccess { result ->
                mapper.onTryUnwrapSuccessReceipt(this, result)
            }.onError { error -> throw (error.exception ?: ReceiptException(error.code)) }
        }
    }

    private suspend fun result(transactionId: String) = apiCaller.safeApiCall {
        receiptAPI.getReceipt(transactionId)
    }
}