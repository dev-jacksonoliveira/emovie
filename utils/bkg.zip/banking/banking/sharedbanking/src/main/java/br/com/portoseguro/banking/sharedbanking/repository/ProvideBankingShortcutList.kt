package br.com.portoseguro.banking.sharedbanking.repository

import br.com.portoseguro.banking.sharedbanking.entity.shortcut.BankingShortcutType

interface ProvideBankingShortcutList<T : BankingShortcutType> {
    fun first(): List<T>
    fun second(): List<T>
}