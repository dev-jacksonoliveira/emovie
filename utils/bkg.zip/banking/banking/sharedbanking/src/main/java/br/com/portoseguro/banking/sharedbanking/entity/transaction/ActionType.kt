package br.com.portoseguro.banking.sharedbanking.entity.transaction

sealed interface ActionType {
    object CancelSchedule : ActionType
    object CancelPix : ActionType
    object Refund : ActionType
    object CancelScheduleOpenFinance : ActionType
}