package br.com.portoseguro.banking.sharedbanking.entity.password

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class AccountPasswordData(
    val password: String
) : Parcelable