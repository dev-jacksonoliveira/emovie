package br.com.portoseguro.banking.sharedbanking.repository

import br.com.portoseguro.banking.sharedbanking.entity.shortcut.BankingShortcutType


interface BankingShortcutAvailability<T : BankingShortcutType> {
    fun check(bankAvailShortcutType: T): Boolean
}