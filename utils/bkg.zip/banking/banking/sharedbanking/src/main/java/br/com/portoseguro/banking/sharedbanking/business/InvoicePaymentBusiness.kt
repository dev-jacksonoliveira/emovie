package br.com.portoseguro.banking.sharedbanking.business

import br.com.portoseguro.banking.sharedbanking.entity.invoice.InvoicePaymentData
import br.com.portoseguro.banking.sharedbanking.entity.receipt.ReceiptData
import br.com.portoseguro.banking.sharedbanking.repository.invoice.InvoicePaymentRepository
import kotlinx.coroutines.flow.Flow

class InvoicePaymentBusiness(
    private val invoicePaymentRepository: InvoicePaymentRepository
) {
    fun performInvoicePayment(
        invoicePaymentData: InvoicePaymentData
    ): Flow<ReceiptData> =
        invoicePaymentRepository.performInvoicePayment(invoicePaymentData)
}