package br.com.portoseguro.banking.sharedbanking.repository.help

import br.com.portoseguro.banking.sharedbanking.data.remote.HelpAPI
import br.com.portoseguro.banking.sharedbanking.entity.help.BankingHelpData
import br.com.portoseguro.banking.sharedbanking.data.mapper.help.BankingHelpResponseMapper
import br.com.portoseguro.superapp.core.infrastructure.SafeApiCaller
import br.com.portoseguro.superapp.core.infrastructure.exceptions.ServerErrorBackendException
import br.com.portoseguro.superapp.core.infrastructure.onError
import br.com.portoseguro.superapp.core.infrastructure.onSuccess
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow

class BankingHelpRepositoryImpl(
    private val safeApiCaller: SafeApiCaller,
    private val helpAPI: HelpAPI,
    private val helpResponseMapper: BankingHelpResponseMapper
) : BankingHelpRepository {

    override fun fetchFAQ(): Flow<List<BankingHelpData>> {
        return flow {
            safeApiCaller.safeApiCall { helpAPI.fetchFAQ() }
                .onSuccess { response -> helpResponseMapper.onTryUnwrapSuccessHelp(this, response) }
                .onError { error -> throw (error.exception ?: ServerErrorBackendException()) }
        }
    }
}