package br.com.portoseguro.banking.sharedbanking.repository

import br.com.portoseguro.sharedentity.banking.response.PixPaymentResponse
import br.com.portoseguro.superapp.core.entities.WrappedResponse

interface RefundRepository {
    suspend fun refund(
        password: String,
        transactionId: String,
        refundValue: Long,
        description: String? = null,
    ): WrappedResponse<PixPaymentResponse>
}
