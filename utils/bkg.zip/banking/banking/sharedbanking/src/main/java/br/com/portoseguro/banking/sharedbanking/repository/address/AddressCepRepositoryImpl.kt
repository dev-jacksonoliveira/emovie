package br.com.portoseguro.banking.sharedbanking.repository.address

import br.com.portoseguro.banking.sharedbanking.R
import br.com.portoseguro.banking.sharedbanking.data.exception.CepInvalidException
import br.com.portoseguro.banking.sharedbanking.data.exception.CepNotFoundException
import br.com.portoseguro.banking.sharedbanking.data.mapper.AddressCepMapper
import br.com.portoseguro.banking.sharedbanking.data.remote.MyRegistrationAPI
import br.com.portoseguro.banking.sharedbanking.data.unwrapDataBody
import br.com.portoseguro.banking.sharedbanking.entity.address.AddressCepData
import br.com.portoseguro.banking.sharedbanking.enum.AddressCepBusinessErrorType
import br.com.portoseguro.banking.sharedbanking.toggles.BankingRemoteConfigKeys
import br.com.portoseguro.sharedentity.core.response.BackendError
import br.com.portoseguro.superapp.core.infrastructure.ResourceProvider
import br.com.portoseguro.superapp.core.infrastructure.Result
import br.com.portoseguro.superapp.core.infrastructure.SafeApiCaller
import br.com.portoseguro.superapp.core.infrastructure.exceptions.BackendException
import br.com.portoseguro.superapp.core.infrastructure.onError
import br.com.portoseguro.superapp.core.infrastructure.onSuccess
import br.com.portoseguro.superapp.core.repository.RemoteConfigRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.transform

internal class AddressCepRepositoryImpl(
    private val myRegistrationAPI: MyRegistrationAPI,
    private val safeApiCaller: SafeApiCaller,
    private val addressCepMapper: AddressCepMapper,
    private val provider: ResourceProvider,
    private val remoteConfigRepository: RemoteConfigRepository
) : AddressCepRepository {

    override fun getAddressWithCep(cep: String): Flow<AddressCepData> {
        return flow {
            emit(safeApiCaller.safeApiCall {
                myRegistrationAPI.getAddressWithCep(cep)
            })
        }.transform { scope ->
            scope.run {
                onSuccess { result ->
                    emit(
                        addressCepMapper.convert(
                            result.unwrapDataBody()
                        )
                    )
                }
                onError { launchException(it) }
            }
        }
    }

    override fun getFindCepUrl(): String =
        remoteConfigRepository.getString(BankingRemoteConfigKeys.FIND_CEP.key)

    private fun launchException(resultError: Result.Error) {
        if (resultError is Result.BackendError) {
            throw throwBusinessError(resultError, resultError.error?.errors?.first())
        } else {
            throw resultError.exception ?: BackendException()
        }
    }

    private fun throwBusinessError(resultError: Result.Error, error: BackendError?): Throwable {
        val message = error?.messages?.first() ?: error.getLocalErrorMessage()
        return when (error?.field) {
            AddressCepBusinessErrorType.CEP_NOT_FOUND.field -> CepNotFoundException(message)
            AddressCepBusinessErrorType.CEP_INVALID.field -> CepInvalidException(message)
            else -> throwGenericException(resultError)
        }
    }

    private fun throwGenericException(resultError: Result.Error): Throwable {
        throw resultError.exception ?: BackendException()
    }

    private fun BackendError?.getLocalErrorMessage(): String {
        return when (this?.field) {
            AddressCepBusinessErrorType.CEP_NOT_FOUND.field -> provider.getString(R.string.address_cep_not_found)
            AddressCepBusinessErrorType.CEP_INVALID.field -> provider.getString(R.string.address_cep_invalid)
            else -> String()
        }
    }
}