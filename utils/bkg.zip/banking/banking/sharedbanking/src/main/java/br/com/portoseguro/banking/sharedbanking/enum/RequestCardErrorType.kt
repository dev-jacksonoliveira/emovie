package br.com.portoseguro.banking.sharedbanking.enum

enum class RequestCardErrorType(val field: String) {
    PASSWORD_INVALID("SENHA_INVALIDA"),
    PASSWORD_BLOCKED("SENHA_BLOQUEADA"),
    FAIL_REQUEST_CARD("FALHA_SOLICITAR_CARTAO"),
    NEW_REQUEST_CARD("NOVA_VIA_CARTAO")
}