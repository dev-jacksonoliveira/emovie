package br.com.portoseguro.banking.sharedbanking.business

import br.com.portoseguro.banking.sharedbanking.entity.onboard.MyRegistrationUpdateRequestData
import br.com.portoseguro.banking.sharedbanking.entity.onboard.MyRegistrationUpdateResponseData
import br.com.portoseguro.banking.sharedbanking.repository.MyRegistrationUpdateRepository
import kotlinx.coroutines.flow.Flow

class MyRegistrationUpdateBusinessImpl(
    private val repository: MyRegistrationUpdateRepository
) : MyRegistrationUpdateBusiness {
    override fun updateMyRegistrationInfo(
        request: MyRegistrationUpdateRequestData
    ): Flow<MyRegistrationUpdateResponseData> = repository.updateMyRegistrationInfo(request)
}
