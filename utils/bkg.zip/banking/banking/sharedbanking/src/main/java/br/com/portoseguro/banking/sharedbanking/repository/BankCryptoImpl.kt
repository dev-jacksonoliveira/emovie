package br.com.portoseguro.banking.sharedbanking.repository

import b.c.p.u.u.b
import br.com.portoseguro.usersecurity.enumerations.CryptographyFeatureType

class BankCryptoImpl(private val crypto: b) : BankCrypto {

    override fun encryptSecurityCode(plainText: String): String {
        return crypto.d(
            plainText,
            CryptographyFeatureType.DIGITAL_ACCOUNT_SECURITY_CODE
        ).removeSuffix("\n")
    }

    override fun decrypt(plainText: String): String {
        return crypto.c(
            plainText,
            CryptographyFeatureType.DIGITAL_ACCOUNT_SECURITY_CODE
        )
    }
}
