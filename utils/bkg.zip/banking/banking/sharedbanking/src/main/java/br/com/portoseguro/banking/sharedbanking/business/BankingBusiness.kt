package br.com.portoseguro.banking.sharedbanking.business

import br.com.portoseguro.banking.sharedbanking.entity.account.AccountStatusResult
import br.com.portoseguro.banking.sharedbanking.entity.account.AccountStatusType
import br.com.portoseguro.banking.sharedbanking.entity.subhome.AccountSummary
import br.com.portoseguro.banking.sharedbanking.mapper.BankingStatusMapper
import br.com.portoseguro.banking.sharedbanking.repository.BankingRepository
import br.com.portoseguro.banking.sharedbanking.repository.SummaryRepository
import kotlinx.coroutines.flow.Flow

class BankingBusiness(
    private val bankingRepository: BankingRepository,
    private val summaryRepository: SummaryRepository,
    private val mapper: BankingStatusMapper
) {

    suspend fun getAccountStatus(): AccountStatusResult {
        val response = bankingRepository.getAccountStatus()
        return mapper(response.body()?.data?.type).let { accountStatusResult: AccountStatusResult ->
            if (accountStatusResult is AccountStatusResult.Success) {
                bankingRepository.saveStatus(accountStatusResult.accountStatusType)
            } else {
                bankingRepository.saveStatus(AccountStatusType.NONE)
            }
            accountStatusResult
        }
    }

    fun getBankingProductOrNull(productCode: String): Any? {
        val statusSaved = getStatusSaved()
        return if (statusSaved.slug.lowercase() != AccountStatusType.NONE.slug.lowercase()) {
            bankingRepository.getBankingProduct(productCode)
        } else {
            null
        }
    }

    suspend fun getSummary(): Flow<AccountSummary> = summaryRepository.getSummary()

    fun getSummaryShortcuts(): List<Any> = summaryRepository.getShortcuts()

    fun getStatusSaved(): AccountStatusType {
        val input = bankingRepository.getLocalStatus().lowercase()
        return mapper(input).run {
            if (this is AccountStatusResult.Success) {
                accountStatusType
            } else {
                AccountStatusType.NONE
            }
        }
    }
}
