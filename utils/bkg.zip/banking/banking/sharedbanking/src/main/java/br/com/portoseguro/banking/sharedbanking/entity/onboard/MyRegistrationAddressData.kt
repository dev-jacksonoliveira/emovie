package br.com.portoseguro.banking.sharedbanking.entity.onboard

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class MyRegistrationAddressData(
    val formattedAddress: String,
    val cep: String,
    val publicPlace: String,
    val number: String,
    val complement: String,
    val city: String,
    val district: String,
    val uf: String
) : Parcelable
