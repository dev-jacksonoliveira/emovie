package br.com.portoseguro.banking.sharedbanking.entity.transfer

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class PixTransferContactData(
    val contactId: String = String(),
    val contactName: String?,
    val document: String?,
    val documentType: String?,
    val quantityKeys: String?,
    val institutionName: String?,
    val keys: List<PixKeyTransferContactData>
) : Parcelable
