package br.com.portoseguro.banking.sharedbanking.entity.transfer

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class PixKeyTransferContactData(
    val id: String,
    val type: String?,
    val key: String,
    val institution: String?,
    val agency: String?,
    val account: String?,
    val confidence: Boolean
) : Parcelable