package br.com.portoseguro.banking.sharedbanking.utils

import android.content.Context
import android.util.AttributeSet
import br.com.portoseguro.banking.sharedbanking.R
import br.com.portoseguro.components.stickheader.StickHeader

class StickHeaderDecorator @JvmOverloads constructor(
    context: Context?,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : StickHeader(context, attrs, defStyleAttr) {
    init {
        setBackButtonColor(R.color.porto_seguros_100)
    }
}