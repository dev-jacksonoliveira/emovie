package br.com.portoseguro.banking.sharedbanking.tool

sealed interface RequestPermissionState {
    object OnRequestPermission : RequestPermissionState
    object Granted : RequestPermissionState
    object NotGranted : RequestPermissionState
    object Blocked : RequestPermissionState
}