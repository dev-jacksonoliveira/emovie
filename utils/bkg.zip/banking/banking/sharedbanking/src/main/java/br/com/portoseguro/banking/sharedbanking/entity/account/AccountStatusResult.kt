package br.com.portoseguro.banking.sharedbanking.entity.account

sealed interface AccountStatusResult {
    data class Success(val accountStatusType: AccountStatusType) : AccountStatusResult
    object NullableTypo : AccountStatusResult
    object UnrecognizedTypo : AccountStatusResult
}