package br.com.portoseguro.banking.sharedbanking.entity.address

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class AddressResponseData(
    val title: String,
    val message: String
) : Parcelable
