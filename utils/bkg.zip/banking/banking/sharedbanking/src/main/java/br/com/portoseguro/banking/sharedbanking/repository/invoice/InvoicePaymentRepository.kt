package br.com.portoseguro.banking.sharedbanking.repository.invoice

import br.com.portoseguro.banking.sharedbanking.entity.invoice.InvoicePaymentData
import br.com.portoseguro.banking.sharedbanking.entity.receipt.ReceiptData
import kotlinx.coroutines.flow.Flow

interface InvoicePaymentRepository {
    fun performInvoicePayment(invoicePaymentRequest: InvoicePaymentData): Flow<ReceiptData>
}
