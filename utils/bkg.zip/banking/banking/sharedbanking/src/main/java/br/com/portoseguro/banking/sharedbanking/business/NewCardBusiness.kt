package br.com.portoseguro.banking.sharedbanking.business

import br.com.portoseguro.banking.sharedbanking.data.mapper.NewCardMapper
import br.com.portoseguro.banking.sharedbanking.entity.cards.delivery.AddressDeliveryCard
import br.com.portoseguro.banking.sharedbanking.entity.cards.delivery.AddressDeliveryCardResult
import br.com.portoseguro.banking.sharedbanking.repository.CardsRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.flow

class NewCardBusiness(
    private val cardsRepository: CardsRepository,
    private val mapper: NewCardMapper
) {
    fun getAddressDeliveryCard(): Flow<AddressDeliveryCardResult> {
        return flow {
            cardsRepository.getAddressDeliveryCard().collect { addressDeliveryCard ->
                val result = when {
                    confirmAddressPredicate(addressDeliveryCard) -> {
                        AddressDeliveryCardResult.ConfirmAddress(addressDeliveryCard)
                    }
                    newAddressPredicate(addressDeliveryCard) -> AddressDeliveryCardResult.NewAddress
                    else -> AddressDeliveryCardResult.EditAddress(addressDeliveryCard)
                }
                emit(result)
            }
        }
    }

    fun requestNewCard(password: String, addressDeliveryCard: AddressDeliveryCard): Flow<String> {
        val encryptPassWord = mapper.encryptPassword(password)
        return cardsRepository.requestNewCard(encryptPassWord, addressDeliveryCard)
    }

    private fun confirmAddressPredicate(addressDeliveryCard: AddressDeliveryCard): Boolean {
        val location = addressDeliveryCard.state.isNotEmpty() &&
                addressDeliveryCard.city.isNotEmpty()
        val street = addressDeliveryCard.neighborhood.isNotEmpty() &&
                addressDeliveryCard.address.isNotEmpty()
        val zipCode = addressDeliveryCard.zipCode.isNotEmpty()
        return location && street && zipCode

    }

    private fun newAddressPredicate(addressDeliveryCard: AddressDeliveryCard): Boolean {
        val location = addressDeliveryCard.state.isEmpty() &&
                addressDeliveryCard.city.isEmpty()
        val street = addressDeliveryCard.neighborhood.isEmpty() &&
                addressDeliveryCard.address.isEmpty()
        val zipCode = addressDeliveryCard.zipCode.isEmpty()
        return location && street && zipCode
    }
}