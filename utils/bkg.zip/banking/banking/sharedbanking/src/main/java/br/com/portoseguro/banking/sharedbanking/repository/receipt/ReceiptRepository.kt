package br.com.portoseguro.banking.sharedbanking.repository.receipt

import br.com.portoseguro.banking.sharedbanking.entity.receipt.ReceiptData
import kotlinx.coroutines.flow.Flow

interface ReceiptRepository {
    fun getReceiptById(transactionId: String): Flow<ReceiptData>
}
