package br.com.portoseguro.banking.sharedbanking.repository

import br.com.portoseguro.banking.sharedbanking.entity.shortcut.AccountShortcuts

interface AccountShortcutRepository {
    fun getShortcuts(): List<AccountShortcuts>
}