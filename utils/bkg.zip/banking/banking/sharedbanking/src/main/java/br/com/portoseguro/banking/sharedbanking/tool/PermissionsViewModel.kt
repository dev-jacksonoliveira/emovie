package br.com.portoseguro.banking.sharedbanking.tool

import br.com.portoseguro.permission.infrastructure.entity.PermissionStatus

class PermissionsViewModel : BaseAccountViewModel() {

    val permState by liveData<RequestPermissionState>()

    fun onRequestCameraPermission() {
        permState(RequestPermissionState.OnRequestPermission)
    }

    fun checkCameraPermission(isGranted: Boolean, permission: PermissionStatus) {
        permission.run {
            when {
                permissionBlocked() -> permState(RequestPermissionState.Blocked)
                isGranted || permissionGranted() -> permState(RequestPermissionState.Granted)
                else -> permState(RequestPermissionState.NotGranted)
            }
        }
    }

    fun checkSettingsResult(permission: PermissionStatus) {
        if (permission.permissionGranted()) {
            permState(RequestPermissionState.Granted)
        } else {
            permState(RequestPermissionState.NotGranted)
        }
    }
}
