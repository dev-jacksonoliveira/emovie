package br.com.portoseguro.banking.sharedbanking.enum

enum class PixContactKeyStatus {
    ATIVO,
    ANALISE
}