package br.com.portoseguro.banking.sharedbanking.repository

import br.com.portoseguro.banking.sharedbanking.entity.onboard.MyRegistrationHomeData
import kotlinx.coroutines.flow.Flow

interface MyRegistrationHomeRepository {
    fun fetchMyRegistrationInfo(): Flow<MyRegistrationHomeData>
}
