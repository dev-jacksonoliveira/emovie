package br.com.portoseguro.banking.sharedbanking.entity.pix_contact

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class PixKeyData(
    val keyId: String = String(),
    val key: String?,
    val type: String?,
    val status: String = String(),
    val institution: String = String(),
    val agency: String?,
    val account: String?,
    val details: PixKeyDetailsData?
) : Parcelable

@Parcelize
data class PixKeyDetailsData(
    val title: String = String(),
    val description: String = String()
) : Parcelable

@Parcelize
data class PixContactData(
    val idContact: String,
    val name: String,
    val document: String,
    val keys: List<PixKeyData>?,
    val amountDescription: String = String(),
    val statusTag: String = String()
) : Parcelable