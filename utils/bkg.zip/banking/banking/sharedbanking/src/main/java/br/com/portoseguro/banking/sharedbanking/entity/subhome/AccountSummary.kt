package br.com.portoseguro.banking.sharedbanking.entity.subhome

import br.com.portoseguro.banking.sharedbanking.entity.account.AccountStatusResult

data class AccountSummary(
    val bankName: String,
    val bankCode: String,
    val agency: String,
    val branch: String,
    val balance: String,
    val accountStatus: AccountStatusResult,
    val descriptionAccountStatus: String,
    val card: Card?
) : SubHomeData
