package br.com.portoseguro.banking.sharedbanking.presentation

import android.content.DialogInterface
import android.os.Bundle
import android.os.Parcelable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.view.isGone
import br.com.portoseguro.banking.sharedbanking.R
import br.com.portoseguro.banking.sharedbanking.databinding.BottomSheetBankingBinding
import br.com.portoseguro.superapp.core.infrastructure.extensions.bindBundle
import br.com.portoseguro.superapp.core.infrastructure.extensions.onClick
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import dev.kdblib.onewaybind.Bindable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class GenericBottomSheetData(
    val title: String,
    val desc: String,
    val disableCloseButton: Boolean = false,
    val primaryButton: String = "",
    val secondaryButton: String = ""
) : Parcelable

class GenericBottomSheet : BottomSheetDialogFragment(), Bindable {

    private var binding: BottomSheetBankingBinding? = null
    private var onPrimaryClickListener: (() -> Unit)? = null
    private var onSecondaryClickListener: (() -> Unit)? = null
    private var onDismissListener: (() -> Unit)? = null
    private val bankingBSData: GenericBottomSheetData by bindBundle(EXTRA_BOTTOM_SHEET_DATA)

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = BottomSheetBankingBinding.inflate(inflater, container, false)
        return binding?.root
    }

    override fun getTheme(): Int = R.style.BottomSheetDialogRoundedWithVerticalAnimationTheme

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupViews()
    }

    override fun onDismiss(dialog: DialogInterface) {
        onDismissListener?.invoke()
        super.onDismiss(dialog)
    }

    override fun onStart() {
        super.onStart()
        //this expands the bottom sheet when it is shown at landscape mode
        val bottomSheetBehavior = BottomSheetBehavior.from(binding?.root?.parent as View)
        bottomSheetBehavior.state = BottomSheetBehavior.STATE_EXPANDED
    }

    private fun setupViews() = with(binding) {

        binding?.tvTitle?.text = bankingBSData.title
        binding?.tvDesc?.text = bankingBSData.desc
        binding?.closeButton?.isGone = bankingBSData.disableCloseButton
        binding?.buttonPrimary?.isGone = bankingBSData.primaryButton.isBlank()
        binding?.buttonSecondary?.isGone = bankingBSData.secondaryButton.isBlank()
        binding?.buttonPrimary?.setText(bankingBSData.primaryButton)
        binding?.buttonSecondary?.setText(bankingBSData.secondaryButton)
        binding?.closeButton?.onClick { dismiss() }
        binding?.buttonPrimary?.clickAction = {
            onPrimaryClickListener?.invoke()
            dismiss()
        }
        binding?.buttonSecondary?.clickAction = {
            onSecondaryClickListener?.invoke()
            dismiss()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        binding = null
    }

    fun setPrimaryClickListener(listener: (() -> Unit)) {
        onPrimaryClickListener = listener
    }

    fun setSecondaryClickListener(listener: (() -> Unit)) {
        onSecondaryClickListener = listener
    }

    fun setOnDismissListener(listener: (() -> Unit)) {
        onDismissListener = listener
    }

    companion object {
        private const val EXTRA_BOTTOM_SHEET_DATA = "EXTRA_BOTTOM_SHEET_DATA"

        fun newInstance(genericBottomSheetData: GenericBottomSheetData) =
            GenericBottomSheet().apply {
                arguments = Bundle().apply {
                    putParcelable(EXTRA_BOTTOM_SHEET_DATA, genericBottomSheetData)
                }
            }
    }
}