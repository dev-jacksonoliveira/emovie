package br.com.portoseguro.banking.sharedbanking.business

import br.com.portoseguro.banking.sharedbanking.entity.onboard.MyRegistrationUpdateRequestData
import br.com.portoseguro.banking.sharedbanking.entity.onboard.MyRegistrationUpdateResponseData
import kotlinx.coroutines.flow.Flow

interface MyRegistrationUpdateBusiness {
    fun updateMyRegistrationInfo(request: MyRegistrationUpdateRequestData): Flow<MyRegistrationUpdateResponseData>
}