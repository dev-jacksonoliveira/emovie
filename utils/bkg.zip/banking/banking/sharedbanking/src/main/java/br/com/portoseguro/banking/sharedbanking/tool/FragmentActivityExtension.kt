package br.com.portoseguro.banking.sharedbanking.tool

import androidx.fragment.app.FragmentActivity
import br.com.portoseguro.superapp.core.ui.BaseActivity

fun FragmentActivity?.makeTransaction(bottomSheetScope: (BaseActivity) -> Unit) {
    (this as? BaseActivity)?.let { activity ->
        if (activity.canMakeFragmentTransaction) {
            bottomSheetScope.invoke(activity)
        }
    }
}
