package br.com.portoseguro.banking.sharedbanking.entity.invoice

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class InvoiceData(
    val invoiceCode: String,
    val editable: Boolean,
    val expired: Boolean,
    val formattedBalance: String,
    val balance: Long,
    val formattedValue: String,
    val value: Long,
    val formattedMax: String,
    val valueMax: Long,
    val formattedTotal: String,
    val valueTotal: Long,
    val formattedMinimum: String,
    val minimum: Long,
    val paymentDate: String,
    val dueDate: String,
    val interestLateFee: String,
    val discount: String,
    val recipient: String
) : Parcelable
