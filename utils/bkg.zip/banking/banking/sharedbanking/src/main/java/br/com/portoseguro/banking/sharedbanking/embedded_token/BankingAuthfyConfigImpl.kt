package br.com.portoseguro.banking.sharedbanking.embedded_token

import android.content.Context
import android.content.Intent
import br.com.portoseguro.banking.sharedbanking.utils.params.BankingAuthfyParams
import br.com.portoseguro.superapp.router.authfy.AuthfyCameraRouter
import br.com.portoseguro.usersecurity.antifraud.AntiFraudSession

private const val ZERO = "0"

class BankingAuthfyConfigImpl(
    private val antiFraudSession: AntiFraudSession,
    private val authfyCameraRouter: AuthfyCameraRouter
) : BankingAuthfyConfig {

    override operator fun invoke(context: Context): Intent {
        antiFraudSession.apply { requestId = ZERO }
        val flow = BankingAuthfyParams().biometricRegisterFlow()
        return authfyCameraRouter.getIntent(context, flow)
    }
}
