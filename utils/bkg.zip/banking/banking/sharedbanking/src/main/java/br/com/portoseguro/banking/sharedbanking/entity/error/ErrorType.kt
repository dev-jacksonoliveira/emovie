package br.com.portoseguro.banking.sharedbanking.entity.error

enum class ErrorType {
    NONE,
    INITIAL,
    SECOND,
    THIRD;

    operator fun inc(): ErrorType = when (this) {
        NONE -> INITIAL
        INITIAL -> SECOND
        SECOND, THIRD -> THIRD
    }
}