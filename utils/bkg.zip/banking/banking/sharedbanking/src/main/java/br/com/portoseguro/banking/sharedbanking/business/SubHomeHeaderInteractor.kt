package br.com.portoseguro.banking.sharedbanking.business

import br.com.portoseguro.banking.sharedbanking.entity.subhome.SubHomeData
import br.com.portoseguro.banking.sharedbanking.presentation.subhome.SubHomeAction
import kotlinx.coroutines.flow.Flow

class SubHomeHeaderInteractor(
    private val bankingBusiness: BankingBusiness,
    private val cardBusiness: CardBusiness
) {
    suspend operator fun invoke(subHomeAction: SubHomeAction): Flow<SubHomeData> {
        return when (subHomeAction) {
            SubHomeAction.Summary -> bankingBusiness.getSummary()
            SubHomeAction.Card -> cardBusiness.getFirstCard()
        }
    }
}