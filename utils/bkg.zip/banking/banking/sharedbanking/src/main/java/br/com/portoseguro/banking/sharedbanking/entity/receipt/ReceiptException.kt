package br.com.portoseguro.banking.sharedbanking.entity.receipt

import br.com.portoseguro.superapp.core.infrastructure.exceptions.BackendException

data class ReceiptException(val code: Int?) : BackendException()