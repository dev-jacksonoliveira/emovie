package br.com.portoseguro.banking.sharedbanking.enum

enum class AddressNumberType(val type: String) {
    WITHOUT_NUMBER("S/N")
}