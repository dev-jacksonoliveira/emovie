package br.com.portoseguro.banking.sharedbanking.presentation.address

import androidx.lifecycle.Observer
import br.com.portoseguro.banking.sharedbanking.RobolectricRunner
import br.com.portoseguro.banking.sharedbanking.TestCoroutineRule
import br.com.portoseguro.banking.sharedbanking.business.MyRegistrationUpdateBusiness
import br.com.portoseguro.banking.sharedbanking.data.exception.BlockedPasswordException
import br.com.portoseguro.banking.sharedbanking.data.exception.InvalidPasswordException
import br.com.portoseguro.banking.sharedbanking.entity.address.AddressCepData
import br.com.portoseguro.banking.sharedbanking.entity.error.ErrorType
import br.com.portoseguro.banking.sharedbanking.entity.onboard.MyRegistrationUpdateRequestData
import br.com.portoseguro.banking.sharedbanking.entity.onboard.MyRegistrationUpdateResponseData
import br.com.portoseguro.banking.sharedbanking.repository.address.AddressCepRepository
import br.com.portoseguro.superapp.core.infrastructure.exceptions.BackendException
import br.com.portoseguro.superapp.core.infrastructure.exceptions.NoConnectivityException
import io.mockk.MockKAnnotations
import io.mockk.coEvery
import io.mockk.impl.annotations.RelaxedMockK
import io.mockk.mockk
import io.mockk.verifySequence
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.flow
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@ExperimentalCoroutinesApi
@RunWith(RobolectricRunner::class)
internal class AddressViewModelTest {

    @get:Rule
    val coroutineRuleTest = TestCoroutineRule()

    private var businessMock = mockk<MyRegistrationUpdateBusiness>(relaxed = true)
    private val repositoryMock = mockk<AddressCepRepository>(relaxed = true)
    private val stateObserverMock = mockk<Observer<AddressCepState>>(relaxed = true)
    private val addressMock = mockk<AddressData>(relaxed = true)
    private val myRegistrationUpdateMock = mockk<MyRegistrationUpdateResponseData>(relaxed = true)
    private val myRegistrationMock = mockk<MyRegistrationUpdateRequestData>(relaxed = true)

    private val viewModelMock = AddressViewModel(repositoryMock, businessMock).apply {
        state.observeForever { stateObserverMock.onChanged(it) }
    }

    @Test
    fun `fetchAddressWithCep - should notify success when zip code(CEP) is correct`() =
        coroutineRuleTest.runBlockingTest {
            val addressCepMock = mockk<AddressCepData>(relaxed = true)

            coEvery { repositoryMock.getAddressWithCep(CEP) } returns flow {
                emit(
                    addressCepMock
                )
            }

            viewModelMock.getAddressCepData(CEP)

            verifySequence {
                stateObserverMock.onChanged(AddressCepState.Loading(true))
                stateObserverMock.onChanged(AddressCepState.Success(addressCepMock))
            }
        }

    @Test
    fun `sendAddress - should notify success when request send data`() =
        coroutineRuleTest.runBlockingTest {
            coEvery { businessMock.updateMyRegistrationInfo(myRegistrationMock) } returns flow {
                emit(
                    myRegistrationUpdateMock
                )
            }

            viewModelMock.submitAddress(addressMock, PASSWORD)

            coEvery {
                stateObserverMock.onChanged(AddressCepState.Loading(true))
                stateObserverMock.onChanged(AddressCepState.SuccessRequest(myRegistrationUpdateMock))
            }
        }

    @Test
    fun `sendAddress - should return a password error when has a password error`() {
        coEvery {
            businessMock.updateMyRegistrationInfo(myRegistrationMock)
        } throws run {
            InvalidPasswordException(
                PASSWORD_ERROR_MESSAGE
            )
        }

        viewModelMock.submitAddress(addressMock, PASSWORD)

        coEvery {
            stateObserverMock.onChanged(
                AddressCepState.InvalidPasswordError(
                    PASSWORD_ERROR_MESSAGE
                )
            )
        }
    }

    @Test
    fun `sendAddress - should return a error when password is blocked`() {
        coEvery {
            businessMock.updateMyRegistrationInfo(myRegistrationMock)
        } throws run {
            BlockedPasswordException(
                PASSWORD_ERROR_MESSAGE
            )
        }

        viewModelMock.submitAddress(addressMock, PASSWORD)

        coEvery {
            stateObserverMock.onChanged(
                AddressCepState.BlockedPasswordError(
                    PASSWORD_ERROR_MESSAGE
                )
            )
        }
    }

    @Test
    fun `fetchAddressWithCep - should return a error when has a backend exception get`() =
        coroutineRuleTest.runBlockingTest {
            coEvery { repositoryMock.getAddressWithCep(CEP) } throws BackendException()

            viewModelMock.getAddressCepData(CEP)

            coEvery { stateObserverMock.onChanged(AddressCepState.Error(false, ErrorType.INITIAL)) }
        }

    @Test
    fun `fetchAddressWithCep - should return a error when has a cep invalid`() =
        coroutineRuleTest.runBlockingTest {
            coEvery { repositoryMock.getAddressWithCep(CEP) } throws Error()

            viewModelMock.getAddressCepData(CEP)

            coEvery { stateObserverMock.onChanged(AddressCepState.CepInvalidError(ErrorType.INITIAL.name)) }
            coEvery { stateObserverMock.onChanged(AddressCepState.CepNotFound(ErrorType.INITIAL.name)) }
        }

    @Test
    fun `sendAddress - should return a error when has a backend exception get `() =
        coroutineRuleTest.runBlockingTest {
            coEvery { businessMock.updateMyRegistrationInfo(myRegistrationMock) } throws BackendException()

            viewModelMock.submitAddress(addressMock, PASSWORD)

            coEvery { stateObserverMock.onChanged(AddressCepState.Error(false, ErrorType.INITIAL)) }
        }

    @Test
    fun `fetchAddressWithCep - should return a error when has a no connection exception`() {
        coroutineRuleTest.runBlockingTest {
            coEvery { repositoryMock.getAddressWithCep(CEP) } throws NoConnectivityException()

            viewModelMock.getAddressCepData(CEP)

            coEvery {
                stateObserverMock.onChanged(AddressCepState.Loading(true))
                stateObserverMock.onChanged(AddressCepState.Error(false, ErrorType.INITIAL))
            }
        }
    }

    @Test
    fun `sendAddress - should return a error when has a no connection exception`() {
        coroutineRuleTest.runBlockingTest {
            coEvery { businessMock.updateMyRegistrationInfo(myRegistrationMock) } throws NoConnectivityException()

            viewModelMock.submitAddress(addressMock, PASSWORD)

            coEvery {
                stateObserverMock.onChanged(AddressCepState.Loading(true))
                stateObserverMock.onChanged(AddressCepState.Error(false, ErrorType.INITIAL))
            }
        }
    }

    companion object {
        const val CEP = "38550000"
        const val PASSWORD = "1234"
        const val PASSWORD_ERROR_MESSAGE = "Error"
    }
}
