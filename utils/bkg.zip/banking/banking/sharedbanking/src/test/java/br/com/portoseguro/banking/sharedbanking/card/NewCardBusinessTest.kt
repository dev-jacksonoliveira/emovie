package br.com.portoseguro.banking.sharedbanking.card

import br.com.portoseguro.banking.sharedbanking.business.NewCardBusiness
import br.com.portoseguro.banking.sharedbanking.data.mapper.NewCardMapper
import br.com.portoseguro.banking.sharedbanking.entity.cards.delivery.AddressDeliveryCard
import br.com.portoseguro.banking.sharedbanking.entity.cards.delivery.AddressDeliveryCardResult
import br.com.portoseguro.banking.sharedbanking.repository.CardsRepository
import io.mockk.MockKAnnotations
import io.mockk.coEvery
import io.mockk.coVerify
import io.mockk.every
import io.mockk.impl.annotations.MockK
import io.mockk.mockk
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.runBlocking
import org.hamcrest.core.IsInstanceOf
import org.junit.Assert
import org.junit.Before
import org.junit.Test

class NewCardBusinessTest {

    @MockK
    private var cardsRepository = mockk<CardsRepository>()

    @MockK
    private var mapper = mockk<NewCardMapper>()

    private lateinit var newCardBusiness: NewCardBusiness

    @Before
    fun setup() {
        MockKAnnotations.init(this)
        newCardBusiness = NewCardBusiness(cardsRepository, mapper)
    }

    @Test
    fun getAddressDeliveryCard_whenAddressIsIncomplete_shouldReturnResultEditAddress() =
        runBlocking {
            val addressDeliveryCard = mockk<AddressDeliveryCard>(relaxed = true)
            every { addressDeliveryCard.address } returns "xxx"
            every { addressDeliveryCard.neighborhood } returns "xxx"
            every { addressDeliveryCard.additionalInformation } returns "xxx"

            coEvery { cardsRepository.getAddressDeliveryCard() } returns flowOf(addressDeliveryCard)
            // ACT
            val result = newCardBusiness.getAddressDeliveryCard().first()
            // ASSERT
            coVerify { cardsRepository.getAddressDeliveryCard() }
            Assert.assertThat(
                result,
                IsInstanceOf.instanceOf(AddressDeliveryCardResult.EditAddress::class.java)
            )
        }

    @Test
    fun getAddressDeliveryCard_whenAddressIsComplete_shouldReturnResultEditAddress() {
        val addressDeliveryCard = mockk<AddressDeliveryCard>(relaxed = true)

        every { addressDeliveryCard.address } returns "xxx"
        every { addressDeliveryCard.city } returns "xxx"
        every { addressDeliveryCard.state } returns "xxx"
        every { addressDeliveryCard.zipCode } returns "xxx"
        every { addressDeliveryCard.neighborhood } returns "xxx"
        every { addressDeliveryCard.additionalInformation } returns "xxx"

        coEvery { cardsRepository.getAddressDeliveryCard() } returns flowOf(addressDeliveryCard)
        // ACT
        val result = runBlocking { newCardBusiness.getAddressDeliveryCard().first() }
        // ASSERT
        coVerify { cardsRepository.getAddressDeliveryCard() }
        Assert.assertThat(
            result,
            IsInstanceOf.instanceOf(AddressDeliveryCardResult.ConfirmAddress::class.java)
        )
    }

    @Test
    fun getAddressDeliveryCard_whenAddressIsEmpty_shouldReturnResultEditAddress() {
        val addressDeliveryCard = mockk<AddressDeliveryCard>(relaxed = true)

        coEvery { cardsRepository.getAddressDeliveryCard() } returns flowOf(addressDeliveryCard)
        // ACT
        val result = runBlocking { newCardBusiness.getAddressDeliveryCard().first() }
        // ASSERT
        coVerify { cardsRepository.getAddressDeliveryCard() }
        Assert.assertThat(
            result,
            IsInstanceOf.instanceOf(AddressDeliveryCardResult.NewAddress::class.java)
        )
    }


    @Test
    fun requestNewCard_whenRequestDeliveryCard() = runBlocking {
        val password = "pwd"
        val passwordEncrypted = "pwdpasswordEncrypted"
        val expectedResult = "expectedResult"
        val addressDeliveryCard = mockk<AddressDeliveryCard>()

        every { mapper.encryptPassword(password) } returns passwordEncrypted
        coEvery {
            cardsRepository.requestNewCard(passwordEncrypted, addressDeliveryCard)
        } returns flowOf(expectedResult)
        // ACT
        val result = newCardBusiness.requestNewCard(password, addressDeliveryCard).first()
        // ASSERT
        Assert.assertEquals(expectedResult, result)
        coVerify { mapper.encryptPassword(password) }
    }
}