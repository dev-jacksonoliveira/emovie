package br.com.portoseguro.banking.sharedbanking.converter

import br.com.portoseguro.banking.sharedbanking.mapper.ExtractMapper
import br.com.portoseguro.sharedentity.banking.response.ExtractResponse
import br.com.portoseguro.sharedentity.banking.response.ExtractResumeResponse
import org.junit.Test
import kotlin.test.assertEquals

class ExtractMapperTest {

    private val extractMapper = ExtractMapper()

    @Test
    fun convert_shouldDataToExtractMapper() {
        //given
        val input = extractResponse

        //when
        val result = extractMapper.invoke(input)

        //then
        assertEquals(true, result.isScheduled)
        assertEquals("20/03/2023", result.scheduleDate)
        assertEquals("pix_scheduled_open_finance", result.category.name)
        assertEquals(null, result.ticketCode)
        assertEquals("Hoje às 14:52", result.date)
        assertEquals("de João da Silva", result.description)
        assertEquals("123456789102", result.document)
        assertEquals("74364936", result.id)
        assertEquals("Itau", result.institution)
        assertEquals("Pix agendado", result.title)
        assertEquals("185,37", result.value)
        assertEquals(true, result.resume.able)
        assertEquals("Quer cancelar o Pix?", result.resume.title)
        assertEquals(
            "Você tem até as 23h59 do dia anterior ao agendado e o cancelamento não pode ser revertido.",
            result.resume.description
        )
    }

    private val extractResponse = ExtractResponse(
        isScheduled = true,
        scheduleDate = "20/03/2023",
        category = "pix_scheduled_open_finance",
        ticketCode = null,
        date = "Hoje às 14:52",
        description = "de João da Silva",
        document = "123456789102",
        id = "74364936",
        institution = "Itau",
        title = "Pix agendado",
        value = "185,37",
        resume = ExtractResumeResponse(
            able = true,
            title = "Quer cancelar o Pix?",
            description = "Você tem até as 23h59 do dia anterior ao agendado e o cancelamento não pode ser revertido."
        )
    )

}