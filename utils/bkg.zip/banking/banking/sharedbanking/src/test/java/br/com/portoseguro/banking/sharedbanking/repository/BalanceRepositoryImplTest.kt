package br.com.portoseguro.banking.sharedbanking.repository

import br.com.portoseguro.superapp.core.repository.DataRepository
import br.com.portoseguro.superapp.core.repository.DataSourceType
import io.mockk.MockKAnnotations
import io.mockk.Runs
import io.mockk.every
import io.mockk.impl.annotations.RelaxedMockK
import io.mockk.just
import org.junit.Before
import org.junit.Test

class BalanceRepositoryImplTest {

    @RelaxedMockK
    private lateinit var dataRepository : DataRepository

    private lateinit var repository: BalanceRepositoryImpl

    @Before
    fun setup() {
        MockKAnnotations.init(this)
        repository = BalanceRepositoryImpl(dataRepository)
    }

    @Test
    fun getBalanceVisibility_shouldReturnTrue_whenVisibilityIsTrue() {
        // ARRANGE
        val visibilityExpected = true
        every {
            dataRepository.get("account_balance_visibility", true, DataSourceType.MEMORY)
        } returns true

        // ACTION
        val result = repository.getBalanceVisibility()

        // ASSERT
        assert(result == visibilityExpected)
    }

    @Test
    fun setBalanceVisibility_whenPassTrue() {
        // ARRANGE
        val visibilityExpected = true
        every {
            dataRepository.set("account_balance_visibility", true, DataSourceType.MEMORY)
        } just Runs

        // ACTION
        repository.setBalanceVisibility(visibilityExpected)
    }

    @Test
    fun getBalance_shouldReturnString_whenExistsValueSaved() {
        // ARRANGE
        val balanceExpected = "R$1,00"
        every {
            dataRepository.get<String?>("account_balance", null, DataSourceType.MEMORY)
        } returns balanceExpected

        // ACTION
        val result = repository.getBalance()

        // ASSERT
        assert(result == balanceExpected)
    }

    @Test
    fun getBalance_shouldReturnNull_whenNotExistsValueSaved() {
        // ARRANGE
        val balanceExpected : String? = null
        every {
            dataRepository.get<String?>("account_balance", null, DataSourceType.MEMORY)
        } returns balanceExpected

        // ACTION
        val result = repository.getBalance()

        // ASSERT
        assert(result == balanceExpected)
    }

    @Test
    fun saveBalance_whenPassString() {
        // ARRANGE
        val balanceExpected = "R$1,99"
        every {
            dataRepository.set("account_balance", balanceExpected, DataSourceType.MEMORY)
        } just Runs

        // ACTION
        repository.saveBalance(balanceExpected)
    }
}