package br.com.portoseguro.banking.sharedbanking.analytics

import android.app.Activity
import br.com.portoseguro.superapp.core.analytics.Analytics
import br.com.portoseguro.superapp.core.analytics.model.Action
import io.mockk.mockk
import io.mockk.slot
import io.mockk.verify
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner

@RunWith(RobolectricTestRunner::class)
class BankingAnalyticsTest {

    private val analytics = mockk<Analytics>(relaxed = true)
    private val actionSlot = slot<Action>()
    private lateinit var bankingAnalytics: BankingAnalyticsImpl

    @Before
    fun setUp() {
        bankingAnalytics = BankingAnalyticsImpl(analytics)
    }

    @Test
    fun trackScreenView() {
        //Arrange
        val activity = mockk<Activity>(relaxed = true)

        //Act
        bankingAnalytics.trackScreenView(
            activity = activity,
            screen = "mockScreen",
            itemName = "mockItemName",
            section = "mockSection",
            product = "mockProduct"
        )

        //Assert
        verify { analytics.trackViewItem(any()) }
    }

    @Test
    fun trackAction() {
        //Act
        bankingAnalytics.trackAction(
            action = "mockAction",
            itemName = "mockItemName",
            section = "mockSection",
            product = "mockProduct",
            category = "mockCategory"
        )

        //Assert
        verify { analytics.trackAction(any()) }
    }

    @Test
    fun trackAlert() {
        //Act
        bankingAnalytics.trackAlert(
            action = "mockAction",
            alert = "mockAlert",
            itemName = "mockItemName",
            section = "mockSection",
            product = "mockProduct",
            category = "mockCategory"
        )

        //Assert
        verify { analytics.trackActionAlert(any()) }
    }

    @Test
    fun trackError() {
        //Act
        bankingAnalytics.trackError(
            error = "mockError",
            action = "mockAction",
            itemName = "mockItemName",
            section = "mockSection",
            product = "mockProduct",
            category = "mockCategory"
        )

        //Assert
        verify { analytics.trackActionError(any()) }
    }

    @Test
    fun `test addExtraParams indirectly`() {
        //Act
        bankingAnalytics.trackAction(
            action = "mockScreen",
            itemName = "mockItemName",
            section = "mockSection",
            product = "mockProduct",
            category = "mockCategory",
            label = "mockLabel",
            subSection1 = "mockSubSection1",
            subSection2 = "mockSubSection2",
            subSection3 = "mockSubSection3",
        )

        //Assert
        verify { analytics.trackAction(capture(actionSlot)) }
        assert(actionSlot.captured.getData()["ev_label"].toString() == "mocklabel")
        assert(actionSlot.captured.getData()["product"].toString() == "mockproduct")
        assert(actionSlot.captured.getData()["app_sub_section_1"].toString() == "mocksubsection1")
        assert(actionSlot.captured.getData()["app_sub_section_2"].toString() == "mocksubsection2")
        assert(actionSlot.captured.getData()["app_sub_section_3"].toString() == "mocksubsection3")
    }
}
