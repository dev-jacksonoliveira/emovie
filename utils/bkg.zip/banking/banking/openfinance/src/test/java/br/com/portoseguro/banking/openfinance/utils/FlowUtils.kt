package br.com.portoseguro.banking.openfinance.utils

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.collect
import org.junit.Assert

object FlowUtils {
    suspend fun <T> checkFlowError(result: Flow<T>) {
        result.catch {
            Assert.assertTrue(true)
        }.collect {
            Assert.assertTrue(false)
        }
    }
}