package br.com.portoseguro.banking.openfinance.infrastructure

import android.os.Build
import org.junit.runners.model.InitializationError
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

internal class RobolectricRunner @Throws(InitializationError::class)
constructor(testClass: Class<*>) : RobolectricTestRunner(testClass) {
    override fun buildGlobalConfig(): Config {
        return Config.Builder()
            .setSdk(Build.VERSION_CODES.O_MR1)
            .build()
    }
}