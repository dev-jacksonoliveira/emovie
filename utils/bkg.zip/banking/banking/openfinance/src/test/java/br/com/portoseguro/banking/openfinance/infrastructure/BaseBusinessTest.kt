package br.com.portoseguro.banking.openfinance.infrastructure

import br.com.portoseguro.superapp.core.infrastructure.SafeApiCaller
import br.com.portoseguro.superapp.core.log.Log
import io.mockk.mockk
import org.junit.After
import org.junit.Before
import org.koin.core.context.loadKoinModules
import org.koin.core.context.startKoin
import org.koin.core.context.stopKoin
import org.koin.dsl.module

abstract class BaseBusinessTest {

    protected val safeApiCaller: SafeApiCaller = SafeApiCaller(mockk(relaxed = true))

    @Before
    fun koinStart() {
        startKoin {
            loadKoinModules(module {
                single<Log> { mockk(relaxed = true) }
            })
        }
    }

    @After
    fun koinStop() {
        stopKoin()
    }
}