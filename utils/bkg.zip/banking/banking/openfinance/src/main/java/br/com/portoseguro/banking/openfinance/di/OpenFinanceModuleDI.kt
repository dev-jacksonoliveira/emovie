package br.com.portoseguro.banking.openfinance.di

import br.com.portoseguro.banking.openfinance.data.api.OpenFinanceAPI
import br.com.portoseguro.banking.openfinance.data.business.OpenFinanceBusiness
import br.com.portoseguro.banking.openfinance.data.business.OpenFinanceBusinessImpl
import br.com.portoseguro.banking.openfinance.data.mapper.OpenFinanceMapper
import br.com.portoseguro.banking.openfinance.data.repository.OpenFinanceRepository
import br.com.portoseguro.banking.openfinance.data.repository.OpenFinanceRepositoryImpl
import br.com.portoseguro.banking.openfinance.presentation.summary.OpenFinanceSummaryViewModel
import br.com.portoseguro.banking.openfinance.presentation.summary.mapper.OpenFinanceSummaryMapper
import br.com.portoseguro.banking.openfinance.presentation.summary.mapper.OpenFinanceSummaryMapperImpl
import br.com.portoseguro.banking.openfinance.router.OpenFinanceRouterImpl
import br.com.portoseguro.superapp.core.api.moshi.MoshiHttp
import br.com.portoseguro.superapp.core.api.moshi.create
import br.com.portoseguro.superapp.router.openfinance.OpenFinanceRouter
import org.koin.androidx.viewmodel.dsl.viewModel
import org.koin.core.context.loadKoinModules
import org.koin.core.module.Module
import org.koin.dsl.module

private val lazyLoadOpenFinanceModule by lazy { loadKoinModules(openFinanceModule) }

fun loadOpenFinanceModule() = lazyLoadOpenFinanceModule

private val openFinanceModule = module {
    addApis()
    addRepositories()
    addMappers()
    addBusiness()
    addViewModels()
    addRouter()
}

private fun Module.addApis() {
    single<OpenFinanceAPI> { get<MoshiHttp>().create() }
}

private fun Module.addRepositories() {
    factory<OpenFinanceRepository> {
        OpenFinanceRepositoryImpl(
            openFinanceAPI = get(),
            safeApiCaller = get(),
            mapper = get()
        )
    }
}

private fun Module.addMappers() {
    factory { OpenFinanceMapper() }
    factory<OpenFinanceSummaryMapper> { OpenFinanceSummaryMapperImpl(resourceProvider = get()) }
}

private fun Module.addBusiness() {
    factory<OpenFinanceBusiness> {
        OpenFinanceBusinessImpl(
            openFinanceRepository = get(),
            bankCrypto = get()
        )
    }
}

private fun Module.addViewModels() {
    viewModel { (consentID: String) ->
        OpenFinanceSummaryViewModel(
            openFinanceBusiness = get(),
            consentID = consentID,
            openFinanceSummaryMapper = get()
        )
    }
}

private fun Module.addRouter() {
    factory<OpenFinanceRouter> { OpenFinanceRouterImpl() }
}