package br.com.portoseguro.banking.openfinance.router

import android.content.Context
import android.content.Intent
import br.com.portoseguro.banking.openfinance.presentation.summary.OpenFinanceActivity
import br.com.portoseguro.superapp.router.openfinance.OpenFinanceRouter

class OpenFinanceRouterImpl : OpenFinanceRouter {
    override fun getOpenFinance(context: Context, consentID: String): Intent {
        return OpenFinanceActivity.getLaunchIntent(context, consentID)
    }
}