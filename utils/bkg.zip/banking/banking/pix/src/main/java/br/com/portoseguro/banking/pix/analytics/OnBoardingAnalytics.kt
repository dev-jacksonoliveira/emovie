package br.com.portoseguro.banking.pix.analytics

import android.app.Activity

class OnBoardingAnalytics(private val pixAnalytics: PixAnalytics) {

    private var currentScreen = PixAnalytics.Screens.OnBoarding.WELCOME

    fun trackingClickBack() {
        trackAction(PixAnalytics.Actions.CLICK_BACK)
    }

    fun trackingClickButton(buttonName: String) {
        trackAction(PixAnalytics.Actions.CLICK_IN_ + buttonName)
    }

    fun trackingScreen(activity: Activity, screenPosition: Int) {
        currentScreen = when (screenPosition) {
            WELCOME -> PixAnalytics.Screens.OnBoarding.WELCOME
            HOW_ITS_WORKS -> PixAnalytics.Screens.OnBoarding.HOW_ITS_WORKS
            KEY_TYPES -> PixAnalytics.Screens.OnBoarding.KEYS_TYPE
            REGISTER -> PixAnalytics.Screens.OnBoarding.REGISTER_YOUR_KEY
            else -> PixAnalytics.Screens.UNDEFINED
        }
        pixAnalytics.trackScreenView(
            activity = activity,
            screen = currentScreen,
            itemName = currentScreen,
            subSection1 = PixAnalytics.Sections.PIX,
            subSection2 = PixAnalytics.Sections.TUTORIAL
        )
    }

    private fun trackAction(action: String) {
        pixAnalytics.trackAction(
            action = action,
            itemName = currentScreen,
            subSection1 = PixAnalytics.Sections.PIX,
            subSection2 = PixAnalytics.Sections.TUTORIAL
        )
    }

    companion object {
        const val WELCOME = 0
        const val HOW_ITS_WORKS = 1
        const val KEY_TYPES = 2
        const val REGISTER = 3
    }
}