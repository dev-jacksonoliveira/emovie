package br.com.portoseguro.banking.pix.analytics

import android.app.Activity

class PixKeyRegisterCpfAnalytics(private val pixAnalytics: PixAnalytics) {
    fun trackingPixKeyRegisterScreen(activity: Activity) {
        pixAnalytics.trackScreenView(
            activity = activity,
            screen = PixAnalytics.Screens.Keys.REGISTER_CPF,
            itemName = PixAnalytics.Screens.Keys.REGISTER_CPF,
            subSection1 = PixAnalytics.Sections.PIX,
            subSection2 = PixAnalytics.Sections.MY_KEYS,
            subSection3 = PixAnalytics.Sections.REGISTER_KEYS
        )
    }

    fun trackingClickButton(buttonName: String) {
        trackAction(PixAnalytics.Actions.CLICK_IN_ + buttonName)
    }

    fun trackingClickBack() {
        trackAction(PixAnalytics.Actions.CLICK_BACK)
    }

    private fun trackAction(action: String) {
        pixAnalytics.trackAction(
            action = action,
            itemName = PixAnalytics.Screens.Keys.REGISTER_CPF,
            subSection1 = PixAnalytics.Sections.PIX,
            subSection2 = PixAnalytics.Sections.MY_KEYS,
            subSection3 = PixAnalytics.Sections.REGISTER_KEYS
        )
    }
}