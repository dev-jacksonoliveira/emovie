package br.com.portoseguro.banking.pix.analytics

import android.app.Activity

class PixKeyRegisterAnalytics(private val pixAnalytics: PixAnalytics) {

    fun trackingChooseCPF() {
        trackAction(PixAnalytics.Actions.CLICK_CPF, PixAnalytics.Screens.Keys.CHOOSE_YOUR_KEY)
    }

    fun trackingChoosePhoneNumber() {
        trackAction(
            PixAnalytics.Actions.CLICK_PHONE_NUMBER,
            PixAnalytics.Screens.Keys.CHOOSE_YOUR_KEY
        )
    }

    fun trackingChooseEmail() {
        trackAction(PixAnalytics.Actions.CLICK_EMAIL, PixAnalytics.Screens.Keys.CHOOSE_YOUR_KEY)
    }

    fun trackingChooseRandomKey() {
        trackAction(
            action = PixAnalytics.Actions.CLICK_RANDOM_KEY,
            itemName = PixAnalytics.Screens.Keys.CHOOSE_YOUR_KEY
        )
    }

    fun trackingClickButtonFromRandomKey(buttonName: String) {
        trackAction(
            action = PixAnalytics.Actions.CLICK_IN_ + buttonName,
            itemName = PixAnalytics.Screens.Keys.REGISTER_RANDOM_KEY
        )
    }

    fun trackingClickBackFromRandomKey() {
        trackAction(PixAnalytics.Actions.CLICK_BACK, PixAnalytics.Screens.Keys.REGISTER_RANDOM_KEY)
    }

    fun trackingRandomKeyScreen(activity: Activity) {
        trackScreen(activity, PixAnalytics.Screens.Keys.REGISTER_RANDOM_KEY)
    }

    private fun trackScreen(activity: Activity, screen: String) {
        pixAnalytics.trackScreenView(
            activity = activity,
            screen = screen,
            itemName = screen,
            subSection1 = PixAnalytics.Sections.PIX,
            subSection2 = PixAnalytics.Sections.MY_KEYS,
            subSection3 = PixAnalytics.Sections.REGISTER_KEYS
        )
    }

    private fun trackAction(action: String, itemName: String) {
        pixAnalytics.trackAction(
            action = action,
            itemName = itemName,
            subSection1 = PixAnalytics.Sections.PIX,
            subSection2 = PixAnalytics.Sections.MY_KEYS,
            subSection3 = PixAnalytics.Sections.REGISTER_KEYS
        )
    }
}