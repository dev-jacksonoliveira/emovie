package br.com.portoseguro.banking.pix.analytics

import android.app.Activity

class PixKeySelectionAnalytics(private val pixAnalytics: PixAnalytics) {
    fun trackingClickBackFromActivity() {
        trackAction(PixAnalytics.Actions.CLICK_BACK, PixAnalytics.Screens.Keys.TERM_REGISTER_KEYS)
    }

    fun trackingClickBackFromFragment() {
        trackAction(PixAnalytics.Actions.CLICK_BACK, PixAnalytics.Screens.Keys.CHOOSE_YOUR_KEY)
    }

    fun tracingPixKeySelectionScreen(activity: Activity) {
        pixAnalytics.trackScreenView(
            activity = activity,
            screen = PixAnalytics.Screens.Keys.CHOOSE_YOUR_KEY,
            itemName = PixAnalytics.Screens.Keys.CHOOSE_YOUR_KEY,
            subSection1 = PixAnalytics.Sections.PIX,
            subSection2 = PixAnalytics.Sections.MY_KEYS,
            subSection3 = PixAnalytics.Sections.REGISTER_KEYS
        )
    }

    private fun trackAction(action: String, itemName: String) {
        pixAnalytics.trackAction(
            action = action,
            itemName = itemName,
            subSection1 = PixAnalytics.Sections.PIX,
            subSection2 = PixAnalytics.Sections.MY_KEYS,
            subSection3 = PixAnalytics.Sections.REGISTER_KEYS
        )
    }
}