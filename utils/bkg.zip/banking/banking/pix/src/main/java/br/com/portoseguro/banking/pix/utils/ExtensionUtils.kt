package br.com.portoseguro.banking.pix.utils

import android.text.InputFilter
import android.widget.EditText
import androidx.core.view.isVisible
import androidx.viewbinding.ViewBinding
import br.com.portoseguro.components.utils.ComponentsUtils

internal var ViewBinding.isVisible: Boolean
    get() = root.isVisible
    set(value) {
        root.isVisible = value
    }

/**
 * Converts this CharSequence to one to be used as icon, if possible.
 *
 * @return If possible, this value converted to be used with the icon font. Otherwise nothing will change.
 */
internal fun CharSequence.toIcon(): CharSequence {
    val rawValue = this
    val formattedIcon = if (rawValue.matches(ICON_PATTERN_MATCHER.toRegex())) {
        this
    } else {
        ICON_PATTERN_CONVERTER.format(rawValue)
    }.toString()
    return ComponentsUtils.setFontIcon(formattedIcon) ?: rawValue
}

internal fun String.unmask(): String {
    val builder = StringBuilder(this)
    return builder.filter { it.isDigit() }.toString()
}

internal fun String.getPhoneWithDDI(): String {
    val number = unmask()
    if (number.length < PHONE_MIN_SIZE) throw IllegalStateException()
    val range = IntRange(0, 1)
    val existsDDI = number.substring(range) == DDI
    return if (number.length > PHONE_MIN_SIZE && existsDDI) {
        number
    } else {
        StringBuilder("$DDI$number").toString()
    }
}

internal fun String.getPhoneWithDDIMask(): String {
    var index = 0
    val number = getPhoneWithDDI()
    val phoneWithMask = StringBuilder()

    CELLPHONE_MASK.toCharArray().forEach { digit ->
        if (digit != MASK_CHAR_CELLPHONE) {
            phoneWithMask.append(digit)
        } else {
            try {
                phoneWithMask.append(number[index])
            } catch (e: StringIndexOutOfBoundsException) {
                // Nothing to do here
            }
            index++
        }
    }
    return phoneWithMask.toString()
}

internal fun String.maskDocumentNumbers(): String {
    return this.replaceRange(0, DOCUMENT_MASK_END_INDEX, DOCUMENT_MASK_FIRST_DIGITS)
        .replaceAfter(DOCUMENT_MASK_DELIMITER, DOCUMENT_MASK_LAST_DIGITS)
}

internal fun EditText.filterEmoji() {
    filters = arrayOf(InputFilter { source, _, _, _, _, _ ->
        source.filter {
            Character.getType(it) != Character.SURROGATE.toInt()
                    && Character.getType(it) != Character.NON_SPACING_MARK.toInt()
                    && Character.getType(it) != Character.OTHER_SYMBOL.toInt()
        }
    })
}

private const val ICON_PATTERN_MATCHER = "[^\\w\\d]"
private const val CELLPHONE_MASK = "+## (##) #####-####"
private const val MASK_CHAR_CELLPHONE = '#'
private const val ICON_PATTERN_CONVERTER = "&#x%s;"
private const val DDI = "55"
private const val PHONE_MIN_SIZE = 11
private const val DOCUMENT_MASK_END_INDEX= 3
private const val DOCUMENT_MASK_DELIMITER = "-"
private const val DOCUMENT_MASK_LAST_DIGITS = "**"
private const val DOCUMENT_MASK_FIRST_DIGITS = "***"
