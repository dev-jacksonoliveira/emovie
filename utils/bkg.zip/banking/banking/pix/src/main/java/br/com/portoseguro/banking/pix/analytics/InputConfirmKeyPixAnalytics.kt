package br.com.portoseguro.banking.pix.analytics

import android.app.Activity

class InputConfirmKeyPixAnalytics(private val pixAnalytics: PixAnalytics) {
    fun trackingInputConfirmKeyScreen(activity: Activity, screen: String, itemName: String) {
        pixAnalytics.trackScreenView(
            activity = activity,
            screen = screen,
            itemName = itemName,
            subSection1 = PixAnalytics.Sections.PIX,
            subSection2 = PixAnalytics.Sections.MY_KEYS,
            subSection3 = PixAnalytics.Sections.REGISTER_KEYS
        )
    }

    fun trackingClickConfirmation(action: String, itemName: String) {
        trackAction(action, itemName)
    }

    fun trackingClickButton(buttonName: String, screen: String){
        trackAction(PixAnalytics.Actions.CLICK_IN_ + buttonName, screen)
    }

    fun trackingClickBack(itemName: String) {
        trackAction(PixAnalytics.Actions.CLICK_BACK, itemName)
    }

    fun  trackingInputFieldError(itemName: String) {
        trackAction(PixAnalytics.Actions.INPUT_VERIFICATION_CODE_ERROR, itemName)
    }

    private fun trackAction(action: String, itemName: String) {
        pixAnalytics.trackAction(
            action = action,
            itemName = itemName,
            subSection1 = PixAnalytics.Sections.PIX,
            subSection2 = PixAnalytics.Sections.MY_KEYS,
            subSection3 = PixAnalytics.Sections.REGISTER_KEYS
        )
    }
}