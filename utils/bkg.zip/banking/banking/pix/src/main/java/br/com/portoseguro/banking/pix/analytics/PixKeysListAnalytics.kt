package br.com.portoseguro.banking.pix.analytics

import android.app.Activity

class PixKeysListAnalytics(private val pixAnalytics: PixAnalytics) {

    fun trackingMyKeysScreenView(activity: Activity) {
        trackScreen(activity)
    }

    fun trackingClickBack() {
        trackAction(PixAnalytics.Actions.CLICK_BACK)
    }

    fun trackingClickButton(buttonName: String) {
        trackAction(PixAnalytics.Actions.CLICK_IN_ + buttonName)
    }

    fun trackingAlert(alertMessage: String) {
        trackAlert(alert = PixAnalytics.Alert.PIX_ALERT_WITH + alertMessage)
    }

    fun trackingScreenError(activity: Activity, message: String) {
        pixAnalytics.trackingScreenError(
            activity = activity,
            errorMessage = PixAnalytics.Alert.PIX_ALERT_WITH + message,
            screen = PixAnalytics.Screens.Keys.SCREEN_ERROR,
            itemName = PixAnalytics.Screens.Keys.SCREEN_ERROR,
            subSection1 = PixAnalytics.Sections.PIX,
            subSection2 = PixAnalytics.Sections.MY_KEYS
        )
    }

    private fun trackScreen(activity: Activity) {
        pixAnalytics.trackScreenView(
            activity = activity,
            screen = PixAnalytics.Screens.Keys.MY_KEYS,
            itemName = PixAnalytics.Screens.Keys.MY_KEYS,
            subSection1 = PixAnalytics.Sections.PIX,
            subSection2 = PixAnalytics.Sections.MY_KEYS
        )
    }

    private fun trackAction(action: String) {
        pixAnalytics.trackAction(
            action = action,
            itemName = PixAnalytics.Screens.Keys.MY_KEYS,
            subSection1 = PixAnalytics.Sections.PIX,
            subSection2 = PixAnalytics.Sections.MY_KEYS
        )
    }

    private fun trackAlert(alert: String) {
        pixAnalytics.trackAlert(
            action = PixAnalytics.Actions.ALERT,
            alert = alert,
            itemName = PixAnalytics.Screens.Keys.MY_KEYS,
            subSection1 = PixAnalytics.Sections.PIX,
            subSection2 = PixAnalytics.Sections.MY_KEYS,
            label = getLabel(alert)
        )
    }

    private fun getLabel(alert: String): String {
        val cpf = "CPF"
        val phone = "Número de celular"
        val email = "E-mail"
        return if (alert.contains(cpf)) {
            PixAnalytics.Label.KEYS_REGISTER_SUCCESS + PixAnalytics.Label.CPF
        } else if (alert.contains(phone)) {
            PixAnalytics.Label.KEYS_REGISTER_SUCCESS + PixAnalytics.Label.PHONE
        } else if (alert.contains(email)) {
            PixAnalytics.Label.KEYS_REGISTER_SUCCESS + PixAnalytics.Label.EMAIL
        } else {
            PixAnalytics.Label.KEYS_REGISTER_SUCCESS + PixAnalytics.Label.RANDOM_KEY
        }
    }
}