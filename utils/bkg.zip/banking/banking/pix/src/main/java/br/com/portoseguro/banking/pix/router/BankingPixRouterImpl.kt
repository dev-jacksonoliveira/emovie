package br.com.portoseguro.banking.pix.router

import android.content.Context
import android.content.Intent
import br.com.portoseguro.banking.pix.data.repository.onboarding.OnboardingRepository
import br.com.portoseguro.banking.pix.presentation.home.HomePixActivity
import br.com.portoseguro.banking.pix.presentation.onboarding.OnboardingActivity
import br.com.portoseguro.superapp.router.banking.BankingPixRouter

class BankingPixRouterImpl(private val onboardingRepository: OnboardingRepository) : BankingPixRouter {

    override fun getIntent(context: Context): Intent {
        return if (onboardingRepository.isFirstAccess()) {
            OnboardingActivity.getLaunchIntent(context)
        } else {
            HomePixActivity.getLaunchIntent(context)
        }
    }
}