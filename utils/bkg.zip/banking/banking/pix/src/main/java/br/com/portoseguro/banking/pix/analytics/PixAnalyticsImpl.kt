package br.com.portoseguro.banking.pix.analytics

import android.app.Activity
import br.com.portoseguro.banking.pix.analytics.PixAnalytics.Sections
import br.com.portoseguro.banking.pix.analytics.PixAnalytics.Category
import br.com.portoseguro.superapp.core.analytics.Analytics
import br.com.portoseguro.superapp.core.analytics.model.Action
import br.com.portoseguro.superapp.core.analytics.model.ActionAlert
import br.com.portoseguro.superapp.core.analytics.model.ActionError
import br.com.portoseguro.superapp.core.analytics.model.ViewItem
import br.com.portoseguro.superapp.core.analytics.model.ViewItemError
import br.com.portoseguro.superapp.core.analytics.utils.AnalyticsConstants.Param.APP_SUB_SECTION_1
import br.com.portoseguro.superapp.core.analytics.utils.AnalyticsConstants.Param.APP_SUB_SECTION_2
import br.com.portoseguro.superapp.core.analytics.utils.AnalyticsConstants.Param.APP_SUB_SECTION_3
import br.com.portoseguro.superapp.core.analytics.utils.AnalyticsConstants.Param.EV_LABEL
import br.com.portoseguro.superapp.core.analytics.utils.AnalyticsConstants.Param.PRODUCT
import br.com.portoseguro.superapp.core.analytics.utils.AnalyticsConstants.Param.PRODUCT_IDENTIFY
import br.com.portoseguro.superapp.core.analytics.utils.AnalyticsConstants.Param.SCREEN
import br.com.portoseguro.superapp.core.analytics.utils.AnalyticsInterface

class PixAnalyticsImpl(
    private val analytics: Analytics
) : PixAnalytics {
    override fun trackScreenView(
        activity: Activity,
        screen: String,
        itemName: String,
        subSection1: String?,
        subSection2: String?,
        subSection3: String?
    ) {
        val viewItem = ViewItem(
            activity = activity,
            appSection = Sections.DIGITAL_ACCOUNT,
            itemName = itemName,
        ).apply {
            addExtraParams(
                screen = screen,
                subSection1 = subSection1,
                subSection2 = subSection2,
                subSection3 = subSection3,
                product = Sections.DIGITAL_ACCOUNT
            )
        }
        analytics.trackViewItem(viewItem)
    }

    override fun trackAction(
        action: String,
        itemName: String,
        label: String?,
        subSection1: String?,
        subSection2: String?,
        subSection3: String?
    ) {
        val act = Action(
            appSection = Sections.DIGITAL_ACCOUNT,
            evCategory = Category.DIGITAL_ACCOUNT,
            evAction = action,
            itemName = itemName
        ).apply {
            addExtraParams(
                label = label,
                subSection1 = subSection1,
                subSection2 = subSection2,
                subSection3 = subSection3,
                product = Sections.DIGITAL_ACCOUNT
            )
        }

        analytics.trackAction(act)
    }

    override fun trackAlert(
        action: String,
        alert: String,
        itemName: String,
        subSection1: String?,
        subSection2: String?,
        subSection3: String?,
        label: String?
    ) {
        val actionAlert = ActionAlert(
            evAction = action,
            alert = alert,
            itemName = itemName,
            appSection = Sections.DIGITAL_ACCOUNT,
            evCategory = Category.DIGITAL_ACCOUNT
        ).apply {
            addExtraParams(
                subSection1 = subSection1,
                subSection2 = subSection2,
                subSection3 = subSection3,
                product = Sections.DIGITAL_ACCOUNT,
                label = label
            )
        }

        analytics.trackActionAlert(actionAlert)
    }

    override fun trackingScreenError(
        activity: Activity,
        errorMessage: String,
        screen: String,
        itemName: String,
        subSection1: String?,
        subSection2: String?,
        subSection3: String?
    ) {
        val error = ViewItemError(
            activity = activity,
            appSection = Sections.DIGITAL_ACCOUNT,
            errorMessage = errorMessage,
            itemName = itemName
        ).apply {
            addExtraParams(
                screen = screen,
                subSection1 = subSection1,
                subSection2 = subSection2,
                subSection3 = subSection3,
                product = Sections.DIGITAL_ACCOUNT
            )
        }

        analytics.trackViewItemError(error)
    }

    private fun <T> AnalyticsInterface.Model<T>.addExtraParams(
        screen: String? = null,
        product: String? = null,
        productIdentify: String? = null,
        subSection1: String? = null,
        subSection2: String? = null,
        subSection3: String? = null,
        label: String? = null
    ) {
        screen?.let { add(key = SCREEN, value = it) }
        subSection1?.let { add(key = APP_SUB_SECTION_1, value = it) }
        subSection2?.let { add(key = APP_SUB_SECTION_2, value = it) }
        subSection3?.let { add(key = APP_SUB_SECTION_3, value = it) }
        productIdentify?.let { add(key = PRODUCT_IDENTIFY, value = it) }
        product?.let { add(key = PRODUCT, value = it) }
        label?.let { add(key = EV_LABEL, value = it) }
    }
}