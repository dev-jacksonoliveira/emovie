package br.com.portoseguro.banking.pix.utils

import java.math.RoundingMode

private const val PATTERN = "[^0-9]"
private const val SCALE = 2

internal fun String.toMoney(pattern: Regex = Regex(PATTERN)): Long =
    this.replace(pattern, "").toBigDecimalOrNull()?.setScale(SCALE, RoundingMode.HALF_UP)?.toLong() ?: 0