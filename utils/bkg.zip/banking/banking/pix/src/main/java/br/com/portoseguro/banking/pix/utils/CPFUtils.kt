package br.com.portoseguro.banking.pix.utils

private const val FORMAT_CPF = "###.###.###-##"

internal fun applyCpfMask(cpf: String, mask: String = FORMAT_CPF, oldString: String = String()): String {
    var index = 0
    var cpfWithMask = ""

    for (m: Char in mask.toCharArray()) {
        if (m != '#' && cpf.length > oldString.length) {
            cpfWithMask += m
        } else {
            try {
                cpfWithMask += cpf[index]
            } catch (e: StringIndexOutOfBoundsException) {
                break
            }
            index++
        }
    }

    return cpfWithMask
}