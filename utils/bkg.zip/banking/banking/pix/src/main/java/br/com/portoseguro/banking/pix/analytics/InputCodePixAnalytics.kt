package br.com.portoseguro.banking.pix.analytics

import android.app.Activity

class InputCodePixAnalytics(private val pixAnalytics: PixAnalytics) {

    fun trackingCodeError(label: String) {
        trackAction(
            action = PixAnalytics.Actions.INPUT_FIELD_ERROR,
            label = label,
            itemName = screen
        )
    }

    fun trackingClickBack(label: String) {
        trackAction(
            action = PixAnalytics.Actions.CLICK_BACK,
            label = label,
            itemName = screen
        )
    }

    fun trackingInputCodeScreen(activity: Activity) {
        pixAnalytics.trackScreenView(
            activity = activity,
            screen = screen,
            itemName = screen,
            subSection1 = PixAnalytics.Sections.PIX,
            subSection2 = PixAnalytics.Sections.MY_KEYS,
            subSection3 = PixAnalytics.Sections.REGISTER_KEYS
        )
    }

    fun trackingResendCode(label: String) {
        trackAction(
            label = label,
            action = PixAnalytics.Actions.CLICK_REQUEST_TOKEN,
            itemName = screen
        )
    }

    fun trackingClickButton(buttonName: String, label: String) {
        trackAction(
            label = label,
            action = PixAnalytics.Actions.CLICK_IN_ + buttonName,
            itemName = screen
        )
    }

    fun trackingOnFinishWriting(action: String, label: String) {
        trackAction(
            action = action,
            label = label,
            itemName = screen
        )
    }

    private fun trackAction(action: String, itemName: String, label: String) {
        pixAnalytics.trackAction(
            action = action,
            itemName = itemName,
            label = label,
            subSection1 = PixAnalytics.Sections.PIX,
            subSection2 = PixAnalytics.Sections.MY_KEYS,
            subSection3 = PixAnalytics.Sections.REGISTER_KEYS
        )
    }

    companion object {
        enum class ScreenType{ EMAIL, PHONE }
        private var screen = ""
        fun setScreenType (type: ScreenType) {
            screen = when(type) {
                ScreenType.PHONE -> PixAnalytics.Screens.Keys.VALID_PHONE
                ScreenType.EMAIL -> PixAnalytics.Screens.Keys.VALID_EMAIL
            }
        }
    }
}