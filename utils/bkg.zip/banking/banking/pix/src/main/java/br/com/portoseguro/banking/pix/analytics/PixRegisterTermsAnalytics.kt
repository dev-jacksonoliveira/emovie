package br.com.portoseguro.banking.pix.analytics

import android.app.Activity

class PixRegisterTermsAnalytics(private val pixAnalytics: PixAnalytics) {

    fun trackingRegisterScreen(activity: Activity) {
        pixAnalytics.trackScreenView(
            activity = activity,
            screen = PixAnalytics.Screens.Keys.TERM_REGISTER_KEYS,
            itemName = PixAnalytics.Screens.Keys.TERM_REGISTER_KEYS,
            subSection1 = PixAnalytics.Sections.PIX,
            subSection2 = PixAnalytics.Sections.MY_KEYS,
            subSection3 = PixAnalytics.Sections.REGISTER_KEYS
        )
    }

    fun trackingClickButton(buttonName: String) {
        trackAction(
            action = PixAnalytics.Actions.CLICK_IN_ + buttonName,
            itemName = PixAnalytics.Screens.Keys.TERM_REGISTER_KEYS
        )
    }

    private fun trackAction(action: String, itemName: String, label: String? = null) {
        pixAnalytics.trackAction(
            action = action,
            itemName = itemName,
            label  = label,
            subSection1 = PixAnalytics.Sections.PIX,
            subSection2 = PixAnalytics.Sections.MY_KEYS,
            subSection3 = PixAnalytics.Sections.REGISTER_KEYS
        )
    }
}