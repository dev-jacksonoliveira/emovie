package br.com.portoseguro.banking.pix.di

import android.content.Context
import br.com.portoseguro.banking.pix.analytics.InputCodePixAnalytics
import br.com.portoseguro.banking.pix.analytics.InputConfirmKeyPixAnalytics
import br.com.portoseguro.banking.pix.analytics.OnBoardingAnalytics
import br.com.portoseguro.banking.pix.analytics.PixAnalytics
import br.com.portoseguro.banking.pix.analytics.PixAnalyticsImpl
import br.com.portoseguro.banking.pix.analytics.PixKeyRegisterAnalytics
import br.com.portoseguro.banking.pix.analytics.PixKeyRegisterCpfAnalytics
import br.com.portoseguro.banking.pix.analytics.PixKeySelectionAnalytics
import br.com.portoseguro.banking.pix.analytics.PixKeysListAnalytics
import br.com.portoseguro.banking.pix.analytics.PixRegisterTermsAnalytics
import br.com.portoseguro.banking.pix.data.api.PixAPI
import br.com.portoseguro.banking.pix.data.business.ClaimsPixBusiness
import br.com.portoseguro.banking.pix.data.business.ClaimsPixBusinessImpl
import br.com.portoseguro.banking.pix.data.business.InstitutionBusiness
import br.com.portoseguro.banking.pix.data.business.InstitutionBusinessImpl
import br.com.portoseguro.banking.pix.data.business.ListPixBusiness
import br.com.portoseguro.banking.pix.data.business.ListPixBusinessImpl
import br.com.portoseguro.banking.pix.data.business.OnboardingBusiness
import br.com.portoseguro.banking.pix.data.business.OnboardingBusinessImpl
import br.com.portoseguro.banking.pix.data.business.PixPaymentLimitExceededUnwrap
import br.com.portoseguro.banking.pix.data.business.PixPaymentLimitExceededUnwrapImpl
import br.com.portoseguro.banking.pix.data.business.PixPaymentPasswordUnwrap
import br.com.portoseguro.banking.pix.data.business.PixPaymentPasswordUnwrapImpl
import br.com.portoseguro.banking.pix.data.business.PixShortcutBusiness
import br.com.portoseguro.banking.pix.data.business.RefundBusiness
import br.com.portoseguro.banking.pix.data.business.RegisterPixBusiness
import br.com.portoseguro.banking.pix.data.business.RegisterPixBusinessImpl
import br.com.portoseguro.banking.pix.data.business.SchedulePixBusiness
import br.com.portoseguro.banking.pix.data.business.SchedulePixBusinessImpl
import br.com.portoseguro.banking.pix.data.business.TransferPixBusiness
import br.com.portoseguro.banking.pix.data.business.TransferPixBusinessImpl
import br.com.portoseguro.banking.pix.data.business.contacts.PixContactsBusiness
import br.com.portoseguro.banking.pix.data.business.contacts.PixContactsBusinessImpl
import br.com.portoseguro.banking.pix.data.business.contacts.PixContactsDeleteKeyBusiness
import br.com.portoseguro.banking.pix.data.business.contacts.PixContactsDeleteKeyBusinessImpl
import br.com.portoseguro.banking.pix.data.business.contacts.PixContactsRecordBusiness
import br.com.portoseguro.banking.pix.data.business.contacts.PixContactsRecordBusinessImpl
import br.com.portoseguro.banking.pix.data.business.limits.PixLimitsPeriodNocturnEditBusiness
import br.com.portoseguro.banking.pix.data.business.limits.PixLimitsPeriodNocturnEditBusinessImpl
import br.com.portoseguro.banking.pix.data.business.limits.UpdatePixLimitBusiness
import br.com.portoseguro.banking.pix.data.business.limits.UpdatePixLimitBusinessImpl
import br.com.portoseguro.banking.pix.data.business.qrcode.PixQrCodeConsultBusiness
import br.com.portoseguro.banking.pix.data.business.qrcode.PixQrCodeConsultBusinessImpl
import br.com.portoseguro.banking.pix.data.business.qrcode.PixQrCodeReceiveBusiness
import br.com.portoseguro.banking.pix.data.business.qrcode.PixQrCodeReceiveBusinessImpl
import br.com.portoseguro.banking.pix.data.business.transfer.PixAccountTransferBusiness
import br.com.portoseguro.banking.pix.data.business.transfer.PixAccountTransferBusinessImpl
import br.com.portoseguro.banking.pix.data.business.transfer.PixTransferContactBusiness
import br.com.portoseguro.banking.pix.data.business.transfer.PixTransferContactBusinessImpl
import br.com.portoseguro.banking.pix.data.business.transfer.contact.PixTransferContactDeleteBusiness
import br.com.portoseguro.banking.pix.data.business.transfer.contact.PixTransferContactDeleteBusinessImpl
import br.com.portoseguro.banking.pix.data.entity.PixKey
import br.com.portoseguro.banking.pix.data.entity.PixKeyTransferData
import br.com.portoseguro.banking.pix.data.entity.contacts.PixContactsDeleteKeyData
import br.com.portoseguro.banking.pix.data.entity.limits.PixSectionsListData
import br.com.portoseguro.banking.pix.data.entity.qrcode.PixQrCodeReceiveData
import br.com.portoseguro.banking.pix.data.enums.PixKeyStatus
import br.com.portoseguro.banking.pix.data.enums.PixKeyType
import br.com.portoseguro.banking.pix.data.local.shortcut.PixShortcutAvailabilityImpl
import br.com.portoseguro.banking.pix.data.local.shortcut.ProvidePixShortcuts
import br.com.portoseguro.banking.pix.data.mapper.PixKeyClaimMapper
import br.com.portoseguro.banking.pix.data.mapper.PixKeyClaimMapperImpl
import br.com.portoseguro.banking.pix.data.mapper.PixKeyMapper
import br.com.portoseguro.banking.pix.data.mapper.PixKeyMapperImpl
import br.com.portoseguro.banking.pix.data.mapper.PixLimitsMapper
import br.com.portoseguro.banking.pix.data.mapper.PixLimitsMapperImpl
import br.com.portoseguro.banking.pix.data.mapper.PixShortcutFeatureToggleMapper
import br.com.portoseguro.banking.pix.data.mapper.PixShortcutFeatureToggleMapper.Companion.HELP
import br.com.portoseguro.banking.pix.data.mapper.PixShortcutFeatureToggleMapper.Companion.MY_KEYS
import br.com.portoseguro.banking.pix.data.mapper.PixShortcutFeatureToggleMapper.Companion.MY_LIMITS
import br.com.portoseguro.banking.pix.data.mapper.PixShortcutFeatureToggleMapper.Companion.PIX_COPY_PASTE
import br.com.portoseguro.banking.pix.data.mapper.PixShortcutFeatureToggleMapper.Companion.QR_CODE
import br.com.portoseguro.banking.pix.data.mapper.PixShortcutFeatureToggleMapper.Companion.RECEIVE
import br.com.portoseguro.banking.pix.data.mapper.PixShortcutFeatureToggleMapper.Companion.TRANSFER
import br.com.portoseguro.banking.pix.data.mapper.limits.PixContactRecordRequestMapperImpl
import br.com.portoseguro.banking.pix.data.mapper.limits.PixContactsDeleteRequestMapper
import br.com.portoseguro.banking.pix.data.mapper.limits.PixContactsDeleteRequestMapperImpl
import br.com.portoseguro.banking.pix.data.mapper.limits.PixContactsRecordMapper
import br.com.portoseguro.banking.pix.data.mapper.limits.PixLimitUpdateRequestMapper
import br.com.portoseguro.banking.pix.data.mapper.limits.PixLimitUpdateRequestMapperImpl
import br.com.portoseguro.banking.pix.data.mapper.limits.PixLimitUpdateResponseMapper
import br.com.portoseguro.banking.pix.data.mapper.limits.PixLimitUpdateResponseMapperImpl
import br.com.portoseguro.banking.pix.data.mapper.limits.PixLimitsPeriodNocturnRequestMapper
import br.com.portoseguro.banking.pix.data.mapper.limits.PixLimitsPeriodNocturnRequestMapperImpl
import br.com.portoseguro.banking.pix.data.mapper.limits.PixLimitsPeriodNocturnResponseMapper
import br.com.portoseguro.banking.pix.data.mapper.limits.PixLimitsPeriodNocturnResponseMapperImpl
import br.com.portoseguro.banking.pix.data.mapper.qrcode.PixQrCodeConsultMapper
import br.com.portoseguro.banking.pix.data.mapper.qrcode.PixQrCodeConsultMapperImpl
import br.com.portoseguro.banking.pix.data.mapper.qrcode.PixQrCodeExceptionMapper
import br.com.portoseguro.banking.pix.data.mapper.qrcode.PixQrCodeExceptionMapperImpl
import br.com.portoseguro.banking.pix.data.mapper.qrcode.PixQrCodeReceiveMapper
import br.com.portoseguro.banking.pix.data.mapper.qrcode.PixQrCodeReceiveMapperImpl
import br.com.portoseguro.banking.pix.data.mapper.qrcode.PixQrCodeTransferMapper
import br.com.portoseguro.banking.pix.data.mapper.qrcode.PixQrCodeTransferMapperImpl
import br.com.portoseguro.banking.pix.data.mapper.transfer.InstitutionMapper
import br.com.portoseguro.banking.pix.data.mapper.transfer.PixKeyPaymentRequestMapper
import br.com.portoseguro.banking.pix.data.mapper.transfer.PixKeyPaymentRequestMapperImpl
import br.com.portoseguro.banking.pix.data.mapper.transfer.PixKeyPaymentResponseMapper
import br.com.portoseguro.banking.pix.data.mapper.transfer.PixKeyPaymentResponseMapperImpl
import br.com.portoseguro.banking.pix.data.mapper.transfer.PixKeyScheduleMapper
import br.com.portoseguro.banking.pix.data.mapper.transfer.PixKeyScheduleMapperImpl
import br.com.portoseguro.banking.pix.data.mapper.transfer.PixKeySummaryMapper
import br.com.portoseguro.banking.pix.data.mapper.transfer.PixKeySummaryMapperImpl
import br.com.portoseguro.banking.pix.data.mapper.transfer.PixKeyTransferMapper
import br.com.portoseguro.banking.pix.data.mapper.transfer.PixKeyTransferMapperImpl
import br.com.portoseguro.banking.pix.data.mapper.transfer.contact.PixTransferContactDeleteRequestMapper
import br.com.portoseguro.banking.pix.data.mapper.transfer.contact.PixTransferContactDeleteRequestMapperImpl
import br.com.portoseguro.banking.pix.data.mapper.transfer.contact.PixTransferContactDeleteResponseMapper
import br.com.portoseguro.banking.pix.data.mapper.transfer.contact.PixTransferContactDeleteResponseMapperImpl
import br.com.portoseguro.banking.pix.data.mapper.transfer.insert.PixAccountTransferMapper
import br.com.portoseguro.banking.pix.data.mapper.transfer.insert.PixAccountTransferMapperImpl
import br.com.portoseguro.banking.pix.data.mapper.transfer.insert.PixInsertTransferMapper
import br.com.portoseguro.banking.pix.data.mapper.transfer.insert.PixInsertTransferMapperImpl
import br.com.portoseguro.banking.pix.data.repository.PixRepository
import br.com.portoseguro.banking.pix.data.repository.PixRepositoryImpl
import br.com.portoseguro.banking.pix.data.repository.institutions.InstitutionsRepository
import br.com.portoseguro.banking.pix.data.repository.institutions.InstitutionsRepositoryImpl
import br.com.portoseguro.banking.pix.data.repository.limits.PixContactsDeleteRepository
import br.com.portoseguro.banking.pix.data.repository.limits.PixContactsDeleteRepositoryImpl
import br.com.portoseguro.banking.pix.data.repository.limits.PixContactsRecordRepository
import br.com.portoseguro.banking.pix.data.repository.limits.PixContactsRecordRepositoryImpl
import br.com.portoseguro.banking.pix.data.repository.limits.PixLimitsPeriodNocturnEditRepository
import br.com.portoseguro.banking.pix.data.repository.limits.PixLimitsPeriodNocturnEditRepositoryImpl
import br.com.portoseguro.banking.pix.data.repository.limits.PixLimitsRepository
import br.com.portoseguro.banking.pix.data.repository.limits.PixLimitsRepositoryImpl
import br.com.portoseguro.banking.pix.data.repository.limits.UpdatePixLimitRepository
import br.com.portoseguro.banking.pix.data.repository.limits.UpdatePixLimitRepositoryImpl
import br.com.portoseguro.banking.pix.data.repository.onboarding.OnboardingRepository
import br.com.portoseguro.banking.pix.data.repository.onboarding.OnboardingRepositoryImpl
import br.com.portoseguro.banking.pix.data.repository.qrcode.PixQrCodeConsultRepository
import br.com.portoseguro.banking.pix.data.repository.qrcode.PixQrCodeConsultRepositoryImpl
import br.com.portoseguro.banking.pix.data.repository.qrcode.PixQrCodeReceiveRepository
import br.com.portoseguro.banking.pix.data.repository.qrcode.PixQrCodeReceiveRepositoryImpl
import br.com.portoseguro.banking.pix.data.repository.shortcut.PixShortcutRepository
import br.com.portoseguro.banking.pix.data.repository.shortcut.PixShortcutRepositoryImpl
import br.com.portoseguro.banking.pix.data.repository.transfer.contact.PixTransferContactDeleteRepository
import br.com.portoseguro.banking.pix.data.repository.transfer.contact.PixTransferContactDeleteRepositoryImpl
import br.com.portoseguro.banking.pix.presentation.contacts.PixContactsViewModel
import br.com.portoseguro.banking.pix.presentation.contacts.add.AddPixContactViewModel
import br.com.portoseguro.banking.pix.presentation.contacts.add.confirm.PixContactAddConfirmViewModel
import br.com.portoseguro.banking.pix.presentation.contacts.add.confirm.mapper.PixContactAddKeyMapper
import br.com.portoseguro.banking.pix.presentation.contacts.add.confirm.mapper.PixContactAddKeyMapperImpl
import br.com.portoseguro.banking.pix.presentation.contacts.add.confirm.mapper.PixContactAddManualMapper
import br.com.portoseguro.banking.pix.presentation.contacts.add.confirm.mapper.PixContactAddManualMapperImpl
import br.com.portoseguro.banking.pix.presentation.contacts.add.insert.insertion.account.ManualInsertionAccountBankInformationActivityViewModel
import br.com.portoseguro.banking.pix.presentation.contacts.add.insert.institution.PixContactsInstitutionInsertViewModel
import br.com.portoseguro.banking.pix.presentation.contacts.delete.confirm.PixContactsDeleteConfirmViewModel
import br.com.portoseguro.banking.pix.presentation.contacts.detail.PixDetailContactViewModel
import br.com.portoseguro.banking.pix.presentation.contacts.detail.mapper.PixDetailContactMapper
import br.com.portoseguro.banking.pix.presentation.contacts.detail.mapper.PixDetailContactMapperImpl
import br.com.portoseguro.banking.pix.presentation.help.HelpRouter
import br.com.portoseguro.banking.pix.presentation.home.HomePixViewModel
import br.com.portoseguro.banking.pix.presentation.home.navigation.HomePixNavigation
import br.com.portoseguro.banking.pix.presentation.home.navigation.HomePixNavigationImpl
import br.com.portoseguro.banking.pix.presentation.keys.PixKeysListViewModel
import br.com.portoseguro.banking.pix.presentation.keys.bottomsheet.claims.PixKeysClaimsViewModel
import br.com.portoseguro.banking.pix.presentation.keys.bottomsheet.delete.PixKeyDeleteViewModel
import br.com.portoseguro.banking.pix.presentation.limits.PixLimitsHomeViewModel
import br.com.portoseguro.banking.pix.presentation.limits.confirm.UpdatePixLimitViewModel
import br.com.portoseguro.banking.pix.presentation.limits.edit.EditPixLimitsActivityViewModel
import br.com.portoseguro.banking.pix.presentation.limits.edit.mapper.PixLimitsEditMapper
import br.com.portoseguro.banking.pix.presentation.limits.edit.mapper.PixLimitsEditMapperImpl
import br.com.portoseguro.banking.pix.presentation.limits.period.edit.PixLimitsPeriodNocturnEditViewModel
import br.com.portoseguro.banking.pix.presentation.onboarding.OnboardingViewModel
import br.com.portoseguro.banking.pix.presentation.qrcode.receive.keys.PixQrCodeKeySelectionViewModel
import br.com.portoseguro.banking.pix.presentation.qrcode.receive.navigation.PixQrCodeReceiveNavViewModel
import br.com.portoseguro.banking.pix.presentation.qrcode.receive.share.PixQrCodeShareViewModel
import br.com.portoseguro.banking.pix.presentation.qrcode.receive.share.helper.PixQrCodeShareHelper
import br.com.portoseguro.banking.pix.presentation.qrcode.receive.share.helper.PixQrCodeShareHelperImpl
import br.com.portoseguro.banking.pix.presentation.qrcode.receive.value.PixQrCodeValueViewModel
import br.com.portoseguro.banking.pix.presentation.register.PixKeyRegisterViewModel
import br.com.portoseguro.banking.pix.presentation.register.PixKeySelectionAnalyticsViewModel
import br.com.portoseguro.banking.pix.presentation.register.claims.PixKeyRegisterClaimsViewModel
import br.com.portoseguro.banking.pix.presentation.register.code.InputCodePixViewModel
import br.com.portoseguro.banking.pix.presentation.register.code.countdown.CountdownResourceProvider
import br.com.portoseguro.banking.pix.presentation.register.code.countdown.CountdownResourceProviderImpl
import br.com.portoseguro.banking.pix.presentation.register.code.countdown.CountdownToExpireCodePixViewModel
import br.com.portoseguro.banking.pix.presentation.register.insert.InputConfirmKeyPixViewModel
import br.com.portoseguro.banking.pix.presentation.register.insert.cpf.PixKeyRegisterCpfViewModel
import br.com.portoseguro.banking.pix.presentation.register.selection.PixKeySelectionViewModel
import br.com.portoseguro.banking.pix.presentation.register.selection.PixRegisterTermsViewModel
import br.com.portoseguro.banking.pix.presentation.transfer.TransactionRouterImpl
import br.com.portoseguro.banking.pix.presentation.transfer.bottomsheet.error.PixTransferErrorViewModel
import br.com.portoseguro.banking.pix.presentation.transfer.bottomsheet.error.mapper.PixTransferErrorMapper
import br.com.portoseguro.banking.pix.presentation.transfer.bottomsheet.error.mapper.PixTransferErrorMapperImpl
import br.com.portoseguro.banking.pix.presentation.transfer.contacts.PixTransferContactsViewModel
import br.com.portoseguro.banking.pix.presentation.transfer.contacts.contact.PixTransferContactViewModel
import br.com.portoseguro.banking.pix.presentation.transfer.contacts.contact.delete.confirm.PixTransferContactDeleteConfirmViewModel
import br.com.portoseguro.banking.pix.presentation.transfer.contacts.contact.details.PixTransferContactDetailsViewModel
import br.com.portoseguro.banking.pix.presentation.transfer.insert.account.PixAccountTransferViewModel
import br.com.portoseguro.banking.pix.presentation.transfer.insert.data.PixDataTransferViewModel
import br.com.portoseguro.banking.pix.presentation.transfer.insert.institution.PixInstitutionTransferViewModel
import br.com.portoseguro.banking.pix.presentation.transfer.insert.navigation.PixInsertTransferNavViewModel
import br.com.portoseguro.banking.pix.presentation.transfer.navigation.PixTransferNavViewModel
import br.com.portoseguro.banking.pix.presentation.transfer.pixKey.PixKeyTransferViewModel
import br.com.portoseguro.banking.pix.presentation.transfer.pixKey.field.PixKeyTransferFieldViewModel
import br.com.portoseguro.banking.pix.presentation.transfer.pixKey.field.mapper.PixKeyTransferFieldMapper
import br.com.portoseguro.banking.pix.presentation.transfer.pixKey.field.mapper.PixKeyTransferFieldMapperImpl
import br.com.portoseguro.banking.pix.presentation.transfer.pixKey.field.validator.PixKeyTransferValidator
import br.com.portoseguro.banking.pix.presentation.transfer.pixKey.field.validator.PixKeyTransferValidatorImpl
import br.com.portoseguro.banking.pix.presentation.transfer.pixKey.summary.PixKeyTransferSummaryViewModel
import br.com.portoseguro.banking.pix.presentation.transfer.pixKey.value.PixKeyTransferValueViewModel
import br.com.portoseguro.banking.pix.presentation.transfer.qrcode.PixTransferPermissionViewModel
import br.com.portoseguro.banking.pix.presentation.transfer.qrcode.insert.PixQrCodeInsertViewModel
import br.com.portoseguro.banking.pix.presentation.transfer.qrcode.navigation.PixQrCodeTransferNavViewModel
import br.com.portoseguro.banking.pix.presentation.transfer.qrcode.reader.PixQrCodeReaderViewModel
import br.com.portoseguro.banking.pix.presentation.transfer.refund.RefundTransferViewModel
import br.com.portoseguro.banking.pix.presentation.transfer.refund.summary.RefundViewModel
import br.com.portoseguro.banking.pix.router.BankingPixRouterImpl
import br.com.portoseguro.banking.pix.router.help.HelpRouterImpl
import br.com.portoseguro.banking.pix.router.payment.PixPaymentRouterImpl
import br.com.portoseguro.banking.pix.router.tranfer.BankingTransferRouterImpl
import br.com.portoseguro.banking.pix.utils.base64.BitmapToBase64
import br.com.portoseguro.banking.pix.utils.base64.BitmapToBase64Impl
import br.com.portoseguro.banking.sharedbanking.data.mapper.PixContactResponseMapper
import br.com.portoseguro.banking.sharedbanking.data.mapper.PixContactResponseMapperImpl
import br.com.portoseguro.banking.sharedbanking.data.mapper.PixTransferContactResponseMapper
import br.com.portoseguro.banking.sharedbanking.data.mapper.PixTransferContactResponseMapperImpl
import br.com.portoseguro.banking.sharedbanking.data.remote.TransactionLimitAPI
import br.com.portoseguro.banking.sharedbanking.entity.pix_contact.PixContactData
import br.com.portoseguro.banking.sharedbanking.entity.shortcut.PixShortcuts
import br.com.portoseguro.banking.sharedbanking.mapper.BankingShortcutFeatureToggleKeyMapper
import br.com.portoseguro.banking.sharedbanking.repository.BankingShortcutAvailability
import br.com.portoseguro.banking.sharedbanking.repository.ProvideBankingShortcutList
import br.com.portoseguro.banking.sharedbanking.repository.pix_contacts.PixContactsRepository
import br.com.portoseguro.banking.sharedbanking.repository.pix_contacts.PixContactsRepositoryImpl
import br.com.portoseguro.banking.sharedbanking.repository.transfer.PixTransferContactRepository
import br.com.portoseguro.banking.sharedbanking.repository.transfer.PixTransferContactRepositoryImpl
import br.com.portoseguro.superapp.core.api.moshi.MoshiHttp
import br.com.portoseguro.superapp.core.api.moshi.create
import br.com.portoseguro.superapp.core.toggle.FeatureToggle
import br.com.portoseguro.superapp.router.banking.BankingPixRouter
import br.com.portoseguro.superapp.router.banking.PixPaymentRouter
import br.com.portoseguro.superapp.router.banking.TransactionRouter
import br.com.portoseguro.superapp.router.banking.transfer.BankingTransferRouter
import org.koin.androidx.viewmodel.dsl.viewModel
import org.koin.core.context.loadKoinModules
import org.koin.core.module.Module
import org.koin.core.parameter.parametersOf
import org.koin.core.qualifier.named
import org.koin.dsl.module

private const val PIX_SHORTCUT_MAPPER_QUALIFIER = "PIX_SHORTCUT_MAPPER_QUALIFIER"
private const val PIX_SHORTCUT_PROVIDE_QUALIFIER = "PIX_SHORTCUT_PROVIDE_QUALIFIER"
private const val PIX_SHORTCUT_AVAILABILITY_QUALIFIER = "PIX_SHORTCUT_AVAILABILITY_QUALIFIER"

private val lazyLoadPixModule by lazy { loadKoinModules(pixModule) }

fun loadPixModule() = lazyLoadPixModule

private val pixModule = module {
    addFeatureToggles()
    addRouter()

    addApis()
    addRepositories()
    addMappers()
    addBusiness()
    addViewModels()
    addValidators()
    addHelpers()

    addShortcuts()
    addFactoryResourceProvider()
    addNavigation()

    analytics()
}

private fun Module.addFeatureToggles() {
    factory {
        val toggle: FeatureToggle = get()
        toggle.addDefaultValues(getPixDefaultFeatureToggle())
    }
}

private fun Module.addRouter() {
    factory<BankingPixRouter> { BankingPixRouterImpl(onboardingRepository = get()) }
    factory<TransactionRouter> { TransactionRouterImpl() }
    factory<HelpRouter> { HelpRouterImpl() }
    factory<PixPaymentRouter> { PixPaymentRouterImpl() }
    factory<BankingTransferRouter> { BankingTransferRouterImpl() }
}

private fun Module.addApis() {
    single<PixAPI> { get<MoshiHttp>().create() }
    single<TransactionLimitAPI> { get<MoshiHttp>().create() }
}

private fun Module.addRepositories() {
    factory<OnboardingRepository> { OnboardingRepositoryImpl(dataRepository = get()) }
    factory<PixShortcutRepository> {
        PixShortcutRepositoryImpl(
            pixShortcutList = get(named(PIX_SHORTCUT_PROVIDE_QUALIFIER)),
            bankingShortcutAvailability = get(named(PIX_SHORTCUT_AVAILABILITY_QUALIFIER))
        )
    }
    factory<InstitutionsRepository> {
        InstitutionsRepositoryImpl(
            pixAPI = get(),
            apiCaller = get(),
            institutionMapper = get()
        )
    }
    factory<PixQrCodeReceiveRepository> { PixQrCodeReceiveRepositoryImpl(api = get()) }
    single<PixRepository> { PixRepositoryImpl(api = get()) }
    factory<PixQrCodeConsultRepository> {
        PixQrCodeConsultRepositoryImpl(
            pixAPI = get(),
            apiCaller = get(),
            mapper = get()
        )
    }
    factory<PixContactsRepository> {
        PixContactsRepositoryImpl(
            api = get(), mapper = get(), safeApiCaller = get()
        )
    }
    factory<PixLimitsRepository> {
        PixLimitsRepositoryImpl(
            limitAPI = get(),
            limitMapper = get(),
            safeApiCaller = get()
        )
    }
    factory<UpdatePixLimitRepository> {
        UpdatePixLimitRepositoryImpl(
            api = get(),
            safeApiCaller = get(),
            reqMapper = get(),
            resMapper = get(),
            provider = get()
        )
    }
    factory<PixContactsRecordRepository> {
        PixContactsRecordRepositoryImpl(
            api = get(),
            safeApiCaller = get(),
            reqMapper = get(),
            provider = get()
        )
    }
    factory<PixLimitsPeriodNocturnEditRepository> {
        PixLimitsPeriodNocturnEditRepositoryImpl(
            api = get(),
            safeApiCaller = get(),
            reqMapper = get(),
            resMapper = get(),
            provider = get()
        )
    }

    factory<PixContactsDeleteRepository> {
        PixContactsDeleteRepositoryImpl(
            api = get(),
            safeApiCaller = get(),
            requestMapper = get()
        )
    }

    factory<PixTransferContactRepository> {
        PixTransferContactRepositoryImpl(
            api = get(),
            mapper = get(),
            safeApiCaller = get()
        )
    }

    factory<PixTransferContactDeleteRepository> {
        PixTransferContactDeleteRepositoryImpl(
            api = get(),
            requestMapper = get(),
            responseMapper = get(),
            safeApiCaller = get()
        )
    }
}

private fun Module.addMappers() {
    factory<PixKeyMapper> { PixKeyMapperImpl() }
    factory<PixKeyClaimMapper> { PixKeyClaimMapperImpl(resourceProvider = get()) }
    factory<PixKeyTransferFieldMapper> { PixKeyTransferFieldMapperImpl(resourceProvider = get()) }
    factory<PixKeyTransferMapper> { PixKeyTransferMapperImpl() }
    factory<PixKeyPaymentRequestMapper> { PixKeyPaymentRequestMapperImpl(bankCrypto = get()) }
    factory<PixKeyPaymentResponseMapper> { PixKeyPaymentResponseMapperImpl() }
    factory<PixTransferErrorMapper> { PixTransferErrorMapperImpl(resourceProvider = get()) }
    factory<PixKeySummaryMapper> { PixKeySummaryMapperImpl(resourceProvider = get()) }
    factory<PixKeyScheduleMapper> { PixKeyScheduleMapperImpl(bankCrypto = get()) }
    factory<PixPaymentLimitExceededUnwrap> { PixPaymentLimitExceededUnwrapImpl(errorMapper = get()) }
    factory<PixPaymentPasswordUnwrap> { PixPaymentPasswordUnwrapImpl(errorMapper = get()) }
    factory { InstitutionMapper() }
    factory<PixQrCodeReceiveMapper> { PixQrCodeReceiveMapperImpl() }
    factory<PixInsertTransferMapper> { PixInsertTransferMapperImpl(bankCrypto = get()) }
    factory<PixQrCodeTransferMapper> { PixQrCodeTransferMapperImpl() }
    factory<PixQrCodeConsultMapper> { PixQrCodeConsultMapperImpl() }
    factory<PixQrCodeExceptionMapper> { PixQrCodeExceptionMapperImpl(resourceProvider = get()) }
    factory<PixContactResponseMapper> { PixContactResponseMapperImpl(resourceProvider = get()) }
    factory<PixLimitsMapper> { PixLimitsMapperImpl() }
    factory<PixLimitUpdateRequestMapper> { PixLimitUpdateRequestMapperImpl(bankCrypto = get()) }
    factory<PixLimitUpdateResponseMapper> { PixLimitUpdateResponseMapperImpl() }
    factory<PixLimitsEditMapper> { PixLimitsEditMapperImpl(resourceProvider = get()) }
    factory<PixContactsRecordMapper> { PixContactRecordRequestMapperImpl() }
    factory<PixContactAddManualMapper> { PixContactAddManualMapperImpl(bankCrypto = get()) }
    factory<PixContactAddKeyMapper> { PixContactAddKeyMapperImpl(bankCrypto = get()) }
    factory<PixLimitsPeriodNocturnRequestMapper> { PixLimitsPeriodNocturnRequestMapperImpl(bankCrypto = get()) }
    factory<PixLimitsPeriodNocturnResponseMapper> { PixLimitsPeriodNocturnResponseMapperImpl() }
    factory<PixContactsDeleteRequestMapper> { PixContactsDeleteRequestMapperImpl() }
    factory<PixDetailContactMapper> { PixDetailContactMapperImpl() }
    factory<PixAccountTransferMapper> { PixAccountTransferMapperImpl(resourceProvider = get()) }
    factory<PixTransferContactResponseMapper> { PixTransferContactResponseMapperImpl() }
    factory<PixTransferContactDeleteRequestMapper> { PixTransferContactDeleteRequestMapperImpl() }
    factory<PixTransferContactDeleteResponseMapper> { PixTransferContactDeleteResponseMapperImpl() }
}

private fun Module.addBusiness() {
    factory<OnboardingBusiness> { OnboardingBusinessImpl(onboardingRepository = get()) }
    factory { PixShortcutBusiness(pixShortcutRepository = get()) }
    factory<ListPixBusiness> {
        ListPixBusinessImpl(
            safeApiCaller = get(),
            pixRepository = get(),
            pixKeyMapper = get()
        )
    }
    factory<RegisterPixBusiness> {
        RegisterPixBusinessImpl(
            safeApiCaller = get(),
            pixRepository = get()
        )
    }
    factory<ClaimsPixBusiness> {
        ClaimsPixBusinessImpl(
            safeApiCaller = get(),
            pixRepository = get(),
            mapper = get()
        )
    }
    factory {
        RefundBusiness(
            apiCaller = get(),
            repository = get(),
            transferPixBusiness = get(),
            bankCrypto = get()
        )
    }
    factory<TransferPixBusiness> {
        TransferPixBusinessImpl(
            safeApiCaller = get(),
            pixRepository = get(),
            pixKeyTransferMapper = get(),
            paymentRequestMapper = get(),
            paymentResponseMapper = get()
        )
    }
    factory<SchedulePixBusiness> {
        SchedulePixBusinessImpl(
            safeApiCaller = get(),
            pixRepository = get(),
            scheduleMapper = get(),
            paymentResponseMapper = get()
        )
    }
    factory<InstitutionBusiness> { InstitutionBusinessImpl(institutionsRepository = get()) }
    factory<PixQrCodeReceiveBusiness> {
        PixQrCodeReceiveBusinessImpl(
            safeApiCaller = get(),
            pixQrCodeReceiveRepository = get(),
            pixQrCodeReceiveMapper = get()
        )
    }
    factory<PixQrCodeConsultBusiness> { PixQrCodeConsultBusinessImpl(qrCodeConsultRepository = get()) }
    factory<UpdatePixLimitBusiness> { UpdatePixLimitBusinessImpl(repository = get()) }
    factory<PixAccountTransferBusiness> { PixAccountTransferBusinessImpl(resourceProvider = get()) }
    factory<PixContactsRecordBusiness> { PixContactsRecordBusinessImpl(repository = get()) }
    factory<PixContactsDeleteKeyBusiness> { PixContactsDeleteKeyBusinessImpl(repository = get()) }
    factory<PixLimitsPeriodNocturnEditBusiness > { PixLimitsPeriodNocturnEditBusinessImpl(repository = get()) }
    factory<PixContactsBusiness> { PixContactsBusinessImpl(contactsRepository = get()) }
    factory<PixTransferContactBusiness> { PixTransferContactBusinessImpl(transferContactsRepository = get()) }
    factory<PixTransferContactDeleteBusiness> { PixTransferContactDeleteBusinessImpl(repository = get()) }
}

private fun Module.addViewModels() {
    viewModel { OnboardingViewModel(onboardingBusiness = get(), onBoardingAnalytics = get()) }
    viewModel { (context: Context) ->
        HomePixViewModel(
            pixShortcutBusiness = get(),
            sharedGenerateShortcut = get(),
            pixHomePixNavigation = get { parametersOf(context) },
            subHomeAnalytics = get()
        )
    }
    viewModel {
        CountdownToExpireCodePixViewModel(
            secondsCountdownBusiness = get(),
            countdownResourceProvider = get()
        )
    }
    viewModel { PixKeysListViewModel(listPixBusiness = get(), pixKeysListAnalytics = get()) }
    viewModel { (hasCpfRegistered: Boolean) -> PixKeySelectionViewModel(hasCpfRegistered = hasCpfRegistered) }
    viewModel { PixKeySelectionAnalyticsViewModel(analytics = get())}
    viewModel { (pixKeyType: PixKeyType) ->
        PixKeyRegisterViewModel(
            pixKeyType = pixKeyType,
            registerPixBusiness = get(),
            cpfBusiness = get(),
            resourceProvider = get(),
            pixKeyRegisterAnalytics = get()
        )
    }
    viewModel { PixKeyDeleteViewModel(registerPixBusiness = get()) }
    viewModel { (pixKeyValue: String?, pixKeyType: PixKeyType, pixKeyStatus: PixKeyStatus) ->
        PixKeyRegisterClaimsViewModel(
            pixKeyValue = pixKeyValue,
            pixKeyType = pixKeyType,
            pixKeyStatus = pixKeyStatus,
            claimsPixBusiness = get(),
        )
    }
    viewModel { InputCodePixViewModel(analytics = get()) }
    viewModel { (pixKey: PixKey?) ->
        PixKeysClaimsViewModel(
            pixKey = pixKey,
            claimsPixBusiness = get(),
            resourceProvider = get(),
            claimsDataMapper = get()
        )
    }
    viewModel {
        PixKeyTransferFieldViewModel(
            pixKeyTransferMapper = get(),
            pixKeyTransferValidator = get()
        )
    }
    viewModel { PixKeyTransferViewModel(transferPixBusiness = get(), errorMapper = get()) }
    viewModel { (transferData: PixKeyTransferData) ->
        PixKeyTransferValueViewModel(
            transferData = transferData,
            balanceBusiness = get()
        )
    }
    viewModel { (maxRefundValue: String) ->
        RefundTransferViewModel(maxRefundValue = maxRefundValue, balanceBusiness = get())
    }
    viewModel { (transferData: PixKeyTransferData) ->
        PixKeyTransferSummaryViewModel(
            transferData = transferData,
            transferPixBusiness = get(),
            pixPaymentLimitExceededUnwrap = get(),
            summaryMapper = get(),
            schedulePixBusiness = get(),
            pixPaymentPasswordUnwrap = get()
        )
    }

    viewModel { PixTransferErrorViewModel(resourceProvider = get()) }
    viewModel { (idTransactionToRefund: String, valueToRefund: String, description: String?) ->
        RefundViewModel(
            idTransactionToRefund = idTransactionToRefund,
            valueToRefund = valueToRefund,
            description = description,
            refundBusiness = get(),
            pixPaymentLimitExceededUnwrap = get(),
            summaryMapper = get(),
            pixPaymentPasswordUnwrap = get()
        )
    }
    viewModel {
        PixInstitutionTransferViewModel(institutionBusiness = get())
    }
    viewModel { PixTransferContactsViewModel(transferContactBusiness = get()) }
    viewModel { PixContactsInstitutionInsertViewModel(institutionBusiness = get()) }
    viewModel { PixInsertTransferNavViewModel(pixInsertTransferMapper = get()) }
    viewModel { PixAccountTransferViewModel(accountBusiness = get(), accountMapper = get()) }
    viewModel { PixDataTransferViewModel() }
    viewModel { PixQrCodeKeySelectionViewModel(listPixBusiness = get()) }
    viewModel { PixQrCodeReceiveNavViewModel() }
    viewModel { (pixKey: PixKey) ->
        PixQrCodeValueViewModel(
            pixKey = pixKey,
            pixQrCodeReceiveBusiness = get()
        )
    }
    viewModel { (pixQrCodeData: PixQrCodeReceiveData) ->
        PixQrCodeShareViewModel(
            pixQrCodeData = pixQrCodeData,
            bitmapToBase64 = get()
        )
    }
    viewModel { PixQrCodeTransferNavViewModel(mapper = get()) }
    viewModel { PixTransferPermissionViewModel() }
    viewModel { PixQrCodeReaderViewModel() }
    viewModel { (code: String?) ->
        PixQrCodeInsertViewModel(
            emv = code,
            pixQrCodeConsultBusiness = get(),
            exceptionMapper = get()
        )
    }
    viewModel { PixTransferNavViewModel() }
    viewModel { PixContactsViewModel(contactsBusiness = get()) }
    viewModel { (sectionsListData: PixSectionsListData) ->
        EditPixLimitsActivityViewModel(
            sectionsListData = sectionsListData,
            limitsEditMapper = get(),
            resourceProvider = get()
        )
    }
    viewModel { UpdatePixLimitViewModel(business = get(), limitsEditMapper = get()) }
    viewModel { PixLimitsHomeViewModel(repository = get()) }
    viewModel { PixRegisterTermsViewModel(analytics = get()) }
    viewModel { InputConfirmKeyPixViewModel(analytics = get())}
    viewModel { PixKeyRegisterCpfViewModel(analytics = get())}
    viewModel { AddPixContactViewModel(transferPixBusiness = get()) }
    viewModel { ManualInsertionAccountBankInformationActivityViewModel() }
    viewModel {
        PixContactAddConfirmViewModel(
            business = get(),
            pixKeyMapper = get(),
            pixManualMapper = get()
        )
    }
    viewModel { (deleteKeyData: PixContactsDeleteKeyData) ->
        PixContactsDeleteConfirmViewModel(
            contactsDeleteKeyData = deleteKeyData,
            deleteContactKeyBusiness = get()
        )
    }
    viewModel { (contactData: PixContactData) ->
        PixDetailContactViewModel(
            pixContactData = contactData,
            pixDetailContactMapper = get()
        )
    }
    viewModel { PixLimitsPeriodNocturnEditViewModel(business = get()) }
    viewModel { PixTransferContactDetailsViewModel(transferPixBusiness = get(), errorMapper = get()) }
    viewModel { PixTransferContactViewModel() }
    viewModel { PixTransferContactDeleteConfirmViewModel(business = get()) }
}

private fun Module.addFactoryResourceProvider() {
    factory<CountdownResourceProvider> {
        CountdownResourceProviderImpl(resourceProvider = get())
    }
}

private fun Module.addShortcuts() {
    factory<ProvideBankingShortcutList<PixShortcuts>>(named(PIX_SHORTCUT_PROVIDE_QUALIFIER)) { ProvidePixShortcuts() }
    factory<BankingShortcutFeatureToggleKeyMapper<PixShortcuts>>(named(PIX_SHORTCUT_MAPPER_QUALIFIER)) { PixShortcutFeatureToggleMapper() }
    factory<BankingShortcutAvailability<PixShortcuts>>(named(PIX_SHORTCUT_AVAILABILITY_QUALIFIER)) {
        PixShortcutAvailabilityImpl(
            featureToggle = get(),
            pixShortcutFeatureToggleKeyMapper = get(named(PIX_SHORTCUT_MAPPER_QUALIFIER))
        )
    }
}

private fun Module.addNavigation() {
    factory<HomePixNavigation> { (context: Context) ->
        HomePixNavigationImpl(context = context, helpRouter = get())
    }
}

private fun Module.addValidators() {
    factory<PixKeyTransferValidator> { PixKeyTransferValidatorImpl() }
}


private fun Module.addHelpers() {
    factory<PixQrCodeShareHelper> { PixQrCodeShareHelperImpl() }
    factory<BitmapToBase64> { BitmapToBase64Impl() }
}

private fun Module.analytics() {
    factory<PixAnalytics> { PixAnalyticsImpl(analytics = get()) }
    factory {PixKeysListAnalytics(pixAnalytics = get()) }
    factory { OnBoardingAnalytics(pixAnalytics = get()) }
    factory { PixKeyRegisterAnalytics(pixAnalytics = get()) }
    factory { PixKeySelectionAnalytics(pixAnalytics = get()) }
    factory { InputCodePixAnalytics(pixAnalytics = get()) }
    factory { PixRegisterTermsAnalytics(pixAnalytics = get()) }
    factory { InputConfirmKeyPixAnalytics(pixAnalytics = get()) }
    factory { PixKeyRegisterCpfAnalytics(pixAnalytics = get()) }
}

private fun getPixDefaultFeatureToggle(): Map<String, Boolean> {
    return mapOf(
        HELP to false,
        MY_KEYS to false,
        MY_LIMITS to false,
        PIX_COPY_PASTE to false,
        QR_CODE to false,
        RECEIVE to false,
        TRANSFER to false
    )
}