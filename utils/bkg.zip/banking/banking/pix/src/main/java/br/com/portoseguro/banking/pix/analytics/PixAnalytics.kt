package br.com.portoseguro.banking.pix.analytics

import android.app.Activity

interface PixAnalytics {
    fun trackScreenView(
        activity: Activity,
        screen: String,
        itemName: String,
        subSection1: String? = null,
        subSection2: String? = null,
        subSection3: String? = null
    )

    fun trackAction(
        action: String,
        itemName: String,
        label: String? = null,
        subSection1: String? = null,
        subSection2: String? = null,
        subSection3: String? = null
    )

    fun trackAlert(
        action: String,
        alert: String,
        itemName: String,
        subSection1: String? = null,
        subSection2: String? = null,
        subSection3: String? = null,
        label: String? = null
    )

    fun trackingScreenError(
        activity: Activity,
        errorMessage: String,
        screen: String,
        itemName: String,
        subSection1: String? = null,
        subSection2: String? = null,
        subSection3: String? = null
    )

    object Actions {
        const val CLICK_IN_ = "click:"
        const val CLICK_BACK = "click:voltar"
        const val CLICK_CPF = "click:cpf"
        const val CLICK_PHONE_NUMBER = "click:numero-de-celular"
        const val CLICK_EMAIL = "click:email"
        const val CLICK_RANDOM_KEY = "click:chave-aleatoria"
        const val CLICK_REQUEST_TOKEN = "click:reenviar-codigo-validacao"

        const val FILLED_PHONE = "preencheu:celular"
        const val FILLED_EMAIL = "preencheu:email"
        const val FILLED_PHONE_CONFIRMATION_CODE = "preencheu:validacao-celular"
        const val FILLED_EMAIL_CONFIRMATION_CODE = "preencheu:validacao-email"

        const val ALERT = "aviso:pix"

        const val INPUT_FIELD_ERROR = "retorno:pix:cadastrar-chave:validacao:erro"
        const val INPUT_VERIFICATION_CODE_ERROR = "retorno:pix:cadastrar-chave:preenchimento:erro"
    }

    object Screens {
        const val UNDEFINED = "indefinido"

        object OnBoarding {
            const val WELCOME = "conta-digital:pix:tutorial:bem-vindo"
            const val HOW_ITS_WORKS = "conta-digital:pix:tutorial:como-funciona"
            const val KEYS_TYPE = "conta-digital:pix:tutorial:tipos-de-chaves"
            const val REGISTER_YOUR_KEY = "conta-digital:pix:tutorial:cadastre-sua-chave"
        }

        object Keys {
            const val MY_KEYS = "conta-digital:pix:minhas-chaves:interna"
            const val TERM_REGISTER_KEYS = "conta-digital:pix:minhas-chaves:cadastrar-chave:termos"
            const val CHOOSE_YOUR_KEY = "conta-digital:pix:minhas-chaves:cadastrar-chave:escolha-sua-chave"
            const val REGISTER_CPF = "conta-digital:pix:minhas-chaves:cadastrar-chave:cpf"
            const val REGISTER_PHONE = "conta-digital:pix:minhas-chaves:cadastrar-chave:celular-inserir"
            const val REGISTER_EMAIL = "conta-digital:pix:minhas-chaves:cadastrar-chave:email-inserir"
            const val REGISTER_RANDOM_KEY = "conta-digital:pix:minhas-chaves:cadastrar-chave:aleatoria"
            const val VALID_PHONE = "conta-digital:pix:minhas-chaves:cadastrar-chave:celular-validar"
            const val VALID_EMAIL = "conta-digital:pix:minhas-chaves:cadastrar-chave:email-validar"
            const val SCREEN_ERROR = "conta-digital:pix:minhas-chaves:erro"
        }
    }

    object Category {
        const val DIGITAL_ACCOUNT = "app:mundoporto:conta-digital"
    }

    object Sections {
        const val DIGITAL_ACCOUNT = "conta-digital"
        const val PIX = "pix"
        const val TUTORIAL = "tutorial"
        const val MY_KEYS = "minhas-chaves"
        const val REGISTER_KEYS = "cadastrar-chaves"
    }

    object Alert {
        const val PIX_ALERT_WITH = "conta-digital:pix:"
    }

    object Label {
        const val PHONE = "celular"
        const val EMAIL = "email"
        const val CPF = "cpf"
        const val RANDOM_KEY = "aleatoria"
        const val KEYS_REGISTER_SUCCESS = "sucesso-cadastro-chave-"
    }
}