package br.com.portoseguro.banking.pix.analytics

import android.app.Activity
import io.mockk.mockk
import io.mockk.verify
import org.junit.Before
import org.junit.Test

class PixKeyRegisterAnalyticsTest {

    private val pixAnalytics = mockk<PixAnalytics>(relaxed = true)
    private lateinit var pixKeyRegisterAnalytics: PixKeyRegisterAnalytics

    @Before
    fun setUp() {
        pixKeyRegisterAnalytics = PixKeyRegisterAnalytics(pixAnalytics)
    }

    @Test
    fun trackingChooseCPF() {
        //Act
        pixKeyRegisterAnalytics.trackingChooseCPF()

        //Assert
        verify {
            pixAnalytics.trackAction(
                action = PixAnalytics.Actions.CLICK_CPF,
                itemName = PixAnalytics.Screens.Keys.CHOOSE_YOUR_KEY,
                subSection1 = PixAnalytics.Sections.PIX,
                subSection2 = PixAnalytics.Sections.TUTORIAL,
                subSection3 = PixAnalytics.Sections.REGISTER_KEYS
            )
        }
    }

    @Test
    fun trackingChoosePhoneNumber() {
        //Act
        pixKeyRegisterAnalytics.trackingChoosePhoneNumber()

        //Assert
        verify {
            pixAnalytics.trackAction(
                action = PixAnalytics.Actions.CLICK_PHONE_NUMBER,
                itemName = PixAnalytics.Screens.Keys.CHOOSE_YOUR_KEY,
                subSection1 = PixAnalytics.Sections.PIX,
                subSection2 = PixAnalytics.Sections.TUTORIAL,
                subSection3 = PixAnalytics.Sections.REGISTER_KEYS
            )
        }
    }

    @Test
    fun trackingChooseEmail() {
        //Act
        pixKeyRegisterAnalytics.trackingChooseEmail()

        //Assert
        verify {
            pixAnalytics.trackAction(
                action = PixAnalytics.Actions.CLICK_EMAIL,
                itemName = PixAnalytics.Screens.Keys.CHOOSE_YOUR_KEY,
                subSection1 = PixAnalytics.Sections.PIX,
                subSection2 = PixAnalytics.Sections.TUTORIAL,
                subSection3 = PixAnalytics.Sections.REGISTER_KEYS
            )
        }
    }

    @Test
    fun trackingChooseRandomKey() {
        //Act
        pixKeyRegisterAnalytics.trackingChooseRandomKey()

        //Assert
        verify {
            pixAnalytics.trackAction(
                action = PixAnalytics.Actions.CLICK_RANDOM_KEY,
                itemName = PixAnalytics.Screens.Keys.CHOOSE_YOUR_KEY,
                subSection1 = PixAnalytics.Sections.PIX,
                subSection2 = PixAnalytics.Sections.TUTORIAL,
                subSection3 = PixAnalytics.Sections.REGISTER_KEYS
            )
        }
    }

    @Test
    fun trackingClickButtonFromRandomKey() {
        //Arrange
        val buttonName = "action"

        //Act
        pixKeyRegisterAnalytics.trackingClickButtonFromRandomKey(buttonName)

        //Assert
        verify {
            pixAnalytics.trackAction(
                action = PixAnalytics.Actions.CLICK_IN_ + buttonName,
                itemName = PixAnalytics.Screens.Keys.REGISTER_RANDOM_KEY,
                subSection1 = PixAnalytics.Sections.PIX,
                subSection2 = PixAnalytics.Sections.TUTORIAL,
                subSection3 = PixAnalytics.Sections.REGISTER_KEYS
            )
        }
    }

    @Test
    fun trackingClickBackFromRandomKey() {
        //Act
        pixKeyRegisterAnalytics.trackingClickBackFromRandomKey()

        //Assert
        verify {
            pixAnalytics.trackAction(
                action = PixAnalytics.Actions.CLICK_BACK,
                itemName = PixAnalytics.Screens.Keys.REGISTER_RANDOM_KEY,
                subSection1 = PixAnalytics.Sections.PIX,
                subSection2 = PixAnalytics.Sections.TUTORIAL,
                subSection3 = PixAnalytics.Sections.REGISTER_KEYS
            )
        }
    }

    @Test
    fun trackingRandomKeyScreen() {
        //Arrange
        val activity = mockk<Activity>()

        //Act
        pixKeyRegisterAnalytics.trackingRandomKeyScreen(activity)

        //Assert
        verify {
            pixAnalytics.trackScreenView(
                activity = activity,
                screen = PixAnalytics.Screens.Keys.REGISTER_RANDOM_KEY,
                itemName = PixAnalytics.Screens.Keys.REGISTER_RANDOM_KEY,
                subSection1 = PixAnalytics.Sections.PIX,
                subSection2 = PixAnalytics.Sections.TUTORIAL,
                subSection3 = PixAnalytics.Sections.REGISTER_KEYS
            )
        }
    }
}