package br.com.portoseguro.banking.pix.repository

import br.com.portoseguro.banking.pix.data.repository.onboarding.OnboardingRepository
import br.com.portoseguro.banking.pix.data.repository.onboarding.OnboardingRepositoryImpl
import br.com.portoseguro.superapp.core.repository.DataRepository
import br.com.portoseguro.superapp.core.repository.DataSourceType
import io.mockk.every
import io.mockk.mockk
import io.mockk.verify
import org.junit.Before
import org.junit.Test
import org.junit.Assert.assertEquals

class OnboardingRepositoryTest {

    private val dataRepository = mockk<DataRepository>(relaxed = true)
    private lateinit var onboardingRepository: OnboardingRepository

    @Before
    fun setup() {
        onboardingRepository = OnboardingRepositoryImpl(dataRepository)
    }

    @Test
    fun isFirstAccess_whenFirstAccess_shouldReturnTrue() {
        every {
            dataRepository.get(
                key = ONBOARDING_FIRST_ACCESS_KEY,
                default = true,
                from = DataSourceType.ENCRYPTED_PERSISTENCE
            )
        } returns IS_FIRST_ACCESS

        val result = onboardingRepository.isFirstAccess()

        assertEquals(IS_FIRST_ACCESS, result)
    }

    @Test
    fun isFirstAccess_whenIsNotFirstAccess_shouldReturnFalse() {
        every {
            dataRepository.get(
                key = ONBOARDING_FIRST_ACCESS_KEY,
                default = true,
                from = DataSourceType.ENCRYPTED_PERSISTENCE
            )
        } returns IS_FIRST_ACCESS.not()

        val result = onboardingRepository.isFirstAccess()

        assertEquals(IS_FIRST_ACCESS.not(), result)
    }

    @Test
    fun saveFirstAccess_shouldSetEncryptedPersistence_withFalse() {
        onboardingRepository.saveFirstAccess()

        verify {
            dataRepository.set(
                key = ONBOARDING_FIRST_ACCESS_KEY,
                value = false,
                from = DataSourceType.ENCRYPTED_PERSISTENCE
            )
        }
    }

    companion object {
        private const val ONBOARDING_FIRST_ACCESS_KEY = "PIX_FIRST_ACCESS_SEE"
        private const val IS_FIRST_ACCESS = true
    }
}