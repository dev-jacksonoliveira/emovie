package br.com.portoseguro.banking.pix.analytics

import android.app.Activity
import io.mockk.mockk
import io.mockk.verify
import org.junit.Before
import org.junit.Test

class PixKeyListAnalyticsTest {

    private val pixAnalytics = mockk<PixAnalytics>(relaxed = true)
    private lateinit var pixKeySelectionAnalytics: PixKeysListAnalytics

    @Before
    fun setUp() {
        pixKeySelectionAnalytics = PixKeysListAnalytics(pixAnalytics)
    }

    @Test
    fun trackingMyKeysScreenView() {
        //Arrange
        val activity = mockk<Activity>()

        //Act
        pixKeySelectionAnalytics.trackingMyKeysScreenView(activity)

        //Assert
        verify {
            pixAnalytics.trackScreenView(
                activity = activity,
                screen = PixAnalytics.Screens.Keys.MY_KEYS,
                itemName = PixAnalytics.Screens.Keys.MY_KEYS,
                subSection1 = PixAnalytics.Sections.PIX,
                subSection2 = PixAnalytics.Sections.MY_KEYS
            )

        }
    }

    @Test
    fun trackingClickBack() {
        //Act
        pixKeySelectionAnalytics.trackingClickBack()

        //Assert
        verify {
            pixAnalytics.trackAction(
                action = PixAnalytics.Actions.CLICK_BACK,
                itemName = PixAnalytics.Screens.Keys.MY_KEYS,
                subSection1 = PixAnalytics.Sections.PIX,
                subSection2 = PixAnalytics.Sections.MY_KEYS
            )
        }
    }

    @Test
    fun trackingClickButton() {
        //Arrange
        val buttonName = "action"

        //Act
        pixKeySelectionAnalytics.trackingClickButton(buttonName)

        //Assert
        verify {
            pixAnalytics.trackAction(
                action = PixAnalytics.Actions.CLICK_IN_ + buttonName,
                itemName = PixAnalytics.Screens.Keys.MY_KEYS,
                subSection1 = PixAnalytics.Sections.PIX,
                subSection2 = PixAnalytics.Sections.MY_KEYS
            )
        }
    }

    @Test
    fun trackingAlert() {
        //Arrange
        val message = "alert"

        //Act
        pixKeySelectionAnalytics.trackingAlert(message)

        //Assert
        verify {
            pixAnalytics.trackAlert(
                action = PixAnalytics.Actions.ALERT,
                alert = PixAnalytics.Alert.PIX_ALERT_WITH + message,
                itemName = PixAnalytics.Screens.Keys.MY_KEYS,
                subSection1 = PixAnalytics.Sections.PIX,
                subSection2 = PixAnalytics.Sections.MY_KEYS,
                label = PixAnalytics.Label.KEYS_REGISTER_SUCCESS
            )
        }
    }
}