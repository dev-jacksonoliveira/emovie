package br.com.portoseguro.banking.pix.utils

import org.junit.Assert.assertEquals
import org.junit.Test


class MonetaryUtilsTest {

    @Test
    fun toMoney_withEmptyValue_shouldReturnZero() {
        assertEquals("R$ ".toMoney(), 0)
    }

    @Test
    fun toMoney_withZeroValue_shouldReturnZero() {
        assertEquals("R$ 0,00".toMoney(), 0)
    }

    @Test
    fun toMoney_withOneCent_shouldCorrectValue() {
        assertEquals("R$ 0,01".toMoney(), 1)
    }

    @Test
    fun toMoney_withNinetyNineCents_shouldReturnCorrectValue() {
        assertEquals("R$ 0,99".toMoney(), 99)
    }

    @Test
    fun toMoney_withOne_shouldReturnCorrectValue() {
        assertEquals("R$ 1,00".toMoney(), 100)
    }

    @Test
    fun toMoney_whenValueWithCents_shouldReturnCorrectValue() {
        assertEquals("R$ 17,99".toMoney(), 1799)
    }

    @Test
    fun toMoney_withThousandValue_shouldReturnCorrectValue() {
        assertEquals("R$ 1.500,00".toMoney(), 150000)
    }

    @Test
    fun toMoney_withThousandValueAndCents_shouldReturnCorrectValue() {
        assertEquals("R$ 1.500,98".toMoney(), 150098)
    }

    @Test
    fun toMoney_withBiggestValue_shouldReturnCorrectValue() {
        assertEquals("R$ 100.000.000,00".toMoney(), 10000000000)
    }

    @Test
    fun toMoney_withBiggestValueAndCents_shouldReturnCorrectValue() {
        assertEquals("R$ 100.000.000,99".toMoney(), 10000000099)
    }
}