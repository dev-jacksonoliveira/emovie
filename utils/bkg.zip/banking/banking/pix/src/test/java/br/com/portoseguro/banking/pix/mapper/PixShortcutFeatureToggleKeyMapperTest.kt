package br.com.portoseguro.banking.pix.mapper

import br.com.portoseguro.banking.sharedbanking.entity.shortcut.PixShortcuts
import br.com.portoseguro.banking.pix.data.mapper.PixShortcutFeatureToggleMapper
import org.junit.Before
import org.junit.Test

class PixShortcutFeatureToggleKeyMapperTest {

    private lateinit var mapper: PixShortcutFeatureToggleMapper

    @Before
    fun setup() {
        mapper = PixShortcutFeatureToggleMapper()
    }

    @Test
    fun invoke_shouldReturnStringCorrectly_whenPassOtherServiceHelp() {
        // ARRANGE
        val expected = "ft_conta_digital_ajuda"
        val input = PixShortcuts.OtherServices.Help

        // ACTION
        val result = mapper(input)

        // ASSERT
        assert(result == expected)
    }

    @Test
    fun invoke_shouldReturnStringCorrectly_whenPassOtherServiceMyKeys() {
        // ARRANGE
        val expected = "ft_conta_digital_pix_minhas_chaves"
        val input = PixShortcuts.OtherServices.MyKeys

        // ACTION
        val result = mapper(input)

        // ASSERT
        assert(result == expected)
    }

    @Test
    fun invoke_shouldReturnStringCorrectly_whenPassOtherServiceMyLimits() {
        // ARRANGE
        val expected = "ft_conta_digital_pix_meus_limites"
        val input = PixShortcuts.OtherServices.MyLimits

        // ACTION
        val result = mapper(input)

        // ASSERT
        assert(result == expected)
    }

    @Test
    fun invoke_shouldReturnStringCorrectly_whenPassShortcutTransfer() {
        // ARRANGE
        val expected = "ft_conta_digital_pix_transferir"
        val input = PixShortcuts.Shortcut.Transfer

        // ACTION
        val result = mapper(input)

        // ASSERT
        assert(result == expected)
    }

    @Test
    fun invoke_shouldReturnStringCorrectly_whenPassShortcutReceive() {
        // ARRANGE
        val expected = "ft_conta_digital_pix_receber"
        val input = PixShortcuts.Shortcut.Receive

        // ACTION
        val result = mapper(input)

        // ASSERT
        assert(result == expected)
    }

    @Test
    fun invoke_shouldReturnStringCorrectly_whenPassShortcutQrCode() {
        // ARRANGE
        val expected = "ft_conta_digital_pix_pagar_qrcode"
        val input = PixShortcuts.Shortcut.QrCode

        // ACTION
        val result = mapper(input)

        // ASSERT
        assert(result == expected)
    }

    @Test
    fun invoke_shouldReturnStringCorrectly_whenPassShortcutPixCopyPaster() {
        // ARRANGE
        val expected = "ft_conta_digital_pix_copia_cola"
        val input = PixShortcuts.Shortcut.PixCopyPaste

        // ACTION
        val result = mapper(input)

        // ASSERT
        assert(result == expected)
    }
}