package br.com.portoseguro.banking.pix.infrastructure

import androidx.lifecycle.LiveData
import androidx.lifecycle.Observer
import br.com.portoseguro.sharedentity.core.response.BackendWrappedResponse
import br.com.portoseguro.superapp.core.entities.WrappedResponse
import okhttp3.MediaType
import okhttp3.ResponseBody
import retrofit2.Response
import java.net.HttpURLConnection

internal fun <T : Any> T?.buildSuccessResponse(): WrappedResponse<T> =
    Response.success(BackendWrappedResponse(this))

internal fun <T : Any> buildErrorResponse(
    statusCode: Int = HttpURLConnection.HTTP_BAD_REQUEST,
    content: String = "{\"error\":\"Bad request\"}"
): WrappedResponse<T> = Response.error(
    statusCode,
    ResponseBody.create(MediaType.parse("application/json"), content)
)

internal fun <T> LiveData<T>.observeForTesting(observer: Observer<T>, block: () -> Unit) {
    try {
        observeForever(observer)
        block()
    } finally {
        removeObserver(observer)
    }
}