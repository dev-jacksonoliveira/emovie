package br.com.portoseguro.banking.pix.local

import br.com.portoseguro.banking.sharedbanking.entity.shortcut.PixShortcuts
import br.com.portoseguro.banking.pix.data.local.shortcut.PixShortcutAvailabilityImpl
import br.com.portoseguro.banking.pix.data.mapper.PixShortcutFeatureToggleMapper
import br.com.portoseguro.superapp.core.toggle.FeatureToggle
import io.mockk.every
import io.mockk.mockk
import org.junit.Before
import org.junit.Test

class PixShortcutAvailabilityImplTest {

    private lateinit var availability: PixShortcutAvailabilityImpl

    private val featureToggle = mockk<FeatureToggle>()
    private val mapper = mockk<PixShortcutFeatureToggleMapper>()

    @Before
    fun setup() {
        availability = PixShortcutAvailabilityImpl(featureToggle, mapper)
    }

    @Test
    fun check_shouldReturnTrue_whenShortcutMyKeysIsAvailable() {
        // ARRANGE
        val input = PixShortcuts.OtherServices.MyKeys
        every { mapper(input) } returns String()
        every { featureToggle.getValue(String()) } returns true

        // ACTION
        val result = availability.check(input)

        // ASSERT
        assert(result)
    }

    @Test
    fun check_shouldReturnTrue_whenShortcutMyLimitsIsAvailable() {
        // ARRANGE
        val input = PixShortcuts.OtherServices.MyLimits
        every { mapper(input) } returns String()
        every { featureToggle.getValue(String()) } returns true

        // ACTION
        val result = availability.check(input)

        // ASSERT
        assert(result)
    }

    @Test
    fun check_shouldReturnTrue_whenShortcutHelpIsAvailable() {
        // ARRANGE
        val input = PixShortcuts.OtherServices.Help
        every { mapper(input) } returns String()
        every { featureToggle.getValue(String()) } returns true

        // ACTION
        val result = availability.check(input)

        // ASSERT
        assert(result)
    }

    @Test
    fun check_shouldReturnTrue_whenShortcutTransferIsAvailable() {
        // ARRANGE
        val input = PixShortcuts.Shortcut.Transfer
        every { mapper(input) } returns String()
        every { featureToggle.getValue(String()) } returns true

        // ACTION
        val result = availability.check(input)

        // ASSERT
        assert(result)
    }

    @Test
    fun check_shouldReturnTrue_whenShortcutReceiveIsAvailable() {
        // ARRANGE
        val input = PixShortcuts.Shortcut.Receive
        every { mapper(input) } returns String()
        every { featureToggle.getValue(String()) } returns true

        // ACTION
        val result = availability.check(input)

        // ASSERT
        assert(result)
    }

    @Test
    fun check_shouldReturnTrue_whenShortcutQrCodeIsAvailable() {
        // ARRANGE
        val input = PixShortcuts.Shortcut.QrCode
        every { mapper(input) } returns String()
        every { featureToggle.getValue(String()) } returns true

        // ACTION
        val result = availability.check(input)

        // ASSERT
        assert(result)
    }

    @Test
    fun check_shouldReturnTrue_whenShortcutPixCopyPasteIsAvailable() {
        // ARRANGE
        val input = PixShortcuts.Shortcut.PixCopyPaste
        every { mapper(input) } returns String()
        every { featureToggle.getValue(String()) } returns true

        // ACTION
        val result = availability.check(input)

        // ASSERT
        assert(result)
    }
}