package br.com.portoseguro.banking.pix.analytics

import android.app.Activity
import io.mockk.mockk
import io.mockk.verify
import org.junit.Before
import org.junit.Test

class OnBoardingAnalyticsTest {

    private val pixAnalytics = mockk<PixAnalytics>(relaxed = true)
    private lateinit var onBoardingAnalytics: OnBoardingAnalytics

    @Before
    fun setUp() {
        onBoardingAnalytics = OnBoardingAnalytics(pixAnalytics)
    }

    fun trackingClickBack() {
        //Act
        onBoardingAnalytics.trackingClickBack()

        //Assert
        verify {
            pixAnalytics.trackAction(
                action = PixAnalytics.Actions.CLICK_BACK,
                itemName = PixAnalytics.Screens.OnBoarding.WELCOME,
                subSection1 = PixAnalytics.Sections.PIX,
                subSection2 = PixAnalytics.Sections.TUTORIAL
            )
        }
    }

    @Test
    fun trackingClickButton() {
        //Arrange
        val action = "test-action"

        //Act
        onBoardingAnalytics.trackingClickButton(action)

        //Assert
        verify {
            pixAnalytics.trackAction(
                action = PixAnalytics.Actions.CLICK_IN_ + action,
                itemName = PixAnalytics.Screens.OnBoarding.WELCOME,
                subSection1 = PixAnalytics.Sections.PIX,
                subSection2 = PixAnalytics.Sections.TUTORIAL
            )
        }
    }

    @Test
    fun trackingWelcomeScreen() {
        //Arrange
        val activity = mockk<Activity>()

        //Act
        onBoardingAnalytics.trackingScreen(activity, OnBoardingAnalytics.WELCOME)

        //Assert
        verify {
            pixAnalytics.trackScreenView(
                activity = activity,
                screen = PixAnalytics.Screens.OnBoarding.WELCOME,
                itemName = PixAnalytics.Screens.OnBoarding.WELCOME,
                subSection1 = PixAnalytics.Sections.PIX,
                subSection2 = PixAnalytics.Sections.TUTORIAL
            )
        }
    }

    @Test
    fun trackingKeyTypesScreen() {
        //Arrange
        val activity = mockk<Activity>()

        //Act
        onBoardingAnalytics.trackingScreen(activity, OnBoardingAnalytics.KEY_TYPES)

        //Assert
        verify {
            pixAnalytics.trackScreenView(
                activity = activity,
                screen = PixAnalytics.Screens.OnBoarding.KEYS_TYPE,
                itemName = PixAnalytics.Screens.OnBoarding.WELCOME,
                subSection1 = PixAnalytics.Sections.PIX,
                subSection2 = PixAnalytics.Sections.TUTORIAL
            )
        }
    }

    @Test
    fun trackingHowItsWorkScreen() {
        //Arrange
        val activity = mockk<Activity>()

        //Act
        onBoardingAnalytics.trackingScreen(activity, OnBoardingAnalytics.HOW_ITS_WORKS)

        //Assert
        verify {
            pixAnalytics.trackScreenView(
                activity = activity,
                screen = PixAnalytics.Screens.OnBoarding.HOW_ITS_WORKS,
                itemName = PixAnalytics.Screens.OnBoarding.WELCOME,
                subSection1 = PixAnalytics.Sections.PIX,
                subSection2 = PixAnalytics.Sections.TUTORIAL
            )
        }
    }

    @Test
    fun trackingRegisterScreen() {
        //Arrange
        val activity = mockk<Activity>()

        //Act
        onBoardingAnalytics.trackingScreen(activity, OnBoardingAnalytics.REGISTER)

        //Assert
        verify {
            pixAnalytics.trackScreenView(
                activity = activity,
                screen = PixAnalytics.Screens.OnBoarding.REGISTER_YOUR_KEY,
                itemName = PixAnalytics.Screens.OnBoarding.WELCOME,
                subSection1 = PixAnalytics.Sections.PIX,
                subSection2 = PixAnalytics.Sections.TUTORIAL
            )
        }
    }
}