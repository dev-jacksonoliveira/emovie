package br.com.portoseguro.banking.pix.analytics

import android.app.Activity
import br.com.portoseguro.superapp.core.analytics.Analytics
import br.com.portoseguro.superapp.core.analytics.model.ViewItem
import br.com.portoseguro.superapp.core.business.user.client.ClientHashMemory
import io.mockk.every
import io.mockk.mockk
import io.mockk.slot
import io.mockk.verify
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner

@RunWith(RobolectricTestRunner::class)
class PixAnalyticsImplTest {

    private val analytics = mockk<Analytics>(relaxed = true)
    private val clientHashMemory = mockk<ClientHashMemory>(relaxed = true)
    private val viewItemSlot = slot<ViewItem>()
    private lateinit var pixAnalyticsImpl: PixAnalyticsImpl

    @Before
    fun setUp() {
        pixAnalyticsImpl = PixAnalyticsImpl(analytics)
    }

    @Test
    fun trackScreenView() {
        //Arrange
        val activity = mockk<Activity>(relaxed = true)

        //Act
        pixAnalyticsImpl.trackScreenView(
            activity = activity,
            screen = PixAnalytics.Screens.OnBoarding.WELCOME,
            itemName = PixAnalytics.Screens.OnBoarding.WELCOME
        )

        //Assert
        verify { analytics.trackViewItem(any()) }
    }

    @Test
    fun trackAction() {
        //Act
        pixAnalyticsImpl.trackAction(
            PixAnalytics.Actions.CLICK_BACK,
            PixAnalytics.Screens.OnBoarding.WELCOME
        )

        //Assert
        verify { analytics.trackAction(any()) }
    }

    @Test
    fun `test addExtraParams indirectly`() {
        //Arrange
        val activity = mockk<Activity>(relaxed = true)
        val hash = "1234"
        every { clientHashMemory.getHash() } returns hash

        //Act
        pixAnalyticsImpl.trackScreenView(
            activity = activity,
            screen = PixAnalytics.Screens.OnBoarding.WELCOME,
            itemName = PixAnalytics.Screens.OnBoarding.WELCOME,
            subSection1 = PixAnalytics.Sections.DIGITAL_ACCOUNT,
            subSection2 = PixAnalytics.Sections.PIX
        )

        //Assert
        verify { analytics.trackViewItem(capture(viewItemSlot)) }
        assert(clientHashMemory.getHash().toString() == hash)
    }
}