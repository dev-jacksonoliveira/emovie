package br.com.portoseguro.banking.pix.analytics

import android.app.Activity
import io.mockk.mockk
import io.mockk.verify
import org.junit.Before
import org.junit.Test

class PixRegisterTermsAnalyticsTest {

    private val pixAnalytics = mockk<PixAnalytics>(relaxed = true)
    private lateinit var pixRegisterTermsAnalytics: PixRegisterTermsAnalytics

    @Before
    fun setUp() {
        pixRegisterTermsAnalytics = PixRegisterTermsAnalytics(pixAnalytics)
    }

    @Test
    fun trackingRegisterScreen() {
        //Arrange
        val activity = mockk<Activity>()

        //Act
        pixRegisterTermsAnalytics.trackingRegisterScreen(activity)

        //Assert
        verify {
            pixAnalytics.trackScreenView(
                activity = activity,
                screen = PixAnalytics.Screens.Keys.TERM_REGISTER_KEYS,
                itemName = PixAnalytics.Screens.Keys.TERM_REGISTER_KEYS,
                subSection1 = PixAnalytics.Sections.PIX,
                subSection2 = PixAnalytics.Sections.MY_KEYS,
                subSection3 = PixAnalytics.Sections.REGISTER_KEYS
            )
        }
    }

    @Test
    fun trackingClickButton() {
        //Arrange
        val buttonName = "action"

        //Act
        pixRegisterTermsAnalytics.trackingClickButton(buttonName)

        //Assert
        verify {
            pixAnalytics.trackAction(
                action = PixAnalytics.Actions.CLICK_IN_ + buttonName,
                itemName = PixAnalytics.Screens.Keys.TERM_REGISTER_KEYS,
                label  = null,
                subSection1 = PixAnalytics.Sections.PIX,
                subSection2 = PixAnalytics.Sections.MY_KEYS,
                subSection3 = PixAnalytics.Sections.REGISTER_KEYS
            )
        }
    }
}