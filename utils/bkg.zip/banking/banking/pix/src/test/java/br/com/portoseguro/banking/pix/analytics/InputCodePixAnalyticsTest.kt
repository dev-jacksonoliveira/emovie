package br.com.portoseguro.banking.pix.analytics

import android.app.Activity
import io.mockk.mockk
import io.mockk.verify
import org.junit.Before
import org.junit.Test

class InputCodePixAnalyticsTest {

    private val pixAnalytics = mockk<PixAnalytics>(relaxed = true)
    private lateinit var inputCodePixAnalytics: InputCodePixAnalytics

    @Before
    fun setUp() {
        inputCodePixAnalytics = InputCodePixAnalytics(pixAnalytics)
    }

    @Test
    fun trackingInputCodeScreen() {
        //Arrange
        val activity = mockk<Activity>()

        //Act
        inputCodePixAnalytics.trackingInputCodeScreen(activity)

        //Assert
        verify {
            pixAnalytics.trackScreenView(
                activity = activity,
                screen = PixAnalytics.Screens.Keys.VALID_PHONE,
                itemName = PixAnalytics.Screens.Keys.VALID_PHONE,
                subSection1 = PixAnalytics.Sections.PIX,
                subSection2 = PixAnalytics.Sections.MY_KEYS,
                subSection3 = PixAnalytics.Sections.REGISTER_KEYS
            )
        }
    }

    @Test
    fun trackingResendCode() {
        //Arrange
        val label = "label"

        //Act
        inputCodePixAnalytics.trackingResendCode(label)

        //Assert
        verify {
            pixAnalytics.trackAction(
                action = PixAnalytics.Actions.CLICK_REQUEST_TOKEN,
                itemName = PixAnalytics.Screens.Keys.VALID_PHONE,
                label = label,
                subSection1 = PixAnalytics.Sections.PIX,
                subSection2 = PixAnalytics.Sections.MY_KEYS,
                subSection3 = PixAnalytics.Sections.REGISTER_KEYS
            )
        }
    }

    @Test
    fun trackingClickButton() {
        //Arrange
        val buttonName = "test-action"
        val label = "label"

        //Act
        inputCodePixAnalytics.trackingClickButton(buttonName, label)

        //Assert
        verify {
            pixAnalytics.trackAction(
                action = PixAnalytics.Actions.CLICK_IN_ + buttonName,
                itemName = PixAnalytics.Screens.Keys.VALID_PHONE,
                label = label,
                subSection1 = PixAnalytics.Sections.PIX,
                subSection2 = PixAnalytics.Sections.MY_KEYS,
                subSection3 = PixAnalytics.Sections.REGISTER_KEYS
            )
        }
    }

    @Test
    fun trackingOnFinishWriting() {
        //Arrange
        val action = "test-action"
        val label = "label"

        //Act
        inputCodePixAnalytics.trackingClickButton(action, label)

        //Assert
        verify {
            pixAnalytics.trackAction(
                action = PixAnalytics.Actions.CLICK_IN_ + action,
                itemName = PixAnalytics.Screens.Keys.VALID_PHONE,
                label = label,
                subSection1 = PixAnalytics.Sections.PIX,
                subSection2 = PixAnalytics.Sections.MY_KEYS,
                subSection3 = PixAnalytics.Sections.REGISTER_KEYS
            )
        }
    }

}