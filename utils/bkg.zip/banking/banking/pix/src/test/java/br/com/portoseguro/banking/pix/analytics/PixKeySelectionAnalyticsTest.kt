package br.com.portoseguro.banking.pix.analytics

import android.app.Activity
import io.mockk.mockk
import io.mockk.verify
import org.junit.Before
import org.junit.Test

class PixKeySelectionAnalyticsTest {

    private val pixAnalytics = mockk<PixAnalytics>(relaxed = true)
    private lateinit var pixKeySelectionAnalytics: PixKeySelectionAnalytics

    @Before
    fun setUp() {
        pixKeySelectionAnalytics = PixKeySelectionAnalytics(pixAnalytics)
    }

    @Test
    fun trackingClickBackFromActivity() {
        //Act
        pixKeySelectionAnalytics.trackingClickBackFromActivity()

        //Assert
        verify {
            pixAnalytics.trackAction(
                action = PixAnalytics.Actions.CLICK_BACK,
                itemName = PixAnalytics.Screens.Keys.TERM_REGISTER_KEYS,
                subSection1 = PixAnalytics.Sections.PIX,
                subSection2 = PixAnalytics.Sections.MY_KEYS,
                subSection3 = PixAnalytics.Sections.REGISTER_KEYS
            )
        }
    }

    @Test
    fun trackingClickBackFromFragment() {
        //Act
        pixKeySelectionAnalytics.trackingClickBackFromFragment()

        //Assert
        verify {
            pixAnalytics.trackAction(
                action = PixAnalytics.Actions.CLICK_BACK,
                itemName = PixAnalytics.Screens.Keys.CHOOSE_YOUR_KEY,
                subSection1 = PixAnalytics.Sections.PIX,
                subSection2 = PixAnalytics.Sections.MY_KEYS,
                subSection3 = PixAnalytics.Sections.REGISTER_KEYS
            )
        }
    }

    @Test
    fun tracingPixKeySelectionScreen() {
        //Arrange
        val activity = mockk<Activity>()

        //Act
        pixKeySelectionAnalytics.tracingPixKeySelectionScreen(activity)

        //Assert
        verify {
            pixAnalytics.trackScreenView(
                activity = activity,
                screen = PixAnalytics.Screens.Keys.CHOOSE_YOUR_KEY,
                itemName = PixAnalytics.Screens.Keys.CHOOSE_YOUR_KEY,
                subSection1 = PixAnalytics.Sections.PIX,
                subSection2 = PixAnalytics.Sections.MY_KEYS,
                subSection3 = PixAnalytics.Sections.REGISTER_KEYS
            )
        }
    }
}