package br.com.portoseguro.banking.pix.analytics

import android.app.Activity
import io.mockk.mockk
import io.mockk.verify
import org.junit.Before
import org.junit.Test

class PixKeyRegisterCpfAnalyticsTest {

    private val pixAnalytics = mockk<PixAnalytics>(relaxed = true)
    private lateinit var pixKeyRegisterCpfAnalytics: PixKeyRegisterCpfAnalytics

    @Before
    fun setUp() {
        pixKeyRegisterCpfAnalytics = PixKeyRegisterCpfAnalytics(pixAnalytics)
    }

    @Test
    fun trackingPixKeyRegisterScreen() {
        //Arrange
        val activity = mockk<Activity>()

        //Act
        pixKeyRegisterCpfAnalytics.trackingPixKeyRegisterScreen(activity)

        //Assert
        verify {
            pixAnalytics.trackScreenView(
                activity = activity,
                screen = PixAnalytics.Screens.Keys.REGISTER_CPF,
                itemName = PixAnalytics.Screens.Keys.REGISTER_CPF,
                subSection1 = PixAnalytics.Sections.PIX,
                subSection2 = PixAnalytics.Sections.MY_KEYS,
                subSection3 = PixAnalytics.Sections.REGISTER_KEYS
            )
        }
    }

    @Test
    fun trackingClickButton() {
        //Arrange
        val buttonName = "action"

        //Act
        pixKeyRegisterCpfAnalytics.trackingClickButton(buttonName)

        //Assert
        verify {
            pixAnalytics.trackAction(
                action = PixAnalytics.Actions.CLICK_IN_ + buttonName,
                itemName = PixAnalytics.Screens.Keys.REGISTER_CPF,
                subSection1 = PixAnalytics.Sections.PIX,
                subSection2 = PixAnalytics.Sections.MY_KEYS,
                subSection3 = PixAnalytics.Sections.REGISTER_KEYS
            )
        }
    }

    @Test
    fun trackingClickBack() {
        //Act
        pixKeyRegisterCpfAnalytics.trackingClickBack()

        //Assert
        verify {
            pixAnalytics.trackAction(
                action = PixAnalytics.Actions.CLICK_BACK,
                itemName = PixAnalytics.Screens.Keys.REGISTER_CPF,
                subSection1 = PixAnalytics.Sections.PIX,
                subSection2 = PixAnalytics.Sections.MY_KEYS,
                subSection3 = PixAnalytics.Sections.REGISTER_KEYS
            )
        }
    }
}