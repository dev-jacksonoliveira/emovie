package br.com.portoseguro.banking.pix.repository

import br.com.portoseguro.banking.sharedbanking.entity.shortcut.PixShortcuts
import br.com.portoseguro.banking.sharedbanking.repository.BankingShortcutAvailability
import br.com.portoseguro.banking.pix.data.local.shortcut.ProvidePixShortcuts
import br.com.portoseguro.banking.pix.data.repository.shortcut.PixShortcutRepository
import br.com.portoseguro.banking.pix.data.repository.shortcut.PixShortcutRepositoryImpl
import io.mockk.every
import io.mockk.mockk
import org.junit.Assert.assertEquals
import org.junit.Before
import org.junit.Test

class PixShortcutRepositoryImplTest {

    private val pixShortcutsList = ProvidePixShortcuts()
    private val bankingShortcutAvailability =
        mockk<BankingShortcutAvailability<PixShortcuts>>(relaxed = true)
    private lateinit var repository: PixShortcutRepository

    @Before
    fun setup() {
        repository = PixShortcutRepositoryImpl(
            pixShortcutsList,
            bankingShortcutAvailability
        )
    }

    @Test
    fun invokeOperatorFun_shouldReturnSevenElementsInOrderByImpl() {
        //ARRANGE
        val sizeExpected = 7
        every { bankingShortcutAvailability.check(any()) } returns true

        // ACTION
        val result = repository.getShortcuts()

        // ASSERT
        assertEquals(result.size, sizeExpected)
        result.forEachIndexed { index, pixShortcutsType ->
            assert(
                when (pixShortcutsType) {
                    PixShortcuts.Shortcut.Transfer -> index == 0
                    PixShortcuts.Shortcut.Receive -> index == 1
                    PixShortcuts.Shortcut.QrCode -> index == 2
                    PixShortcuts.Shortcut.PixCopyPaste -> index == 3
                    PixShortcuts.OtherServices.MyKeys -> index == 4
                    PixShortcuts.OtherServices.MyLimits -> index == 5
                    PixShortcuts.OtherServices.Help -> index == 6
                    else -> false
                }
            )
        }
    }
}