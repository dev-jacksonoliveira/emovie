package br.com.portoseguro.banking.pix.business

import br.com.portoseguro.banking.pix.data.business.OnboardingBusiness
import br.com.portoseguro.banking.pix.data.business.OnboardingBusinessImpl
import br.com.portoseguro.banking.pix.data.repository.onboarding.OnboardingRepository
import io.mockk.mockk
import io.mockk.verify
import org.junit.Before
import org.junit.Test

private const val METHOD_CALL_TIMES = 1

class OnboardingBusinessTest {

    private val repository = mockk<OnboardingRepository>(relaxed = true)
    private lateinit var business: OnboardingBusiness

    @Before
    fun setup() {
        business = OnboardingBusinessImpl(repository)
    }

    @Test
    fun saveFirstAccess_shouldSaveFirstAccess() {
        business.saveFirstAccess()

        verify(exactly = METHOD_CALL_TIMES) {
            repository.saveFirstAccess()
        }
    }
}