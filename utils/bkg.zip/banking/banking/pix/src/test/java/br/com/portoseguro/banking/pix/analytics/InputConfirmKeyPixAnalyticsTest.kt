package br.com.portoseguro.banking.pix.analytics

import android.app.Activity
import io.mockk.mockk
import io.mockk.verify
import org.junit.Before
import org.junit.Test

class InputConfirmKeyPixAnalyticsTest {

    private val pixAnalytics = mockk<PixAnalytics>(relaxed = true)
    private lateinit var inputConfirmKeyPixAnalytics: InputConfirmKeyPixAnalytics

    @Before
    fun setUp() {
        inputConfirmKeyPixAnalytics = InputConfirmKeyPixAnalytics(pixAnalytics)
    }

    @Test
    fun trackingInputConfirmKeyScreen() {
        //Arrange
        val activity = mockk<Activity>()
        val screen = "scree"
        val itemName = "itemName"

        //Act
        inputConfirmKeyPixAnalytics.trackingInputConfirmKeyScreen(activity, screen, itemName)

        //Assert
        verify {
            pixAnalytics.trackScreenView(
                activity = activity,
                screen = screen,
                itemName = itemName,
                subSection1 = PixAnalytics.Sections.PIX,
                subSection2 = PixAnalytics.Sections.MY_KEYS,
                subSection3 = PixAnalytics.Sections.REGISTER_KEYS
            )
        }
    }

    @Test
    fun trackingClickConfirmation() {
        //Arrange
        val buttonName = "test-action"
        val itemName = "name"

        //Act
        inputConfirmKeyPixAnalytics.trackingClickConfirmation(buttonName, itemName)

        //Assert
        verify {
            pixAnalytics.trackAction(
                action = buttonName,
                itemName = itemName,
                subSection1 = PixAnalytics.Sections.PIX,
                subSection2 = PixAnalytics.Sections.MY_KEYS,
                subSection3 = PixAnalytics.Sections.REGISTER_KEYS
            )
        }
    }

    @Test
    fun trackingClickButton(){
        //Arrange
        val buttonName = "test-action"
        val itemName = "name"

        //Act
        inputConfirmKeyPixAnalytics.trackingClickButton(buttonName, itemName)

        //Assert
        verify {
            pixAnalytics.trackAction(
                action = PixAnalytics.Actions.CLICK_IN_ + buttonName,
                itemName = itemName,
                subSection1 = PixAnalytics.Sections.PIX,
                subSection2 = PixAnalytics.Sections.MY_KEYS,
                subSection3 = PixAnalytics.Sections.REGISTER_KEYS
            )
        }
    }

    @Test
    fun trackingClickBack() {
        //Arrange
        val itemName = "name"

        //Act
        inputConfirmKeyPixAnalytics.trackingClickBack(itemName)

        //Assert
        verify {
            pixAnalytics.trackAction(
                action = PixAnalytics.Actions.CLICK_BACK,
                itemName = itemName,
                subSection1 = PixAnalytics.Sections.PIX,
                subSection2 = PixAnalytics.Sections.MY_KEYS,
                subSection3 = PixAnalytics.Sections.REGISTER_KEYS
            )
        }
    }
}