package br.com.portoseguro.banking.sample

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import br.com.portoseguro.banking.pix.data.enums.PixTransferType
import br.com.portoseguro.banking.pix.presentation.help.HelpActivity
import br.com.portoseguro.banking.pix.presentation.keys.PixKeysListActivity
import br.com.portoseguro.banking.pix.presentation.transfer.pixKey.PixKeyTransferActivity
import br.com.portoseguro.banking.presentation.card.requestnewcard.RequestNewCardActivity
import br.com.portoseguro.banking.sample.databinding.ActivityHomeBinding
import br.com.portoseguro.banking.sharedbanking.presentation.extract.ExtractActivity
import br.com.portoseguro.superapp.core.infrastructure.extensions.onClick

class HomeActivity : AppCompatActivity() {

    private val binding: ActivityHomeBinding by lazy { ActivityHomeBinding.inflate(layoutInflater) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)

        setupListeners()
    }

    private fun setupListeners() {
        binding.pixButton.onClick(::openPixScreen)
        binding.pixListBtn.onClick(::openPixKeysListScreen)
        binding.requestNewCardButton.onClick(::openRequestNewCard)
        binding.extractButton.onClick(::openExtract)
        binding.helpButton.onClick(::openHelp)
    }

    private fun openPixScreen() {
        startActivity(PixKeyTransferActivity.getLaunchIntent(this, PixTransferType.PIX_TRANSFER))
    }

    private fun openPixKeysListScreen() {
        startActivity(PixKeysListActivity.getLaunchIntent(this))
    }

    private fun openRequestNewCard() {
//        startActivity(RequestNewCardActivity.getLaunchIntent(this))
    }

    private fun openExtract() {
        startActivity(ExtractActivity.getLaunchIntent(this))
    }

    private fun openHelp() {
        startActivity(HelpActivity.getLaunchIntent(this))
    }
}
