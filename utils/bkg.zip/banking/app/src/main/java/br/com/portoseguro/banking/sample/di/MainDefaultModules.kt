package br.com.portoseguro.banking.sample.di

import br.com.portoseguro.components.di.componentModules
import br.com.portoseguro.superapp.core.di.coreModules
import br.com.portoseguro.usersecurity.di.userSecurityModules


internal fun loadMainDefaultModules() = listOf(coreModules, componentModules, userSecurityModules)
