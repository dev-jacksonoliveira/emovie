package br.com.portoseguro.banking.sample

import android.app.Application
import br.com.portoseguro.banking.di.loadBankingModules
import br.com.portoseguro.banking.pix.di.loadPixModule
import br.com.portoseguro.banking.sample.di.loadMainApplicationModules
import br.com.portoseguro.banking.sample.di.loadMainDefaultModules
import br.com.portoseguro.banking.sharedbanking.di.loadSharedBankingModules
import br.com.portoseguro.superapp.core.di.PROPERTIES_APP_VERSION
import com.google.firebase.FirebaseApp
import org.koin.android.ext.koin.androidContext
import org.koin.core.context.startKoin

class MainApplication : Application() {

    override fun onCreate() {
        super.onCreate()

        startKoin()
        startFirebase()
        loadModules()
    }

    private fun loadModules() {
        loadPixModule()
        loadSharedBankingModules()
        loadBankingModules()
    }

    private fun startKoin() {
        startKoin {
            androidContext(this@MainApplication)
            modules(loadMainApplicationModules() + loadMainDefaultModules())
            properties(mapOf(PROPERTIES_APP_VERSION to BuildConfig.VERSION_NAME))
        }
    }

    private fun startFirebase() {
        FirebaseApp.initializeApp(this)
    }
}
