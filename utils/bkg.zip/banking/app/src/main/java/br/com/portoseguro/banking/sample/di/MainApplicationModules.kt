package br.com.portoseguro.banking.sample.di

import android.text.format.DateUtils
import br.com.portoseguro.banking.sample.BuildConfig
import br.com.portoseguro.superapp.core.notification.impl.urban.setup.UrbanAirshipSettings
import br.com.portoseguro.superapp.core.repository.BaseWebService
import org.koin.core.module.Module
import org.koin.dsl.module


internal fun loadMainApplicationModules() = listOf(module(override = true) {
    loadBaseWebService()
    loadUrbanModule()
})

private fun Module.loadBaseWebService() {
    single {
        BaseWebService(
            baseUrl = BuildConfig.BASE_URL_API,
            securityAPIKey = BuildConfig.SECURITY_API_KEY,
            connectTimeout = DateUtils.MINUTE_IN_MILLIS,
            readTimeout = DateUtils.MINUTE_IN_MILLIS,
            writeTimeout = DateUtils.MINUTE_IN_MILLIS,
            buildType = BuildConfig.BUILD_TYPE,
            fpServer = BuildConfig.FP_SERVER,
            orgId = BuildConfig.ORG_ID
        )
    }
}

private fun Module.loadUrbanModule() {
    single {
        UrbanAirshipSettings(
            airshipKey = BuildConfig.AIRSHIP_KEY,
            airshipSecret = BuildConfig.AIRSHIP_SECRET
        )
    }
}