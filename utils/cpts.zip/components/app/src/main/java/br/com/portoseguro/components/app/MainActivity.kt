package br.com.portoseguro.components.app

import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import br.com.portoseguro.components.alertdialog.AlertDialog
import br.com.portoseguro.components.alertdialog.AlertDialogData
import br.com.portoseguro.components.app.barcodebutton.BarcodeButtonActivity
import br.com.portoseguro.components.app.buttonlink.ButtonLinkActivity
import br.com.portoseguro.components.app.cardInvoiceBarCodePayment.CardInvoiceBarCodePaymentActivity
import br.com.portoseguro.components.app.cardheader.HeaderCardViewActivity
import br.com.portoseguro.components.app.codefield.CodeFieldActivity
import br.com.portoseguro.components.app.comingsoon.ComingSoonSampleActivity
import br.com.portoseguro.components.app.confirmation.ConfirmationView
import br.com.portoseguro.components.app.datepicker.DatePickerSampleActivity
import br.com.portoseguro.components.app.designsystem.ButtonLoadingOutlinedSampleActivity
import br.com.portoseguro.components.app.designsystem.InvoiceViewSampleActivity
import br.com.portoseguro.components.app.designsystem.LimitViewSampleActivity
import br.com.portoseguro.components.app.designsystem.SliderSampleActivity
import br.com.portoseguro.components.app.detailinvoice.DetailInvoiceActivity
import br.com.portoseguro.components.app.emptyview.EmptyViewActivity
import br.com.portoseguro.components.app.error.ErrorViewActivity
import br.com.portoseguro.components.app.error.ErrorWhiteActivity
import br.com.portoseguro.components.app.error.GenericErrorViewActivity
import br.com.portoseguro.components.app.expandableCard.ExpandableCardViewActivity
import br.com.portoseguro.components.app.genericimagebutton.GenericImageButtonActivity
import br.com.portoseguro.components.app.genericloadingbutton.GenericLoadingButtonActivity
import br.com.portoseguro.components.app.genericwebview.GenericWebViewActivity
import br.com.portoseguro.components.app.invoicesectionview.InvoiceSectionActivity
import br.com.portoseguro.components.app.itemview.ItemViewActivity
import br.com.portoseguro.components.app.labelmessage.LabelMessageActivity
import br.com.portoseguro.components.app.labeltag.LabelTagActivity
import br.com.portoseguro.components.app.lastcharge.LastChargeActivity
import br.com.portoseguro.components.app.loading.LoadingActivity
import br.com.portoseguro.components.app.loading.LoadingActivityFull
import br.com.portoseguro.components.app.newproduct.NewProductSampleActivity
import br.com.portoseguro.components.app.notificationview.NotificationViewActivity
import br.com.portoseguro.components.app.outdatedregistration.OutdatedRegistrationActivity
import br.com.portoseguro.components.app.phones.PhonesActivity
import br.com.portoseguro.components.app.radiobutton.RadioButtonActivity
import br.com.portoseguro.components.app.segmentedprogressbar.SegmentedProgressBarActivity
import br.com.portoseguro.components.app.selectorButton.SelectorButtonActivity
import br.com.portoseguro.components.app.shimmer.ShimmerActivity
import br.com.portoseguro.components.app.shortcut.ShortcutButtonsActivity
import br.com.portoseguro.components.app.shortcut.ShortcutGroupActivity
import br.com.portoseguro.components.app.simpleinvoice.SimpleInvoiceActivity
import br.com.portoseguro.components.app.statepicker.StatePickerActivity
import br.com.portoseguro.components.app.stickheader.StickHeaderExampleActivity
import br.com.portoseguro.components.app.story.StoriesButtonsActivity
import br.com.portoseguro.components.app.tabbar.TabBarActivity
import br.com.portoseguro.components.app.textarea.TextAreaSampleActivity
import br.com.portoseguro.components.app.textfield.TextFieldSampleActivity
import br.com.portoseguro.components.app.theme.ThemeButtonsActivity
import br.com.portoseguro.components.app.virtualcard.UserCardViewActivity
import br.com.portoseguro.components.confirmation.Confirmation
import br.com.portoseguro.components.confirmation.ConfirmationDialog
import br.com.portoseguro.components.dialog.ActionBottomSheetDialog
import br.com.portoseguro.components.error.GenericErrorBottomSheetDialog
import br.com.portoseguro.components.feedbackbottomsheet.FeedbackBottomSheetFragment
import br.com.portoseguro.components.genericwebviewbottomsheet.GenericWebViewBottomSheetDialogFragment
import br.com.portoseguro.components.selector.LoadableSwitch
import br.com.portoseguro.components.snackbar.CustomSnackBar
import br.com.portoseguro.superapp.core.infrastructure.extensions.onClick
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.coroutines.*

class MainActivity : AppCompatActivity() {

    private val newProductButton by lazy { findViewById<Button>(R.id.button_new_product_sample) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    override fun onStart() {
        super.onStart()
        bindEvents()
    }

    private fun bindEvents() {
        buttonLoadingOutlined.setOnClickListener {
            startActivity(ButtonLoadingOutlinedSampleActivity.getIntent(this))
        }

        newProductButton.setOnClickListener {
            startActivity(Intent(this, NewProductSampleActivity::class.java))
        }

        buttonSegmentedProgressBar.setOnClickListener {
            startActivity(Intent(this, SegmentedProgressBarActivity::class.java))
        }

        buttonInvoiceView.setOnClickListener {
            startActivity(Intent(this, InvoiceViewSampleActivity::class.java))
        }

        buttonCodeField.setOnClickListener {
            startActivity(Intent(this, CodeFieldActivity::class.java))
        }

        buttonLink.setOnClickListener {
            startActivity(Intent(this, ButtonLinkActivity::class.java))
        }

        buttonTextField.setOnClickListener {
            TextFieldSampleActivity.start(this)
        }

        buttonDatePicker.setOnClickListener {
            DatePickerSampleActivity.start(this)
        }

        expandableCardViewActivity.setOnClickListener {
            val intent = Intent(
                this@MainActivity, ExpandableCardViewActivity::class.java
            )
            startActivity(intent)
        }

        shortcutButtonsActivity.setOnClickListener {
            val intent = Intent(
                this@MainActivity, ShortcutButtonsActivity::class.java
            )
            startActivity(intent)
        }

        shortcutGroupSample.setOnClickListener {
            val intent = Intent(
                this@MainActivity, ShortcutGroupActivity::class.java
            )
            startActivity(intent)
        }

        storiesButtonsActivity.setOnClickListener {
            val intent = Intent(
                this@MainActivity, StoriesButtonsActivity::class.java
            )
            startActivity(intent)
        }

        buttonLoading.setOnClickListener {
            val intent = Intent(
                this@MainActivity, LoadingActivity::class.java
            )
            startActivity(intent)
        }

        buttonLoadingFull.setOnClickListener {
            val intent = Intent(
                this@MainActivity, LoadingActivityFull::class.java
            )
            startActivity(intent)
        }

        buttonShimmer.setOnClickListener {
            val intent = Intent(
                this@MainActivity, ShimmerActivity::class.java
            )
            startActivity(intent)
        }

        buttonErrorView.setOnClickListener {
            val intent = Intent(
                this@MainActivity, ErrorViewActivity::class.java
            )
            startActivity(intent)
        }
        buttonErrorGeneric.setOnClickListener {
            startGenericErrorViewActivity()
        }
        buttonErrorGenericFirstTry.setOnClickListener {
            startGenericErrorViewActivity(
                title = getString(R.string.generic_error_second_title),
                subtitle = getString(R.string.generic_error_second_subtitle)
            )
        }
        buttonErrorGenericSecondTry.setOnClickListener {
            startGenericErrorViewActivity(
                title = getString(R.string.generic_error_third_title),
                subtitle = getString(R.string.generic_error_second_subtitle),
                buttonText = getString(R.string.back_to_login)
            )
        }

        buttonUserLimitViewSample.onClick {
            startActivity(LimitViewSampleActivity.getLaunchIntent(context = this@MainActivity))
        }

        buttonLastChargeViewSample.onClick {
            startActivity(LastChargeActivity.getLaunchIntent(this@MainActivity))
        }

        buttonHeaderCard.setOnClickListener {
            val intent = Intent(
                this@MainActivity, HeaderCardViewActivity::class.java
            )
            startActivity(intent)
        }

        buttonInvoiceSample.onClick {
            startActivity(SimpleInvoiceActivity.getLaunchIntent(context = this@MainActivity))
        }

        buttonConfirmation.setOnClickListener {
            val intent = Intent(this@MainActivity, ConfirmationView::class.java)
            startActivity(intent)
        }

        buttonConfirmationDialog.setOnClickListener {
            startConfirmationDialog()
        }

        customSnackBarSuccess.onClick {
            CustomSnackBar.showSuccessSnackBar(
                CustomSnackBar.CustomSnackBarData(
                    root_layout,
                    "Cartão desbloqueado!",
                    Gravity.TOP
                )
            )
        }

        customSnackBarError.onClick {
            CustomSnackBar.showErrorSnackBar(
                CustomSnackBar.CustomSnackBarData(
                    root_layout,
                    "Erro na solicitação. Por favor, tente novamente",
                    Gravity.BOTTOM
                )
            )
        }

        customSnackBarNeutral.onClick {
            CustomSnackBar.showNeutralSnackBar(
                CustomSnackBar.CustomSnackBarData(
                    root_layout,
                    "Texto de aviso neutro, com layout claro e texto escuro",
                    Gravity.BOTTOM
                )
            )
        }

        detailInvoiceButton.onClick {
            startActivity(Intent(this, DetailInvoiceActivity::class.java))
        }

        errorWhiteButton.onClick {
            startActivity(ErrorWhiteActivity.getLaunchIntent(this@MainActivity))
        }

        genericLoadingButton.onClick {
            startActivity(GenericLoadingButtonActivity.getLaunchIntent(this@MainActivity))
        }

        genericImageButton.onClick {
            startActivity(GenericImageButtonActivity.getLaunchIntent(this@MainActivity))
        }

        cardInvoiceBarcodePayment.onClick {
            startActivity(CardInvoiceBarCodePaymentActivity.getLaunchIntent(this@MainActivity))
        }

        termsDialog.onClick {
            val terms = GenericWebViewBottomSheetDialogFragment
                .newInstance("https://mock-server-dot-experienciadocliente-dev.appspot.com/static_files/termosDeUso.html")
            terms.show(supportFragmentManager, "terms-dialog")
        }

        barcodeButton.onClick {
            startActivity(BarcodeButtonActivity.getLaunchIntent(this@MainActivity))
        }

        userCardButton.onClick {
            startActivity(UserCardViewActivity.getLaunchIntent(this@MainActivity))
        }

        genericWebViewButton.onClick {
            startActivity(GenericWebViewActivity.getLaunchIntent(this@MainActivity))
        }

        genericErrorDialogButton.setOnClickListener {
            val genericErrorDialog = GenericErrorBottomSheetDialog()
            genericErrorDialog.show(
                supportFragmentManager,
                GenericErrorBottomSheetDialog::class.simpleName
            )
        }

        buttonTheme.setOnClickListener {
            startActivity(Intent(this, ThemeButtonsActivity::class.java))
        }

        dialogActionButton1.setOnClickListener {
            val actionDialog =
                ActionBottomSheetDialog.newInstance(
                    title = "Reenviar Código",
                    description = "O Código de Acesso enviado para o e-mail f*******s@gmail.com expirou",
                    primaryButtonLabel = "Reenviar SMS",
                    primaryButtonListener = ::primaryButtonClick
                ).apply {
                    setupSecondaryButton(
                        buttonLabel = "Reenviar para o e-mail",
                        buttonListener = ::secondaryButtonClick
                    )
                }

            supportFragmentManager.let {
                actionDialog.show(it, ACTION_DIALOG_TAG)
            }
        }


        dialogActionButton2.setOnClickListener {
            val actionDialog =
                ActionBottomSheetDialog.newInstance(
                    title = "Confirme a forma de recebimento do seu código",
                    description = "Você irá receber um e-mail na conta f*********s@gmail.com",
                    primaryButtonLabel = "Receber meu token",
                    primaryButtonListener = ::primaryButtonClick
                )

            supportFragmentManager.let {
                actionDialog.show(it, ACTION_DIALOG_TAG)
            }
        }

        dialogActionButton3.setOnClickListener {
            val actionDialog =
                ActionBottomSheetDialog.newInstance(
                    title = "Use a biometria",
                    description = "Cadastre sua biometria para facilitar os próximos acessos ao Cartão Virtual",
                    primaryButtonLabel = "Cadastrar agora",
                    icon = getString(R.string.icon_finger_print),
                    isExpanded = true,
                    primaryButtonListener = ::primaryButtonClick
                ).apply {
                    setupSecondaryButton(
                        buttonLabel = "Cadastrar mais tarde",
                        buttonListener = ::secondaryButtonClick
                    )
                }

            supportFragmentManager.let {
                actionDialog.show(it, ACTION_DIALOG_TAG)
            }
        }

        stickHeaderButton.setOnClickListener {
            startActivity(Intent(this, StickHeaderExampleActivity::class.java))
        }

        relationshipCenter.setOnClickListener {
            startActivity(OutdatedRegistrationActivity.getLaunchIntent(this@MainActivity))
        }

        emptyView.setOnClickListener {
            startActivity(EmptyViewActivity.getLaunchIntent(this@MainActivity))
        }

        phonesView.setOnClickListener {
            startActivity(PhonesActivity.getLaunchIntent(this))
        }

        tabBar.setOnClickListener {
            startActivity(Intent(this, TabBarActivity::class.java))
        }

        notificationView.setOnClickListener {
            startActivity(Intent(this, NotificationViewActivity::class.java))
        }

        invoiceSectionView.setOnClickListener {
            startActivity(Intent(this, InvoiceSectionActivity::class.java))
        }

        itemView.setOnClickListener {
            startActivity(Intent(this, ItemViewActivity::class.java))
        }

        alertDialog.setOnClickListener {
            val alert = AlertDialog(
                this,
                AlertDialogData(
                    text = "Este canal é exclusivo para atualizar seu cadastro. Deseja continuar?",
                    textBold = "Deseja continuar?",
                    firstButtonText = "Sim, continuar",
                    secondButtonText = "Não, cancelar"
                )
            )
            alert.show()

        }

        statePicker.setOnClickListener {
            startActivity(Intent(this, StatePickerActivity::class.java))
        }

        radioButton.setOnClickListener {
            startActivity(Intent(this, RadioButtonActivity::class.java))
        }

        loadingSelector.addStateChangedListener {
            GlobalScope.launch(Dispatchers.Main) {
                if (it is LoadableSwitch.State.Loading) {
                    delay(2000)
                    loadingSelector.state = if (it.beforeState is LoadableSwitch.State.Checked) {
                        LoadableSwitch.State.NotChecked
                    } else {
                        LoadableSwitch.State.Checked
                    }
                }

            }
        }

        labelMessage.setOnClickListener {
            startActivity(Intent(this, LabelMessageActivity::class.java))
        }

        buttonLabelTag.setOnClickListener {
            startActivity(Intent(this, LabelTagActivity::class.java))
        }

        sliderSample.setOnClickListener {
            startActivity(Intent(this, SliderSampleActivity::class.java))
        }

        comingSoonButton.setOnClickListener {
            startActivity(Intent(this, ComingSoonSampleActivity::class.java))
        }

        buttonTextArea.setOnClickListener {
            TextAreaSampleActivity.start(this)
        }

        feedbackBottomSheet.setOnClickListener {
            val fragment = FeedbackBottomSheetFragment
                .newInstance(R.string.icon_heart,"Título de teste","Descrição de teste" +
                        " Descrição de teste Descrição de teste Descrição de " +
                        "teste Descrição de teste Descrição de teste", "")
            fragment.show(supportFragmentManager, "feedbakc_bottomsheet")
        }
        buttonSelectorButton.setOnClickListener {
            startActivity(Intent(this, SelectorButtonActivity::class.java))
        }
    }

    private fun startConfirmationDialog() {
        val data = Confirmation(
            title = "Regra do Bloqueio Temporário",
            subtitle = getString(R.string.long_description_example),
            iconVisibility = false,
            isExpanded = false,
            animationVisibility = false
        )
        val dialog = ConfirmationDialog.instance(data)
        dialog.setPrimaryButtonOnClick {
            Toast.makeText(this, "Clicou", Toast.LENGTH_SHORT).show()
            dialog.dismiss()
        }
        dialog.setOnCloseAction {
            Toast.makeText(this, "Fechou", Toast.LENGTH_SHORT).show()
        }
        dialog.show(supportFragmentManager, "dialog")
    }

    private fun startGenericErrorViewActivity(
        title: String? = null,
        subtitle: String? = null,
        buttonText: String? = null
    ) {
        val intent = Intent(
            this@MainActivity, GenericErrorViewActivity::class.java
        ).apply {
            putExtra(GenericErrorViewActivity.ERROR_TITLE_VALUE, title)
            putExtra(GenericErrorViewActivity.ERROR_SUBTITLE_VALUE, subtitle)
            putExtra(GenericErrorViewActivity.ERROR_BUTTON_TEXT, buttonText)
        }
        startActivity(intent)
    }

    private fun primaryButtonClick() {
        Toast.makeText(applicationContext, "click on button primary", Toast.LENGTH_SHORT).show()
    }

    private fun secondaryButtonClick() {
        Toast.makeText(applicationContext, "click on button secondary", Toast.LENGTH_SHORT).show()
    }

    companion object {
        private const val ACTION_DIALOG_TAG = "ACTION_DIALOG_TAG"
    }
}