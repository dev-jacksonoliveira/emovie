package br.com.portoseguro.components.app

import android.app.Application
import br.com.portoseguro.components.di.componentModules
import br.com.portoseguro.superapp.core.di.PROPERTIES_APP_VERSION
import br.com.portoseguro.superapp.core.di.coreModules
import br.com.portoseguro.superapp.core.toggle.CoreFeatureToggleKeys
import br.com.portoseguro.superapp.core.toggle.FeatureToggle
import org.koin.android.ext.android.get
import org.koin.android.ext.koin.androidContext
import org.koin.core.context.startKoin

class MainApplication : Application() {

    override fun onCreate() {
        super.onCreate()

        startKoin {
            // declare used Android context
            androidContext(this@MainApplication)
            // declare modules
            modules(
                listOf(
                    coreModules,
                    componentModules
                )
            )
            properties(
                mapOf(
                    PROPERTIES_APP_VERSION to BuildConfig.VERSION_NAME
                )
            )
        }

        val toggles: FeatureToggle = get()
        toggles.addDefaultValues(CoreFeatureToggleKeys.getDefaultValueMap())
    }
}