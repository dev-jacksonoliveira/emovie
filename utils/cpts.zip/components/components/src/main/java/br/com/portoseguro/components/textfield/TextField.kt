package br.com.portoseguro.components.textfield

import android.content.Context
import android.content.res.ColorStateList
import android.text.InputFilter
import android.text.InputType.TYPE_CLASS_NUMBER
import android.text.InputType.TYPE_CLASS_PHONE
import android.text.InputType.TYPE_CLASS_TEXT
import android.text.InputType.TYPE_NULL
import android.text.InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS
import android.text.TextUtils
import android.text.TextWatcher
import android.text.method.DigitsKeyListener
import android.util.AttributeSet
import android.util.TypedValue
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.annotation.ColorRes
import androidx.appcompat.widget.AppCompatTextView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.constraintlayout.widget.ConstraintSet
import androidx.core.content.ContextCompat
import androidx.core.view.isVisible
import androidx.core.widget.TextViewCompat
import br.com.portoseguro.components.R
import br.com.portoseguro.components.removeSpecialCharacters
import br.com.portoseguro.components.shimmer.ShimmerFrameLayout
import br.com.portoseguro.components.toPx
import br.com.portoseguro.components.utils.CepFormatter
import br.com.portoseguro.components.utils.ComplementFormatter
import br.com.portoseguro.components.utils.PhoneNumberFormatter
import br.com.portoseguro.components.utils.AlphanumericTextWatcher
import br.com.portoseguro.components.utils.GenericTextWatcher
import br.com.portoseguro.components.utils.CardDueDateFormatter
import br.com.portoseguro.components.utils.DateFormatter
import br.com.portoseguro.components.utils.CardFormatter
import br.com.portoseguro.components.utils.CpfCnpjFormatter
import br.com.portoseguro.components.utils.MonetaryFormatter
import br.com.portoseguro.superapp.core.infrastructure.extensions.bindView
import br.com.portoseguro.superapp.core.infrastructure.extensions.onClick
import br.com.portoseguro.superapp.core.utils.CPFUtils
import br.com.portoseguro.superapp.core.utils.Utils
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout

/**
 * This class implements a Custom Component TextField
 */
/*
 * TooManyFunctions suppressed, all functions belongs here. Some functions could be props, but would still break
 * detekt threshold
 */
@Suppress("TooManyFunctions")
class TextField @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleRes: Int = 0
) : ConstraintLayout(context, attrs, defStyleRes) {

    val inputLayout: TextInputLayout by bindView(R.id.input_layout)
    val editText: TextInputEditText by bindView(R.id.edit_text)
    private val indicatorView: View by bindView(R.id.indicator_view)
    private val messageTextView: AppCompatTextView by bindView(R.id.text_message)
    private val icon: TextView by bindView(R.id.icon)
    private val viewEditTextShimmer: View by bindView(R.id.view_edit_text_shimmer)
    private val editTextShimmer: ShimmerFrameLayout by bindView(R.id.shimmer_edit_text)
    private val contentInput: ConstraintLayout by bindView(R.id.content_input)

    private var fieldState: State = State.ActiveNoTextEntry
    private var fieldFocusState: State = State.Focus
    private var fieldType: Type = Type.Text
    private var fieldIcon: String = EMPTY_STRING
    private var descriptionMessage: String = EMPTY_STRING
    private var errorMessage: String = EMPTY_STRING
    private var onAfterTextChanged: ((String) -> Unit)? = null

    var onFocusAction: (() -> Unit)? = null
    var onLostFocusAction: (() -> Unit)? = null

    private var textWatcher: TextWatcher? = null

    init {
        LinearLayout.inflate(context, R.layout.view_text_field, this)
        fillAttributes(attrs)
        setupListeners()
    }

    private fun setupListeners() {
        editText.setOnFocusChangeListener { _, hasFocus ->
            if (hasFocus) {
                configureEditText(fieldFocusState)
                onFocusAction?.invoke()
            } else {
                onLostFocusAction?.invoke()
                configureEditText(fieldState)
            }
        }

        inputLayout.onClick {
            editText.requestFocus()
            Utils().showSoftInputKeyboard(context, editText)
        }
    }

    private fun fillAttributes(attrs: AttributeSet? = null) {
        if (attrs == null) {
            return
        }
        val attributes = context.obtainStyledAttributes(attrs, R.styleable.TextField)
        attributes.getString(R.styleable.TextField_tf_hint)?.let {
            inputLayout.hint = it
        }
        attributes.recycle()
    }

    private fun setIndicatorState(state: IndicatorState) {
        indicatorView.setBackgroundColor(ContextCompat.getColor(context, state.strokeColor))
        val layoutParams = indicatorView.layoutParams
        layoutParams.width = ViewGroup.LayoutParams.MATCH_PARENT
        layoutParams.height = state.strokeSize.toPx()
    }

    /**
     * Get EditText
     */
    fun getEditText(): EditText = editText

    /**
     * Set TextWatcher to edittext field
     */
    fun setTextWatcher(watcher: TextWatcher) {
        editText.addTextChangedListener(watcher)
    }

    /**
     * Clear the description Message on the bottom of field
     */
    fun clearDescriptionMessage() {
        messageTextView.isVisible = false
        messageTextView.text = EMPTY_STRING
        descriptionMessage = EMPTY_STRING
    }

    /**
     * Request the component focus and show keyboard.
     */
    fun requestComponentFocus() {
        editText.requestFocus()
        Utils().showSoftInputKeyboard(context, editText)
    }

    /**
     * Clear the error Message on the bottom of field
     */
    fun clearErrorMessage() {
        messageTextView.isVisible = false
        messageTextView.text = EMPTY_STRING
        errorMessage = EMPTY_STRING
    }

    /**
     * Set description Message on the bottom of field
     *
     * @param message String with the expected text
     */
    fun setDescriptionMessage(message: String) {
        messageTextView.isVisible = true
        messageTextView.text = message
        descriptionMessage = message
    }

    fun setDescriptionLines(lines: Int) {
        messageTextView.setLines(lines)
    }

    /**
     * Set error Message on the bottom of field
     *
     * @param message String with the expected text
     */
    fun setErrorMessage(message: String) {
        messageTextView.isVisible = true
        messageTextView.text = message
        errorMessage = message
    }

    /**
     * Set icon on the right of field
     *
     * @param iconRes Int with the expected icon id resource
     */
    fun setIcon(iconRes: Int) {
        val iconText = resources.getString(iconRes)
        icon.text = iconText
        fieldIcon = iconText
        configureIcon(fieldState)
    }

    /**
     * Set state on field to apply the expected layout state
     *
     * @param state State with the expected State
     */
    fun setState(state: State, stateFocus: State? = null) {
        fieldState = state
        stateFocus?.let {
            fieldFocusState = it
        }
        configureEditText(state)
    }

    /**
     * Set hint on field input layout
     *
     * @param text String with the expected text
     */
    fun setHintText(text: String) {
        inputLayout.hint = text
    }

    /**
     * Set text on field edit text
     *
     * @param text String with the expected text
     */
    fun setText(text: String) {
        editText.setText(text)
    }

    /**
     * Remove text of edit text
     */
    fun clearText() {
        editText.setText("")
    }

    /**
     * Set the type of input
     *
     * @param type expected Type
     */
    fun setInputType(type: Type) {
        editText.inputType = type.value
        fieldType = type
        configureInputType(type)
    }

    /**
     * Set the width of shimmer view
     *
     * @param width expected Int
     */
    fun setEditTextShimmerWidth(width: Int) {
        val layoutParams = viewEditTextShimmer.layoutParams
        layoutParams.width = width.toPx()
    }

    /**
     * start the animation of shimmer
     */
    fun startLoadingEditText() {
        editText.isEnabled = false
        editText.visibility = View.INVISIBLE
        editTextShimmer.visibility = View.VISIBLE
        val hintText = inputLayout.hint
        val contentDescription = context.getString(R.string.loading)
        contentInput.contentDescription = "$hintText $contentDescription"
        contentInput.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_YES
        editTextShimmer.startShimmerAnimation()
    }

    /**
     * stop the animation of shimmer
     */
    fun stopLoadingEditText() {
        editTextShimmer.stopShimmerAnimation()
        contentInput.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
        editTextShimmer.visibility = View.GONE
        editText.isEnabled = true
        editText.visibility = View.VISIBLE
    }

    /**
     * enable or disable edit text
     *
     * @param isEnabled Boolean, true enable, false disable
     */
    fun setIsEnabled(isEnabled: Boolean) {
        editText.isEnabled = isEnabled
        setCorrectState()
    }

    /**
     * Set the correct state by field isEnabled property
     */
    fun setCorrectState() {
        if (editText.isEnabled) {
            setState(getActiveState())
        } else {
            setState(getInactiveState())
        }
    }

    private fun getInactiveState(): State {
        return if (isTextEmpty()) {
            State.InactiveNoTextEntry
        } else {
            State.InactiveTextEntry
        }
    }

    private fun getActiveState(): State {
        return if (isTextEmpty()) {
            State.ActiveNoTextEntry
        } else {
            State.ActiveTextEntry
        }
    }

    /**
     * get text of edit text
     */
    fun getText() = editText.text.toString()

    /**
     * get text of edit text without mask
     */
    fun getTextWithoutMask(): String =
        editText.text.toString()
            .replace(Regex(MASKS_PATTERN), EMPTY_STRING)
            .replace(SPACE, EMPTY_STRING)

    /**
     * get current State
     */
    fun getState() = fieldState

    /**
     * get current Type
     */
    fun getInputType() = editText.inputType

    /**
     * get hint text of edit text
     */
    fun getHintText() = inputLayout.hint.toString()

    /**
     * set the expected text color for hint
     * @param colorRes the resource id of color
     */
    fun setHintTextColor(colorRes: Int) {
        inputLayout.defaultHintTextColor = ColorStateList.valueOf(
            ContextCompat.getColor(context, colorRes)
        )
    }

    /**
     * set the expected text appearance hint
     *
     * @param styleRes expected style resource id
     */
    fun setHintTextAppearance(styleRes: Int) {
        inputLayout.setHintTextAppearance(styleRes)
    }

    /**
     * set the expected color box background of input layout
     * @param colorRes the resource id of color
     */
    fun setBackgroundBoxColor(colorRes: Int) {
        inputLayout.boxBackgroundColor = ContextCompat.getColor(context, colorRes)
    }

    /**
     * set the expected corner radius box background of input layout
     * @param topStart expected Float for radius top start
     * @param topEnd expected Float for radius top end
     * @param bottomStart expected Float for radius bottom start
     * @param bottomEnd expected Float for radius bottom end
     */
    fun setCornerRadius(topStart: Float, topEnd: Float, bottomStart: Float, bottomEnd: Float) {
        inputLayout.setBoxCornerRadii(topStart, topEnd, bottomStart, bottomEnd)
    }

    /**
     * set the expected max text length of edit text
     * @param length expected Int for text length
     */
    fun setMaxTextLength(length: Int) {
        editText.filters = arrayOf(InputFilter.LengthFilter(length))
    }

    /**
     * remove all the special characters of text in TextField
     */
    fun removeSpecialCharacters() {
        editText.setText(editText.text?.removeSpecialCharacters())
    }

    /**
     * verify if text is empty
     *
     * @return Boolean
     */
    fun isTextEmpty(): Boolean = TextUtils.isEmpty(editText.text.toString())

    /**
     * verify if actual state is Error
     *
     * @return Boolean
     */
    fun isStateError(): Boolean = getState() == State.Error

    /**
     * Customize edit text accessibility
     *
     * @param title to announced for talkback
     */
    fun setupEditTextAccessibility(title: String) {
        editText.contentDescription = title
    }

    fun setOnAfterTextChanged(onAfterTextChanged: ((String) -> Unit)? = null) {
        this.onAfterTextChanged = onAfterTextChanged
    }

    fun saveEnable(save: Boolean) {
        editText.isSaveEnabled = save
        inputLayout.isSaveEnabled = save
    }

    private fun removeTextWatcher() {
        if (textWatcher != null) editText.removeTextChangedListener(textWatcher)
    }

    private fun configureInputType(type: Type) {
        removeTextWatcher()
        when (type) {
            Type.Phone -> textWatcher = PhoneNumberFormatter(this.onAfterTextChanged)
            Type.CEP -> {
                editText.keyListener = DigitsKeyListener.getInstance(CEP_ACCEPTED_KEYS)
                textWatcher = CepFormatter(this.onAfterTextChanged)
                editText.filters = arrayOf(InputFilter.LengthFilter(CEP_MAX_LENGTH))
            }

            Type.COMPLEMENT -> {
                textWatcher = ComplementFormatter(this.onAfterTextChanged)
            }

            Type.CPF -> {
                textWatcher = CPFUtils.cpfMask(CPFUtils.FORMAT_CPF, editText) {
                    this.onAfterTextChanged?.invoke(it)
                }
            }

            Type.Date -> {
                editText.keyListener = DigitsKeyListener.getInstance(DATE_ACCEPTED_KEYS)
                textWatcher = DateFormatter(this.onAfterTextChanged)
                editText.filters = arrayOf(InputFilter.LengthFilter(DATE_MAX_LENGTH))
            }

            Type.Card -> {
                editText.keyListener = DigitsKeyListener.getInstance(CARD_ACCEPTED_KEYS)
                textWatcher = CardFormatter(editText, this.onAfterTextChanged)
                editText.filters = arrayOf(InputFilter.LengthFilter(CARD_MAX_LENGTH))
            }

            Type.CardDueDate -> {
                editText.keyListener = DigitsKeyListener.getInstance(DATE_ACCEPTED_KEYS)
                textWatcher = CardDueDateFormatter(this.onAfterTextChanged)
                editText.filters = arrayOf(InputFilter.LengthFilter(CARD_DUE_DATE_MAX_LENGTH))
            }

            Type.Alphanumeric -> {
                textWatcher = AlphanumericTextWatcher(editText, this.onAfterTextChanged)
            }

            Type.CpfCpnj -> {
                textWatcher = CpfCnpjFormatter(this.editText)
                editText.filters = arrayOf(InputFilter.LengthFilter(CNPJ_MAX_LENGTH))
            }

            Type.Monetary -> {
                textWatcher = MonetaryFormatter(this.editText)
            }

            Type.Text, Type.Number, Type.Email -> {
                textWatcher = GenericTextWatcher(this.onAfterTextChanged)
            }

            else -> return
        }
        if (textWatcher != null) editText.addTextChangedListener(textWatcher)
    }

    private fun configureEditText(state: State) {
        setBackgroundBoxColor(state.backgroundColor)
        configureHint(state)
        setIndicatorState(state.indicatorState)
        adjustMessageTextView(state)
        configureIcon(state)
        adjustEditTextPadding()
    }

    private fun configureHint(state: State) {
        when {
            state is State.Error -> {
                setHintTextAppearance(R.style.TextFieldHintDisabled)
                setHintTextColor(R.color.brand_support_01)
            }

            isTextEmpty() && state != State.Focus -> {
                setHintTextAppearance(R.style.TextFieldHintDisabled)
                setHintTextColor(R.color.neutral_color_grey_06)
            }

            else -> {
                setHintTextAppearance(R.style.TextFieldHintEnabled)
                setHintTextColor(state.labelTextColor)
            }
        }
    }

    private fun adjustIconPosition(state: State) {
        if (isTextEmpty() && state != State.Focus) {
            adjustIconToHintText()
        } else {
            adjustIconToText()
        }
    }

    private fun adjustIconToText() {
        val constraintSet = ConstraintSet()
        constraintSet.clone(contentInput)
        constraintSet.clear(icon.id, ConstraintSet.TOP)
        constraintSet.clear(icon.id, ConstraintSet.BOTTOM)
        constraintSet.connect(
            icon.id,
            ConstraintSet.BOTTOM,
            inputLayout.id,
            ConstraintSet.BOTTOM,
            ICON_MARGIN_BOTTOM.toPx()
        )
        constraintSet.applyTo(contentInput)
    }

    private fun adjustIconToHintText() {
        val constraintSet = ConstraintSet()
        constraintSet.clone(contentInput)
        constraintSet.clear(icon.id, ConstraintSet.TOP)
        constraintSet.clear(icon.id, ConstraintSet.BOTTOM)
        constraintSet.connect(
            icon.id,
            ConstraintSet.TOP,
            inputLayout.id,
            ConstraintSet.TOP,
            ICON_MARGIN_TOP.toPx()
        )
        constraintSet.connect(icon.id, ConstraintSet.BOTTOM, inputLayout.id, ConstraintSet.BOTTOM)
        constraintSet.applyTo(contentInput)
    }

    private fun adjustEditTextPadding() {
        var paddingEnd = EDIT_TEXT_PADDING.toPx()

        if (hasIcon()) {
            paddingEnd = (ICON_SIZE + EDIT_TEXT_PADDING).toPx()
        }

        val padding = EDIT_TEXT_PADDING.toPx()
        editText.setPadding(padding, editText.paddingTop, paddingEnd, padding)
    }

    private fun hasIcon(): Boolean =
        icon.text != EMPTY_STRING && icon.text != null && icon.isVisible

    private fun configureIcon(state: State) {
        when {
            state == State.Error -> {
                icon.text = resources.getString(R.string.icon_information)
                adjustIconColorAndPosition(R.color.brand_support_01, state)
            }

            fieldType == Type.State -> {
                icon.text = resources.getString(R.string.icon_arrow_down)
                adjustIconColorAndPosition(R.color.neutral_color_grey_02, state)
            }

            fieldIcon != EMPTY_STRING -> {
                icon.text = fieldIcon
                adjustIconColorAndPosition(R.color.neutral_color_darkest, state)
            }

            else -> {
                icon.visibility = View.GONE
            }
        }
    }

    private fun adjustIconColorAndPosition(colorRes: Int, state: State) {
        icon.setTextColor(ContextCompat.getColor(context, colorRes))
        icon.visibility = View.VISIBLE
        adjustIconPosition(state)
    }

    private fun adjustMessageTextView(state: State) {
        if (state == State.Error) {
            messageTextView.setTextAppearance(R.style.text_field_error)
            messageTextView.text = errorMessage
        } else {
            adjustMessageDescription()
        }

        TextViewCompat.setAutoSizeTextTypeUniformWithConfiguration(
            messageTextView,
            MESSAGE_MIN_TEXT_SIZE,
            MESSAGE_MAX_TEXT_SIZE,
            STEP_GRANULARITY,
            TypedValue.COMPLEX_UNIT_SP
        )
    }

    private fun adjustMessageDescription() {
        if (descriptionMessage == EMPTY_STRING) {
            messageTextView.visibility = View.GONE
        } else {
            messageTextView.setTextAppearance(R.style.text_field_message)
            messageTextView.text = descriptionMessage
        }
    }

    /**
     * Disable keyboard input for text field. This should be used in cases where the text field
     * updates its value using other means (a picker, for example).
     */
    fun disableKeyboardInput() {
        editText.inputType = TYPE_NULL
    }

    fun setTextColor(color: Int) {
        editText.setTextColor(color)
    }

    fun setMessageMaxLines(maxLines: Int) {
        messageTextView.maxLines = maxLines
    }

    companion object {
        private const val WIDTH_SM = 1
        private const val WIDTH_M = 2
        private const val ICON_MARGIN_BOTTOM = 3
        private const val ICON_MARGIN_TOP = 10
        private const val ICON_SIZE = 14
        private const val EDIT_TEXT_PADDING = 6
        private const val EMPTY_STRING = ""
        private const val SPACE = " "
        private const val CEP_MAX_LENGTH = 10
        private const val DATE_MAX_LENGTH = 10
        private const val CARD_DUE_DATE_MAX_LENGTH = 5
        private const val CARD_MAX_LENGTH = 19
        private const val CEP_ACCEPTED_KEYS = "0123456789-"
        private const val DATE_ACCEPTED_KEYS = "0123456789/"
        private const val CARD_ACCEPTED_KEYS = "0123456789 "
        private const val MASKS_PATTERN = """[().-]"""
        private const val MESSAGE_MIN_TEXT_SIZE = 12
        private const val MESSAGE_MAX_TEXT_SIZE = 14
        private const val STEP_GRANULARITY = 1
        private const val CNPJ_MAX_LENGTH = 18

        sealed class IndicatorState(@ColorRes val strokeColor: Int, val strokeSize: Int) {
            object Default : IndicatorState(R.color.neutral_color_grey_03, WIDTH_SM)
            object Focus : IndicatorState(R.color.brand_color_primary, WIDTH_M)
            object Error : IndicatorState(R.color.brand_support_01, WIDTH_M)
        }

        sealed class State(
            @ColorRes val backgroundColor: Int,
            @ColorRes val labelTextColor: Int,
            val indicatorState: IndicatorState = IndicatorState.Default
        ) {

            object ActiveTextEntry : State(
                R.color.brand_support_05,
                R.color.neutral_color_grey_02
            )

            object ActiveNoTextEntry : State(
                R.color.brand_support_05,
                R.color.neutral_color_grey_06
            )

            object InactiveTextEntry : State(
                R.color.neutral_color_grey_03,
                R.color.neutral_color_grey_02
            )

            object InactiveNoTextEntry : State(
                R.color.neutral_color_grey_05,
                R.color.neutral_color_grey_06
            )

            object Error : State(
                R.color.brand_support_05,
                R.color.brand_support_01,
                IndicatorState.Error
            )

            object Focus : State(
                R.color.brand_support_04,
                R.color.brand_color_primary,
                IndicatorState.Focus
            )
        }

        sealed class Type(val value: Int) {
            object Text : Type(TYPE_CLASS_TEXT)
            object State : Type(TYPE_CLASS_TEXT)
            object Phone : Type(TYPE_CLASS_PHONE)
            object Email : Type(TYPE_TEXT_VARIATION_EMAIL_ADDRESS)
            object Number : Type(TYPE_CLASS_NUMBER)
            object CEP : Type(TYPE_CLASS_NUMBER)
            object COMPLEMENT : Type(TYPE_CLASS_TEXT)
            object CPF : Type(TYPE_CLASS_NUMBER)
            object Date : Type(TYPE_CLASS_NUMBER)
            object Card : Type(TYPE_CLASS_NUMBER)
            object CardDueDate : Type(TYPE_CLASS_NUMBER)
            object Alphanumeric : Type(TYPE_CLASS_TEXT)
            object CpfCpnj : Type(TYPE_CLASS_NUMBER)
            object Monetary : Type(TYPE_CLASS_NUMBER)
        }
    }
}