package br.com.portoseguro.components.tutorial

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.view.isVisible
import androidx.fragment.app.DialogFragment
import androidx.viewpager2.widget.ViewPager2
import br.com.portoseguro.components.R
import br.com.portoseguro.components.databinding.FragmentTutorialLayoutBinding
import br.com.portoseguro.components.tutorial.adapter.TutorialAdapter
import br.com.portoseguro.components.tutorial.data.StepType
import br.com.portoseguro.components.tutorial.data.Tutorial
import br.com.portoseguro.superapp.core.infrastructure.extensions.bindBundle
import br.com.portoseguro.superapp.core.infrastructure.extensions.onClick
import com.google.android.material.tabs.TabLayoutMediator
import org.koin.androidx.viewmodel.ext.android.viewModel

/**
 * Tutorial screen.
 *
 * Will open a walk through with the steps defined previously.
 */
class TutorialDialogFragment : DialogFragment() {

    private val tutorialParams: Tutorial by bindBundle(TUTORIAL_PARAMS)
    private val viewModel: TutorialViewModel by viewModel()

    private var _binding: FragmentTutorialLayoutBinding? = null
    private val binding: FragmentTutorialLayoutBinding get() = _binding!!
    private var onFinishListener: ((Boolean) -> Unit)? = null

    //#region ----- Lifecycle overrides

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentTutorialLayoutBinding.inflate(layoutInflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        fillScreenItems()
        setupButtonCloseClick()
        setupButtonClick()
        setupIndicator()
        setupViewPager()
    }

    override fun onDestroy() {
        super.onDestroy()
        _binding = null
    }

    //#endregion

    override fun getTheme(): Int = R.style.BottomSheetDialogRoundedWithVerticalAnimationTheme

    private fun fillScreenItems() = with(binding) {
        // configure pages/adapter
        val adapter = TutorialAdapter(tutorialParams.tutorialScreenList)
        viewPager.adapter = adapter

        // set the visibility of the close button
        closeIconButton.isVisible = tutorialParams.isCloseButtonVisible
    }

    private fun setupButtonCloseClick() {
        binding.closeIconButton.onClick {
            val pos = binding.viewPager.currentItem.plus(1)
            val step: String = getStep(pos)
            viewModel.trackClickAction(tutorialParams.screen, step, CLOSE)
            finish(false)
        }
    }

    private fun setupButtonClick() {
        binding.activityTutorialButton.clickAction = {
            when (tutorialParams.stepType) {
                StepType.STEPADVANCE -> doStepAdvanceOnClick()
                StepType.STEPCLOSE -> doStepCloseOnClick()
            }
        }
    }

    private fun doStepAdvanceOnClick() {
        var position = binding.viewPager.currentItem
        trackAction(position)

        if (position + 1 < tutorialParams.tutorialScreenList.size) {
            position++
            binding.viewPager.currentItem = position
        } else {
            finish(true)
        }
    }

    private fun doStepCloseOnClick() {
        trackAction(binding.viewPager.currentItem)
        finish(true)
    }

    private fun finish(isFromConclusion: Boolean) {
        onFinishListener?.invoke(isFromConclusion)
        dismiss()
    }

    private fun setupIndicator() {
        TabLayoutMediator(binding.tutorialTabLayout, binding.viewPager) { tab, position ->
            val pageNumber = position + 1
            tab.contentDescription = resources.getString(
                R.string.tutorial_pagination_content_description,
                pageNumber.toString(),
                tutorialParams.tutorialScreenList.size.toString()
            )
        }.attach()
    }

    private fun setupViewPager() {
        binding.viewPager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                super.onPageSelected(position)
                // track the new selected page view
                trackPageView(position)
                setupButtonByPosition(position)
            }
        })
    }

    private fun setupButtonByPosition(position: Int) = with(binding.activityTutorialButton) {
        when {
            tutorialParams.stepType == StepType.STEPCLOSE -> setText(tutorialParams.stepCloseButtonText)
            position + 1 < tutorialParams.tutorialScreenList.size -> {
                // is StepType.STEPADVANCE and we are not at the last page
                setText(getString(R.string.tutorial_activity_step_advance_button))
                setTextColor(R.color.brand_color_primary)
                setBackgroundButton(R.drawable.generic_loading_button_white_background)
            }
            else -> {
                // is StepType.STEPADVANCE and we are in the last page
                setText(getString(R.string.tutorial_activity_step_start_button))
                setTextColor(R.color.neutral_color_white)
                setBackgroundButton(R.drawable.primary_button_background)
            }
        }
    }

    private fun trackAction(position: Int) {
        val step: String = getStep(position + 1)
        viewModel.trackClickAction(tutorialParams.screen, step, binding.activityTutorialButton.getButtonText().toString())
    }

    private fun trackPageView(position: Int) {
        val step: String = getStep(position + 1)
        tutorialParams.screen.step = step
        viewModel.trackPageView(requireActivity(), tutorialParams.screen)
    }

    private fun getStep(pos: Int): String {
        val isLastPosition = pos >= binding.viewPager.adapter?.itemCount ?: 0
        return if (isLastPosition) {
            CONCLUSION
        } else {
            pos.toString()
        }
    }

    companion object {
        private const val TUTORIAL_PARAMS = "TUTORIAL_PARAMS"
        private const val CONCLUSION = "conclusao"
        private const val CLOSE = "fechar"

        const val TUTORIAL_TAG = "TUTORIAL_TAG"

        /**
         * returns a new [TutorialDialogFragment] instance.
         *
         * @param onFinishListener Notifies when the tutorial is finished, true means that the tutorial was completed.
         */
        fun getInstance(params: Tutorial, onFinishListener: ((Boolean) -> Unit)? = null) = TutorialDialogFragment().apply {
            this.onFinishListener = onFinishListener
            arguments = Bundle().apply {
                putParcelable(TUTORIAL_PARAMS, params)
            }
        }
    }
}