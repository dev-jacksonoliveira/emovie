package br.com.portoseguro.components

import android.webkit.WebView

/**
 * Open a file from Google Docs
 * @param docUrl the url for the file that will be open
 */
fun WebView.loadDocUrl(docUrl: String) {
    val baseURL = "https://docs.google.com/gview?embedded=true&url="
    val url = baseURL + docUrl
    return loadUrl(url)
}