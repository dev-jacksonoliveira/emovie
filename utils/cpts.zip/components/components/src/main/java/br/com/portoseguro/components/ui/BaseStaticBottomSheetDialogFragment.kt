package br.com.portoseguro.components.ui

import android.content.DialogInterface
import android.util.DisplayMetrics
import android.view.View
import android.widget.FrameLayout
import androidx.coordinatorlayout.widget.CoordinatorLayout
import com.google.android.material.R
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment

abstract class BaseStaticBottomSheetDialogFragment : BottomSheetDialogFragment() {

    protected fun removeDrag(it: DialogInterface?) {
        val bottomSheet = (it as BottomSheetDialog).findViewById<View>(
            R.id.design_bottom_sheet
        ) as FrameLayout?
        bottomSheet?.let {
            val behavior = BottomSheetBehavior.from(bottomSheet)
            behavior.state = BottomSheetBehavior.STATE_EXPANDED
            behavior.addBottomSheetCallback(object : BottomSheetBehavior.BottomSheetCallback() {
                override fun onStateChanged(bottomSheet: View, newState: Int) {
                    if (newState == BottomSheetBehavior.STATE_DRAGGING) {
                        behavior.state = BottomSheetBehavior.STATE_EXPANDED
                    }
                }

                override fun onSlide(bottomSheet: View, slideOffset: Float) {
                    // do nothing
                }
            })
        }
    }

    protected fun setupFullHeight(
        bottomSheetDialog: BottomSheetDialog,
        resizeWithKeyboard: Boolean = false
    ) {
        val bottomSheet = bottomSheetDialog.findViewById<View>(
            R.id.design_bottom_sheet
        ) as FrameLayout?
        if (resizeWithKeyboard) {
            val coordinatorLayout = bottomSheetDialog.findViewById<View>(
                R.id.coordinator
            ) as CoordinatorLayout?
            val topMargin = getTopMargin()

            coordinatorLayout?.addOnLayoutChangeListener(
                object : View.OnLayoutChangeListener {
                    override fun onLayoutChange(
                        v: View?,
                        left: Int,
                        top: Int,
                        right: Int,
                        bottom: Int,
                        oldLeft: Int,
                        oldTop: Int,
                        oldRight: Int,
                        oldBottom: Int
                    ) {
                        if (bottom != oldBottom) {
                            setBottomSheetHeight(bottomSheet, bottom - topMargin)
                        }
                    }
                }
            )
        }

        val windowHeight = getWindowHeight()
        setBottomSheetHeight(bottomSheet, windowHeight)
        bottomSheet?.let {
            BottomSheetBehavior.from(bottomSheet).state = BottomSheetBehavior.STATE_EXPANDED
        }
    }

    private fun setBottomSheetHeight(bottomSheet: FrameLayout?, height: Int) {
        bottomSheet?.let {
            val layoutParams = bottomSheet.layoutParams as? CoordinatorLayout.LayoutParams
            context?.let {
                layoutParams?.let { params ->
                    params.height = height

                }
            }
            bottomSheet.layoutParams = layoutParams
        }
    }

    private fun getWindowHeight(): Int {
        val displayMetrics = DisplayMetrics()
        activity?.windowManager?.defaultDisplay?.getMetrics(displayMetrics)
        val topMargin = (displayMetrics.heightPixels * OUTSIDE_SIZE_PERCENTAGE).toInt()
        return displayMetrics.heightPixels - topMargin
    }

    private fun getTopMargin(): Int {
        val displayMetrics = DisplayMetrics()
        activity?.windowManager?.defaultDisplay?.getMetrics(displayMetrics)
        return (displayMetrics.heightPixels * OUTSIDE_SIZE_PERCENTAGE).toInt()
    }

    override fun onStart() {
        super.onStart()
        stopOutsideClick()
    }

    private fun stopOutsideClick() {
        val touchOutsideView = dialog?.window?.decorView?.findViewById<View>(R.id.touch_outside)
        touchOutsideView?.setOnClickListener(null)
    }

    companion object {
        const val OUTSIDE_SIZE_PERCENTAGE = 0.06
    }
}