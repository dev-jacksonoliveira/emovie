package br.com.portoseguro.components.unavailabilityview

import android.content.Context
import android.util.AttributeSet
import android.widget.LinearLayout
import android.widget.TextView
import androidx.annotation.StringRes
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.view.isVisible
import br.com.portoseguro.components.R
import br.com.portoseguro.superapp.core.infrastructure.extensions.bindView

class UnavailabilityView@JvmOverloads constructor(
        context: Context,
        attrs: AttributeSet? = null,
        defStyleRes: Int = 0
) : ConstraintLayout(context, attrs, defStyleRes) {

    private val titleTextView: TextView by bindView(R.id.text_view_title)
    private val descriptionTextView: TextView by bindView(R.id.text_view_description)

    init {
        LinearLayout.inflate(context, R.layout.unavailability_view, this)
        fillAttributes(attrs)
    }

    private fun fillAttributes(attrs: AttributeSet? = null) {
        if (attrs == null) {
            return
        }
        val attributes = context.obtainStyledAttributes(attrs, R.styleable.UnavailabilityView)

        attributes.getString(R.styleable.UnavailabilityView_unavailabilityView_title)?.let {
            titleTextView.text = it
        }
        attributes.getString(R.styleable.UnavailabilityView_unavailabilityView_description).let {
            descriptionTextView.text = it
            descriptionTextView.isVisible = !it.isNullOrEmpty()
        }
        attributes.getString(R.styleable.UnavailabilityView_unavailabilityView_title_accessibility)?.let {
            titleTextView.contentDescription = it
        }
        attributes.getString(R.styleable.UnavailabilityView_unavailabilityView_description_accessibility)?.let {
            descriptionTextView.contentDescription = it
        }
        attributes.recycle()
    }

    fun setup(
        title: String,
        description: String? = null,
        titleAccessibility: String? = null,
        descriptionAccessibility: String? = null
    ) {
        titleTextView.text = title
        descriptionTextView.text = description
        descriptionTextView.isVisible = !description.isNullOrEmpty()

        titleAccessibility?.let {
            titleTextView.contentDescription = it
        }
        descriptionAccessibility?.let {
            descriptionTextView.contentDescription = it
        }
    }

    fun setup(
        @StringRes title: Int,
        @StringRes description: Int? = null,
        @StringRes titleAccessibility: Int? = null,
        @StringRes descriptionAccessibility: Int? = null
    ) {
        setup(
                context.getString(title),
                description?.let { context.getString(it) },
                titleAccessibility?.let { context.getString(it) },
                descriptionAccessibility?.let { context.getString(it) }
        )
    }
}