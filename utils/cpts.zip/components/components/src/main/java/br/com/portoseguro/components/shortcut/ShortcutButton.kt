package br.com.portoseguro.components.shortcut

import android.content.Context
import android.content.res.TypedArray
import android.util.AttributeSet
import android.view.LayoutInflater
import android.view.accessibility.AccessibilityEvent
import androidx.core.content.ContextCompat
import androidx.core.view.isVisible
import br.com.portoseguro.components.R
import br.com.portoseguro.components.databinding.ShortcutButtonBinding
import br.com.portoseguro.components.setNodeInfoButton
import br.com.portoseguro.components.utils.ComponentsUtils.setFontIcon

class ShortcutButton @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleRes: Int = 0
) : BaseShortcutButton(context, attrs, defStyleRes) {

    private val binding = ShortcutButtonBinding.inflate(
        LayoutInflater.from(context), this, true
    )
    private var shortcutButtonType: ShortcutButtonType = ShortcutButtonType.SHORTCUT
    private lateinit var description: String
    private var mColor = ContextCompat.getColor(context, R.color.brand_color_primary)
    private var mDrawable =
        ContextCompat.getDrawable(context, R.drawable.button_shortcut_background)
    private var mInDrawable = ContextCompat.getDrawable(context, R.drawable.button_in_background)

    init {
        attrs?.let {
            fillAttributes(attrs)
        }
    }

    fun getDescription() = binding.descriptionShortcut.text.toString()

    override fun setShortcut(shortcut: Shortcut) = with(binding) {
        iconShortcut.text = setFontIcon(shortcut.icon)
        setShortcutType(shortcut.type)
        setupDescriptionAndAutoSize(descriptionShortcut, shortcut.description.trim(), shortcut.type)

        shortcutButton.contentDescription = retrieveContentDescriptionShortcut(shortcut)
        setupButtonAccessibility(shortcut.type)

    }

    private fun setShortcutType(type: ShortcutButtonType) = with(binding) {
        shortcutButtonType = type
        when (type) {
            ShortcutButtonType.IN -> {
                shortcutButton.background = mInDrawable
                iconShortcut.setTextColor(context.getColor(R.color.neutral_color_white))
                descriptionShortcut.setTextAppearance(R.style.button_white_sm)
            }
            ShortcutButtonType.COMING_SOON -> {
                shortcutButton.background =
                    ContextCompat.getDrawable(context, R.drawable.button_coming_soon_background)
                iconShortcut.setTextColor(mColor)
                iconShortcut.isClickable = false
            }
            ShortcutButtonType.SHORTCUT -> {
                configureShortcutLayout()
            }
            ShortcutButtonType.SHORTCUT_FILLED -> {
                configureShortcutLayout(
                    background = R.drawable.button_selected_background_light,
                    iconTextColor = R.color.porto_seguros_100,
                    textColor = R.color.neutral_color_darkest
                )
            }
            ShortcutButtonType.SHORTCUT_LIGHT -> {
                configureShortcutLayout(
                    background = R.drawable.button_shortcut_darkest_background,
                    iconTextColor = R.color.porto_seguros_100,
                    textColor = R.color.porto_seguros_100
                )
            }
            else -> shortcutButton.isVisible = false
        }
    }

    private fun configureShortcutLayout() = with(binding) {
        shortcutButton.background =
            mDrawable
        iconShortcut.setTextColor(mColor)
        iconShortcut.isClickable = false
        descriptionShortcut.setTextAppearance(R.style.text_regular_blue_primary)
        descriptionShortcut.setTextColor(mColor)
    }

    private fun configureShortcutLayout(
        background: Int = R.drawable.button_shortcut_background,
        iconTextColor: Int = R.color.brand_color_primary,
        textColor: Int = R.color.brand_color_primary
    ) = with(binding) {
        shortcutButton.background =
            ContextCompat.getDrawable(context, background)
        iconShortcut.setTextColor(context.getColor(iconTextColor))
        iconShortcut.isClickable = false
        descriptionShortcut.setTextAppearance(R.style.text_regular_blue_primary)
        descriptionShortcut.setTextColor(context.getColor(textColor))
    }

    fun setEnable(enable: Boolean) {
        if (enable) {
            setShortcutType(shortcutButtonType)
        } else {
            this.isClickable = false
            configureShortcutLayout(
                background = R.drawable.button_shortcut_disabled,
                iconTextColor = R.color.black_45,
                textColor = R.color.black_45
            )
        }
    }

    fun setIsSelected(isSelected: Boolean) {
        if (isSelected) {
            configureShortcutLayout(
                background = R.drawable.button_selected_background,
                iconTextColor = R.color.color_neutral_white,
                textColor = R.color.color_neutral_white
            )
        } else {
            configureShortcutLayout(
                background = R.drawable.button_shortcut_darkest_background,
                iconTextColor = R.color.porto_seguros_100,
                textColor = R.color.porto_seguros_100
            )
        }
    }

    private fun fillAttributes(attrs: AttributeSet? = null) {
        val attributes = context.obtainStyledAttributes(attrs, R.styleable.ShortcutButton)

        val icon = attributes.getString(R.styleable.ShortcutButton_shortcut_icon) ?: EMPTY_STRING
        val description =
            attributes.getString(R.styleable.ShortcutButton_shortcut_description) ?: EMPTY_STRING
        this.description = description
        val color = attributes.getColor(
            R.styleable.ShortcutButton_shortcut_color,
            ContextCompat.getColor(context, R.color.brand_color_primary)
        )
        mColor = color
        val drawable = attributes.getDrawable(R.styleable.ShortcutButton_shortcut_background)
        if (drawable != null) {
            mDrawable = drawable
        }
        val drawableIn = attributes.getDrawable(R.styleable.ShortcutButton_shortcut_background_in)
        if (drawableIn != null) {
            mInDrawable = drawableIn
        }


        adjustSize(attributes)

        shortcutButtonType =
            this.getShortcutButtonType(
                attributes.getInt(
                    R.styleable.ShortcutButton_shortcut_type,
                    0
                )
            ) ?: ShortcutButtonType.SHORTCUT

        binding.iconShortcut.text = icon
        binding.descriptionShortcut.text = description
        setShortcutType(shortcutButtonType)
        binding.shortcutButton.contentDescription = description
        setupButtonAccessibility(shortcutButtonType)

        attributes.recycle()
    }

    private fun adjustSize(attributes: TypedArray) {
        var newWidth = 0
        var newHeight = 0

        if (attributes.hasValue(R.styleable.ShortcutButton_shortcut_width)) {
            newWidth = attributes.getDimensionPixelSize(
                R.styleable.ShortcutButton_shortcut_width, 0
            )
        }

        if (attributes.hasValue(R.styleable.ShortcutButton_shortcut_height)) {
            newHeight = attributes.getDimensionPixelSize(
                R.styleable.ShortcutButton_shortcut_height, 0
            )
        }

        if (newWidth > 0 && newHeight > 0) {
            binding.shortcutButton.layoutParams = LayoutParams(newWidth, newHeight)
        }
    }

    private fun getShortcutButtonType(value: Int): ShortcutButtonType? =
        ShortcutButtonType.values().find { it.ordinal == value }

    private fun setupButtonAccessibility(type: ShortcutButtonType) {
        if (type != ShortcutButtonType.COMING_SOON) {
            binding.shortcutButton.setNodeInfoButton()
        }
    }

    fun setupAccessibility(contentDescription: String) {
        binding.shortcutButton.contentDescription = contentDescription
    }

    fun setFocusAndAnnounce() = with(binding) {
        shortcutButton.post {
            shortcutButton.sendAccessibilityEvent(AccessibilityEvent.TYPE_VIEW_FOCUSED)
            shortcutButton.announceForAccessibility(shortcutButton.contentDescription.toString())
        }
    }

    companion object {
        private const val EMPTY_STRING = ""
    }
}