package br.com.portoseguro.components.notificationview

import android.content.Context
import android.util.AttributeSet
import android.util.TypedValue
import android.view.View
import android.widget.TextView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.view.isVisible
import androidx.constraintlayout.widget.Guideline
import br.com.portoseguro.components.R
import br.com.portoseguro.components.withBoldText
import br.com.portoseguro.superapp.core.infrastructure.extensions.bindView

class NotificationView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleRes: Int = 0
) : ConstraintLayout(context, attrs, defStyleRes) {

    private val notificationViewMessage: TextView by bindView(R.id.notification_view_text)
    private val notificationViewIcon: TextView by bindView(R.id.notification_view_icon)
    private val notificationViewArrowIcon: TextView by bindView(R.id.notification_view_arrow_icon)
    private val notificationContainer: View by bindView(R.id.notification_view_container)
    private val notificationIconGuide: Guideline by bindView(R.id.notification_icon_guideline)

    init {
        inflate(context, R.layout.notification_view, this)

        attrs?.let { fillAttributes(it) }
    }

    private fun fillAttributes(attrs: AttributeSet) {
        val attributes = context.obtainStyledAttributes(attrs, R.styleable.NotificationView)

        val icon = attributes.getString(R.styleable.NotificationView_notificationView_icon)
        val displayArrow = attributes.getBoolean(R.styleable.NotificationView_notificationView_arrow_visible, false)
        val viewColor = attributes.getColor(
            R.styleable.NotificationView_notificationView_view_color,
            resources.getColor(R.color.brand_support_04, context.theme)
        )
        val fontColor = attributes.getColor(
            R.styleable.NotificationView_notificationView_font_color,
            resources.getColor(R.color.brand_color_secondary, context.theme)
        )
        val fontSize = attributes.getDimensionPixelSize(
            R.styleable.NotificationView_notificationView_textSize,
            NO_SIZE_PASSED
        )
        val iconSize = attributes.getDimensionPixelSize(
            R.styleable.NotificationView_notificationView_iconSize,
            NO_SIZE_PASSED
        )

        setIcon(icon ?: context.getString(R.string.icon_Calendar))
        setArrowVisibility(displayArrow)
        setViewColor(viewColor)
        setFontColor(fontColor)
        if (fontSize != NO_SIZE_PASSED) {
            setFontSize(fontSize)
        }
        if (iconSize != NO_SIZE_PASSED) {
            setIconSize(iconSize)
        }

        attributes.recycle()
    }

    fun setMessage(message: String) {
        notificationViewMessage.text = message
    }

    fun setAccessibilityMessage(messageContentDescription: String) {
        notificationContainer.contentDescription = messageContentDescription
    }

    fun setMessageBold(message: String, messageBold: String) {
        notificationViewMessage.text = message.withBoldText(messageBold)
    }

    fun setIcon(icon: String) {
        notificationViewIcon.text = icon
    }

    fun adjustIconMargin() {
        val iconParams = notificationViewIcon.layoutParams as LayoutParams
        iconParams.startToStart = notificationIconGuide.id
        notificationViewIcon.layoutParams = iconParams
    }

    private fun setViewColor(color: Int) {
        notificationContainer.setBackgroundColor(color)
    }

    private fun setFontColor(color: Int) {
        notificationViewIcon.setTextColor(color)
        notificationViewMessage.setTextColor(color)
        notificationViewArrowIcon.setTextColor(color)
    }

    private fun setArrowVisibility(visible: Boolean) {
        notificationViewArrowIcon.isVisible = visible
    }

    private fun setFontSize(size: Int) {
        notificationViewMessage.setTextSize(TypedValue.COMPLEX_UNIT_PX, size.toFloat())
    }

    private fun setIconSize(size: Int) {
        notificationViewIcon.setTextSize(TypedValue.COMPLEX_UNIT_PX, size.toFloat())
    }

    companion object {
        private const val NO_SIZE_PASSED = 0
    }
}