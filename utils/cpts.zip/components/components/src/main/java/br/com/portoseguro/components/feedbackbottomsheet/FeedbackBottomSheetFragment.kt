package br.com.portoseguro.components.feedbackbottomsheet

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import br.com.portoseguro.components.databinding.FragmentBottomSheetFeedbackBinding
import com.google.android.material.bottomsheet.BottomSheetDialogFragment

class FeedbackBottomSheetFragment : BottomSheetDialogFragment() {

    private var icon: Int? = null
    private var title: String? = null
    private var titleAccessibility: String? = null
    private var description: String? = null

    private val binding by lazy { FragmentBottomSheetFeedbackBinding.inflate(layoutInflater) }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View = binding.root

    override fun getTheme(): Int =
        br.com.portoseguro.components.R.style.BottomSheetDialogRoundedWithVerticalAnimationTheme

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        configureScreen()
    }

    private fun configureScreen() {
        icon?.let {
            binding.icon.setText(it)
        }
        title.let {
            binding.title.text = it
        }
        titleAccessibility?.let {
            binding.title.contentDescription = it
        }
        description?.let {
            binding.description.text = description
        }
        binding.close.setOnClickListener {
            dismiss()
        }
    }

    companion object {
        fun newInstance(
            iconText: Int?,
            titleText: String?,
            titleTextAccessibility: String? = null,
            descriptionText: String?
        ): FeedbackBottomSheetFragment = FeedbackBottomSheetFragment().apply {
            icon = iconText
            title = titleText
            titleAccessibility = titleTextAccessibility
            description = descriptionText
        }
    }
}