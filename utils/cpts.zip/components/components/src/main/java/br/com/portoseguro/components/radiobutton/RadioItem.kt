package br.com.portoseguro.components.radiobutton

data class RadioItem(
    val label: CharSequence,
    val icon: String? = null,
    val type: String? = null,
    var disabled: Boolean = false,
    var checked: Boolean = false
)