package br.com.portoseguro.components.selector

import android.content.Context
import android.util.AttributeSet
import android.view.LayoutInflater
import android.widget.FrameLayout
import androidx.core.view.isInvisible
import androidx.core.view.isVisible
import androidx.lifecycle.MutableLiveData
import br.com.portoseguro.components.R
import br.com.portoseguro.components.databinding.ViewLoadingSelectorBinding
import dev.kdblib.twowaybind.TwoWayBinder
import java.lang.ref.WeakReference

typealias StateChangedListener = ((state: LoadableSwitch.State) -> Unit)

class LoadableSwitch @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : FrameLayout(context, attrs, defStyleAttr) {

    private val binding: ViewLoadingSelectorBinding =
        ViewLoadingSelectorBinding.inflate(LayoutInflater.from(context), this, true)

    //region state setter
    var state: State = State.NotChecked
        set(value) {
            if (value != field) {
                if (!loadable && value is State.Loading){
                    return
                }

                if (value is State.Loading) {
                    value.beforeState = state
                    setLoading(true)
                } else {
                    setLoading(false)
                    setChecked(value is State.Checked)
                }

                field = value
                notifyStateChangedListener(value)
            }
        }
    //endregion state setter

    var loadable: Boolean = true

    var onSelectorClickListener: () -> Unit = {}

    private val onStateChangeListeners: MutableList<StateChangedListener> = mutableListOf()

    init {
        attrs?.let { setupView(attrs) }
    }

    fun addStateChangedListener(stateChangedListener: StateChangedListener) {
        onStateChangeListeners.add(stateChangedListener)
    }

    fun removeStateChangedListener(stateChangedListener: StateChangedListener) {
        onStateChangeListeners.remove(stateChangedListener)
    }

    private fun notifyStateChangedListener(state: State) {
        for (listener in onStateChangeListeners) {
            listener.invoke(state)
        }
    }

    private fun setupView(attrs: AttributeSet) {
        val attributes = context.obtainStyledAttributes(attrs, R.styleable.LoadableSwitch)
        val text: String? = attributes.getString(R.styleable.LoadableSwitch_vls_text)
        loadable = attributes.getBoolean(R.styleable.LoadableSwitch_loadable, true)
        text?.let {
            binding.selectorDescription.text = it
        }
        val textColor = attributes.getColor(
            R.styleable.LoadableSwitch_vls_text_color,
            context.getColor(R.color.brand_color_secondary)
        )

        binding.selectorDescription.setTextColor(textColor)
        text?.let {
            binding.apply {
                selectorDescription.text = it
            }
        }

        attributes.recycle()
        binding.selectorButton.setOnClickListener { onSelectorClick() }
        setupAccessibility(text)
    }

    //region selector listener
    private fun onSelectorClick() {
        onSelectorClickListener()
        if (state !is State.Loading) {
            state = when {
                loadable -> {
                    State.Loading()
                }
                state == State.Checked -> {
                    State.NotChecked
                }
                else -> {
                    State.Checked
                }
            }
        }
    }
    //endregion selector listener

    private fun setupAccessibility(text: String?) {
        val status = if (binding.selectorSwitch.isChecked) {
            context.getString(R.string.active)
        } else {
            context.getString(R.string.inactive)
        }

        contentDescription = "$text $status"
    }

    fun setTextColor(color: Int) {
        binding.selectorDescription.setTextColor(color)
    }

    fun setText(text: String) {
        binding.selectorDescription.text = text
        setupAccessibility(text)
    }

    private fun setLoading(enable: Boolean) {
        binding.selectorSwitch.isInvisible = enable
        binding.selectorLoading.isVisible = enable
        adjustLoadingAccessibility(enable)
    }

    private fun adjustLoadingAccessibility(enable: Boolean) {
        if (enable) {
            setupLoadingAccessibility()
        } else {
            setupAccessibility(binding.selectorDescription.text.toString())
        }
    }

    private fun setupLoadingAccessibility() {
        val text = binding.selectorDescription.text
        val status = context.getString(R.string.loading)
        contentDescription = "$text $status"
    }

    private fun setChecked(checked: Boolean) {
        binding.selectorSwitch.isChecked = checked
        setupAccessibility(binding.selectorDescription.text.toString())
    }

    fun changeState(isChecked: Boolean) {
        state = if (isChecked) State.Checked else State.NotChecked
    }

    fun isChecked() = binding.selectorSwitch.isChecked

    sealed class State {
        object Checked : State()

        class Loading : State() {
            var beforeState: State? = null
                internal set
        }

        object NotChecked : State()

        fun toBoolean(): Boolean? = when (this) {
            is Checked -> true
            is NotChecked -> false
            else -> null
        }

        companion object {
            fun fromBoolean(isChecked: Boolean): State = if (isChecked) Checked else NotChecked
        }
    }

    //region bindable switch
    /**
     * the check two way bindable
     *
     * @return boolean
     */
    val bindableSwitch: TwoWayBinder<State>
        get() = object : TwoWayBinder<State>() {

            var stateChangedListener: StateChangedListener? = null

            override val oneWayBind: (it: State) -> Unit
                get() = { state = it }

            override fun observeField(dataReference: WeakReference<MutableLiveData<State>?>) {
                stateChangedListener = {
                    val data = dataReference.get()
                    data?.let { dt -> dt.value = it }
                }
                stateChangedListener?.let {
                    addStateChangedListener(it)
                }
            }

            override fun removeObserver() {
                stateChangedListener?.let {
                    removeStateChangedListener(it)
                }
            }
        }
    //endregion bindable switch
}