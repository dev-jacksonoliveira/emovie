package br.com.portoseguro.components.shortcut

import android.content.Context
import android.util.AttributeSet
import android.util.TypedValue
import android.widget.TextView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.widget.TextViewCompat

/**
 * Classe base para um dos vários botões de atalhos.
 * Apresenta uma assinatura única para cada elementos visual distinto bem como
 * agrupa regras de exibição e configuração para os mesmos.
 */
abstract class BaseShortcutButton @JvmOverloads constructor(
        context: Context,
        attrs: AttributeSet? = null,
        defStyleRes: Int = 0
) : ConstraintLayout(context, attrs, defStyleRes) {

    /**
     * Realiza o setup deste botão de atalho dada as informações desejadas.
     * @param shortcut Dados a serem considerados para a configuração do botão de atalho.
     */
    abstract fun setShortcut(shortcut: Shortcut)

    /**
     * Configura a view de descrição (texto do botão) fornecida para o valor apropriado e
     * aplica as regras de exibição do texto para o mesmo.
     */
    protected fun setupDescriptionAndAutoSize(
            descriptionTextView: TextView,
            description: CharSequence,
            type: ShortcutButtonType
    ) {

        descriptionTextView.text = description
        val maxCharByLine = if (type == ShortcutButtonType.COMING_SOON) MAX_CHARACTER_BY_LINE_COMING_SOON else MAX_CHARACTER_BY_LINE

        if (description.length <= maxCharByLine) {
            descriptionTextView.setLines(ONE_LINE)
            descriptionTextView.minLines = ONE_LINE
            descriptionTextView.maxLines = ONE_LINE
        } else {
            descriptionTextView.setLines(TWO_LINES)
            descriptionTextView.minLines = TWO_LINES
            descriptionTextView.maxLines = TWO_LINES
        }

        TextViewCompat.setAutoSizeTextTypeUniformWithConfiguration(
                descriptionTextView,
                AUTO_SIZE_FONT_MIN,
                AUTO_SIZE_FONT_MAX,
                AUTO_SIZE_FONT_STEP,
                TypedValue.COMPLEX_UNIT_SP
        )
    }

    /**
     * Obtém o texto de acessibilidade esperado para o botão de atalho.
     */
    protected fun retrieveContentDescriptionShortcut(shortcut: Shortcut) =
            if (shortcut.type == ShortcutButtonType.IN) {
                context.getString(br.com.portoseguro.components.R.string.card_list_shortcut_mais)
            } else shortcut.description

    companion object {
        private const val MAX_CHARACTER_BY_LINE = 11
        private const val MAX_CHARACTER_BY_LINE_COMING_SOON = 27
        private const val ONE_LINE = 1
        private const val TWO_LINES = 2
        private const val AUTO_SIZE_FONT_MAX = 14
        private const val AUTO_SIZE_FONT_MIN = 12
        private const val AUTO_SIZE_FONT_STEP = 1
    }
}