package br.com.portoseguro.components

import androidx.fragment.app.FragmentManager
import com.google.android.material.bottomsheet.BottomSheetDialogFragment

fun BottomSheetDialogFragment.showSingleBottomSheet(fragmentManager: FragmentManager, tag: String) {
    val isShowed = fragmentManager.findFragmentByTag(tag)?.isVisible ?: false
    if (isShowed.not()) {
        show(fragmentManager, tag)
    }
}
