package br.com.portoseguro.components.loading

import android.content.Context
import android.util.AttributeSet
import android.widget.LinearLayout
import br.com.portoseguro.components.R
import kotlinx.android.synthetic.main.view_loading_full.view.*

class LoadingViewFull @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : LinearLayout(context, attrs) {

    init {
        inflate(context, R.layout.view_loading_full, this)

        attrs?.let {
            config()
        }
    }

    private fun config(){
        animationView.setAnimation(R.raw.loading_default)
        animationView.playAnimation()
    }

}