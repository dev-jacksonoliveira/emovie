package br.com.portoseguro.components

import android.content.Context
import android.graphics.drawable.Drawable
import android.util.AttributeSet
import android.view.LayoutInflater
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import androidx.annotation.ColorInt
import androidx.annotation.DrawableRes
import androidx.core.graphics.toColorInt
import androidx.core.view.isVisible
import br.com.portoseguro.components.databinding.UserCardViewBinding
import br.com.portoseguro.components.enums.Brand
import br.com.portoseguro.components.enums.CardType
import br.com.portoseguro.components.enums.CardType.MASTER_BLACK
import br.com.portoseguro.components.enums.CardType.MASTER_GOLD
import br.com.portoseguro.components.enums.CardType.MASTER_INTERNATIONAL
import br.com.portoseguro.components.enums.CardType.MASTER_PLATINUM
import br.com.portoseguro.components.enums.CardType.VISA_FREE
import br.com.portoseguro.components.enums.CardType.VISA_GOLD
import br.com.portoseguro.components.enums.CardType.VISA_INFINITE
import br.com.portoseguro.components.enums.CardType.VISA_INTERNATIONAL
import br.com.portoseguro.components.enums.CardType.VISA_PLATINUM
import br.com.portoseguro.superapp.core.infrastructure.extensions.capitalize
import com.bumptech.glide.Glide
import com.bumptech.glide.load.DataSource
import com.bumptech.glide.load.engine.GlideException
import com.bumptech.glide.request.RequestListener
import com.bumptech.glide.request.target.Target

class UserCardView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleRes: Int = 0
) : FrameLayout(context, attrs, defStyleRes) {

    private val binding: UserCardViewBinding by lazy {
        UserCardViewBinding.inflate(LayoutInflater.from(context), this, true)
    }

    var cardNumber: String = CARD_NUMBER_DEFAULT
        private set(value) {
            field = value
            binding.textViewCardNumber.text = value
        }

    var ownerName: String = CARD_OWNER_NAME_DEFAULT
        private set(value) {
            field = value
            binding.cardOwnerName.text = value
        }

    var brand: Brand = Brand.MASTERCARD
        private set(value) {
            field = value
            binding.cardBrand.setImageResource(value.imageRes)
        }

    var logoName: String = context.getString(VISA_INTERNATIONAL.rawLogoNameRes)
        private set(value) {
            field = value
            binding.cardType.text = value
        }

    private val defaultTextColor = context.getColor(R.color.neutral_color_white)

    init {
        attrs?.let { setupAttributes(context, it) }

        val radius = resources.getDimension(R.dimen.user_card_view_border_radius)
        val sam = binding.cardShapeableBackground.shapeAppearanceModel.toBuilder()
            .setAllCornerSizes(radius)
            .build()

        binding.cardShapeableBackground.shapeAppearanceModel = sam

        configureAccessibility()
    }

    private fun setupAttributes(context: Context, attrs: AttributeSet) {

        val typedArray = context.obtainStyledAttributes(attrs, R.styleable.UserCardView, 0, 0)

        val hasContentDescription = typedArray.getString(R.styleable.UserCardView_android_contentDescription) != null
        hideDescendantAccessibility(hasContentDescription)

        cardNumber = typedArray.getString(R.styleable.UserCardView_card_number) ?: CARD_NUMBER_DEFAULT
        ownerName = typedArray.getString(R.styleable.UserCardView_card_owner_name) ?: CARD_OWNER_NAME_DEFAULT

        val brandRaw = typedArray.getString(R.styleable.UserCardView_card_brand) ?: Brand.MASTERCARD.name
        val brandName = brandRaw.uppercase()

        brand = Brand.getByName(brandName)
        logoName = typedArray.getString(R.styleable.UserCardView_card_type) ?: context.getString(VISA_INTERNATIONAL.rawLogoNameRes)

        typedArray.recycle()
    }

    override fun setContentDescription(contentDescription: CharSequence?) {
        super.setContentDescription(contentDescription)
        hideDescendantAccessibility(contentDescription.isNullOrEmpty().not())
    }

    @Deprecated("use setupCard(CardSetupData) instead.")
    fun setupCard(number: String, name: String, type: CardType) {
        this.cardNumber = number
        this.ownerName = name
        this.brand = type.brand
        this.logoName = context.getString(type.rawLogoNameRes).capitalize()
        setupTextColors(defaultTextColor)
        setupBackground(type)
        configureAccessibility()
    }

    fun setupCard(setupData: CardSetupData) {
        val cardType = CardType.getByLogoCode(setupData.logoCode)

        // setup legacy properties
        cardNumber = setupData.cardNumber
        ownerName = setupData.userName
        logoName = setupData.logoName ?: context.getString(cardType.rawLogoNameRes).capitalize()

        // check for custom images
        binding.logoPorto.loadImageUrl(setupData.portoLogoUrl, R.drawable.ic_porto_bank_white)
        binding.cardBrand.loadImageUrl(setupData.brandLogoUrl, cardType.brand.imageRes)
        loadRemoteCardBackground(setupData.backgroundUrl, cardType)

        // setup custom text colors
        val textColor = setupData.textColors?.toColorInt() ?: defaultTextColor
        setupTextColors(textColor)

        configureAccessibility()
    }

    private fun ImageView.loadImageUrl(imageUrl: String?, @DrawableRes defaultDrawable: Int) {
        if (isInEditMode) {
            this.setImageResource(defaultDrawable)
            return
        }

        Glide.with(context)
            .load(imageUrl)
            .placeholder(defaultDrawable)
            .error(defaultDrawable)
            .into(this)
    }

    private fun loadRemoteCardBackground(backgroundUrl: String?, cardType: CardType) {

        if (isInEditMode || backgroundUrl.isNullOrBlank()) {
            setupBackground(cardType)
            return
        }

        Glide.with(context)
            .load(backgroundUrl)
            .listener(getRemoteCardBackgroundListener(cardType))
            .into(binding.cardShapeableBackground)
    }

    private fun getRemoteCardBackgroundListener(cardType: CardType) = object : RequestListener<Drawable> {

        override fun onLoadFailed(
            e: GlideException?,
            model: Any?,
            target: Target<Drawable>?,
            isFirstResource: Boolean
        ): Boolean {
            setupBackground(cardType)
            return true
        }

        override fun onResourceReady(
            resource: Drawable?,
            model: Any?,
            target: Target<Drawable>?,
            dataSource: DataSource?,
            isFirstResource: Boolean
        ): Boolean {
            binding.flagBackground.isVisible = false
            return false
        }

    }

    private fun hideDescendantAccessibility(hide: Boolean) {
        if (hide) {
            binding.cardRootView.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS
        }
    }

    private fun selectCardBackground(cardType: CardType) = when (cardType) {
        VISA_INTERNATIONAL, VISA_FREE, MASTER_INTERNATIONAL -> R.drawable.virtual_card_blue_background
        VISA_GOLD, MASTER_GOLD -> R.drawable.virtual_card_gold_background
        VISA_PLATINUM, MASTER_PLATINUM -> R.drawable.virtual_card_gray_background
        VISA_INFINITE, MASTER_BLACK -> R.drawable.virtual_card_black_background
    }

    private fun setupBackground(type: CardType) {
        val drawableRes = selectCardBackground(type)
        binding.cardShapeableBackground.setImageResource(drawableRes)
        binding.flagBackground.isVisible = true
    }

    private fun setupTextColors(@ColorInt color: Int) {
        binding.cardNumberLabel.setTextColor(color)
        binding.textViewCardNumber.setTextColor(color)
        binding.cardOwnerName.setTextColor(color)
        binding.cardType.setTextColor(color)
    }

    private fun configureAccessibility() = with(binding) {
        textViewCardNumber.contentDescription = context.getString(R.string.card_number_content_description, cardNumber)
        cardOwnerName.contentDescription = context.getString(R.string.card_owner_name_content_description, ownerName)

        val brandName = context.getString(brand.stringRes).replaceFirstChar { it.uppercaseChar() }
        cardType.contentDescription = "$brandName $logoName"
    }

    companion object {
        private const val CARD_NUMBER_DEFAULT = "0000 0000 0000 0000"
        private const val CARD_OWNER_NAME_DEFAULT = "Lorem Ipsum"
    }

    data class CardSetupData(
        val cardNumber: String,
        val userName: String,

        /**
         * Logo code that will be used to select tha base card layout.
         * @see [CardType]
         */
        val logoCode: String,

        /** Color to paint all the texts displayed over the card background/image. */
        val textColors: String? = null,

        /** Logo name to be displayed. It will override the [logoCode] default. */
        val logoName: String? = null,

        /** Url for the background / card layout. It will override the [logoCode] default. */
        val backgroundUrl: String? = null,

        /** Url for the porto logo. It will override the system default. */
        val portoLogoUrl: String? = null,

        /** Url for the brand logo mark. It will override the [logoCode] default. */
        val brandLogoUrl: String? = null
    )
}