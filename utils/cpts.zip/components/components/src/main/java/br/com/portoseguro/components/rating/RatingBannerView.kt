package br.com.portoseguro.components.rating

import android.content.Context
import android.util.AttributeSet
import android.view.LayoutInflater
import androidx.constraintlayout.widget.ConstraintLayout
import br.com.portoseguro.components.R
import br.com.portoseguro.components.databinding.ViewRatingBannerBinding
import br.com.portoseguro.components.setNodeInfoButton
import br.com.portoseguro.superapp.core.infrastructure.extensions.onClick
import br.com.portoseguro.superapp.core.utils.AccessibilityUtils

class RatingBannerView @JvmOverloads constructor(
        context: Context,
        attrs: AttributeSet? = null,
        defStyleRes: Int = 0
) : ConstraintLayout(context, attrs, defStyleRes) {

    private var binding = ViewRatingBannerBinding.inflate(LayoutInflater.from(context), this, true)
    var onRatingSelected:((Int) -> Unit)? = null

    private var inflated = false

    var title: String = context.getString(R.string.rating_banner_view_title)
        set(value) {
            field = value

            if (inflated) {
                binding.txtTitle.text = value
            }
        }

    private fun adjustRatingView() {
        binding.ratingView.setSubtitles(
            context.getString(R.string.rating_view_banner_bad_label),
            context.getString(R.string.rating_view_banner_great_label)
        )
    }

    init {
        adjustRatingView()
        setupListeners()
        setupAccessibility()
    }

    override fun onFinishInflate() {
        super.onFinishInflate()
        inflated = true
    }

    private fun setupListeners() {
        binding.ratingView.onRatingChangedListener = { value -> onRatingSelected?.invoke(value) }
    }

    private fun setupAccessibility() {
        val isAccessibilityEnabled = AccessibilityUtils.isScreenReaderEnabled(context)

        if (isAccessibilityEnabled) {
            binding.root.setNodeInfoButton()
            binding.root.onClick {
                onRatingSelected?.invoke(EMPTY_STARS)
            }
        }
    }

    fun clearRating() {
        binding.ratingView.clearRating()
    }

    companion object {
        private const val EMPTY_STARS = 0
    }
}