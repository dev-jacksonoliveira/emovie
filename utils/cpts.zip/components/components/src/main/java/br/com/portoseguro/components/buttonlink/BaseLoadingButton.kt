package br.com.portoseguro.components.buttonlink

import android.content.Context
import android.util.AttributeSet
import android.view.View
import android.widget.FrameLayout
import android.widget.TextView
import br.com.portoseguro.components.R

abstract class BaseLoadingButton(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : FrameLayout(context, attrs, defStyleAttr) {
    protected abstract val textViewButton: TextView

    /**
     * Sets the loading button visibility. If [enable] is true sets [loadingView] visibility to
     * [View.VISIBLE], otherwise [View.GONE].
     */
    open fun setLoading(enable: Boolean) {
        textViewButton.isEnabled = !enable
        textViewButton.setTextColor(
            if (enable) {
                textViewButton.resources.getColor(R.color.transparent, null)
            } else {
                textViewButton.resources.getColor(R.color.brand_color_primary, null)
            }
        )

        textViewButton.contentDescription = if (enable) {
            textViewButton.resources.getString(R.string.loading)
        } else {
            textViewButton.text
        }
    }

    /**
     * Set the button [text].
     */
    open fun setText(text: String) {
        textViewButton.text = text
    }

    /**
     * Invoke a callback of [onClick] when [textViewButton] is clicked.
     */
    open fun setOnClickListener(onClick: (View) -> Unit) {
        textViewButton.setOnClickListener {
            onClick(it)
        }
    }
}