package br.com.portoseguro.components.utils

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.text.Html
import android.util.DisplayMetrics
import androidx.core.text.HtmlCompat

object ComponentsUtils {

    /**
     * This method converts icons strings to CharSequence.
     *
     * @param icon A String of wanted icon. Example "e95c"
     * @return A CharSequence to use on icon text view.
     */
    fun setFontIcon(icon: String): CharSequence? {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            Html.fromHtml(icon, HtmlCompat.FROM_HTML_MODE_LEGACY)
        } else {
            Html.fromHtml(icon)
        }
    }

    /**
     * This method converts dp unit to equivalent pixels, depending on device density.
     *
     * @param dp A value in dp (density independent pixels) unit. Which we need to convert into pixels
     * @param context Context to get resources and device specific display metrics
     * @return A float value to represent px equivalent to dp depending on device density
     */
    fun convertDpToPixel(dp: Float, context: Context): Float =
        dp * (context.resources.displayMetrics.densityDpi.toFloat() / DisplayMetrics.DENSITY_DEFAULT)

    /**
     * This method converts device specific pixels to density independent pixels.
     *
     * @param px A value in px (pixels) unit. Which we need to convert into db
     * @param context Context to get resources and device specific display metrics
     * @return A float value to represent dp equivalent to px value
     */
    fun convertPixelsToDp(px: Float, context: Context): Float =
        px / (context.resources.displayMetrics.densityDpi.toFloat() / DisplayMetrics.DENSITY_DEFAULT)

    /**
     * This method return Intent with default browser and url
     *
     * @param url String of the expected website
     * @return Intent with default browser with url
     */
    fun defaultBrowserWithUrl(url: String): Intent {
        val defaultBrowser =
            Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_BROWSER)
        defaultBrowser.data = Uri.parse(url)
        return defaultBrowser
    }
}