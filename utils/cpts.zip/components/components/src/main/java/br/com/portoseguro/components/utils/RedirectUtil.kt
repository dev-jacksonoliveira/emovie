package br.com.portoseguro.components.utils

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.annotation.StringRes
import br.com.portoseguro.components.R
import br.com.portoseguro.components.genericwebview.GenericWebViewActivity

class RedirectUtil {

    fun startActivityFromUrl(context: Context, url: String) {
        val intent = Intent(Intent.ACTION_VIEW).apply {
            data = Uri.parse(url)
        }
        context.startActivity(intent)
    }

    fun redirectToWebView(context: Context, @StringRes title: Int, url: String) {
        val intent = GenericWebViewActivity.createIntent(
            GenericWebViewActivity.GenericWebViewData(
                context = context,
                webViewUrl = url,
                title = context.getString(title)
            )
        )
        context.startActivity(intent)
    }

    fun openDialPhone(context: Context, phoneNumber: String) {
        val number: Uri = Uri.parse(context.getString(R.string.action_dial_uri, phoneNumber))
        val intent = Intent(Intent.ACTION_DIAL, number)
        context.startActivity(intent)
    }

    fun openEmail(
        context: Context,
        to: Array<String> = arrayOf(),
        subject: String = "",
        body: String = ""
    ) {
        val intent = Intent(Intent.ACTION_MAIN).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
            addCategory(Intent.CATEGORY_APP_EMAIL)
            putExtra(Intent.EXTRA_EMAIL, to)
            putExtra(Intent.EXTRA_SUBJECT, subject)
            putExtra(Intent.EXTRA_TEXT, body)
        }
        context.startActivity(intent)
    }

    /**
     * Open website in the external preferred browser.
     *
     * @param context the activity context.
     * @param url to be opened.
     */
    fun launchBrowserUrl(context: Context, url: String) {
        val intent = Intent(Intent.ACTION_VIEW).apply {
            data = Uri.parse(url)
        }
        context.startActivity(Intent.createChooser(intent, null))
    }

    fun openChooserSendEmail(
        context: Context,
        to: Array<String> = arrayOf(),
        chooserTitle: String = "",
        subject: String = "",
        body: String = ""
    ) {
        val intent = Intent(Intent.ACTION_SENDTO).apply {
            data = Uri.parse(URI_SEND_EMAIL.format(to.joinToString(","), subject, body))
        }
        context.startActivity(Intent.createChooser(intent, chooserTitle))
    }

    private companion object {
        const val URI_SEND_EMAIL = "mailto:%s?subject=%s&body=%s"
    }
}
