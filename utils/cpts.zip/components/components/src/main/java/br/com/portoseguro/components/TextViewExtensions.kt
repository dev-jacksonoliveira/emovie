package br.com.portoseguro.components

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.graphics.Typeface
import android.os.Build
import android.text.Html
import android.text.style.TextAppearanceSpan
import android.util.TypedValue
import android.view.View
import android.widget.TextView
import androidx.annotation.ColorRes
import androidx.annotation.DimenRes
import androidx.annotation.NonNull
import androidx.appcompat.widget.AppCompatTextView
import br.com.portoseguro.components.utils.ComponentsUtils
import br.com.portoseguro.superapp.core.infrastructure.extensions.getCompatColor
import io.noties.markwon.AbstractMarkwonPlugin
import io.noties.markwon.Markwon
import io.noties.markwon.MarkwonSpansFactory
import io.noties.markwon.core.MarkwonTheme
import org.commonmark.node.StrongEmphasis

private const val ANIMATION_TIME_HALF = 2
private const val DEFAULT_FONT_FAMILY = "open_sans_bold"

/**
 * Faz animação de fade out e na sequencia um fade in com o novo texto
 * @param text texto a ser atualizado no textView
 * @param duration duração total da animação, que será dividida em 2 partes
 * (fade out texto existente + fade in com novo texto). Se nao informado duração padrao de 300ms
 *
 */
fun TextView.changeTextAnimation(text: String, duration: Long = DEFAULT_ANIMATION_DURATION) {
    val view = this
    view.animate()
        .alpha(ALPHA_TRANSPARENT)
        .setDuration(duration / ANIMATION_TIME_HALF)
        .setListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: Animator) {
                view.visibility = View.GONE
                view.text = text
                view.fadeIn(duration / ANIMATION_TIME_HALF)
            }
        })
}

/**
 * Recebe um fontIcon coloca no formato (&amp;#x%s) e seta para o textview.
 */
fun TextView.setUnformattedIcon(icon: String) {
    val convertPattern = "&#x%s;"
    val formattedIcon = convertPattern.format(icon)
    text = ComponentsUtils.setFontIcon(formattedIcon)
}

fun TextView.textHtml(text: String) {
    this.text = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
        Html.fromHtml(text, Html.FROM_HTML_MODE_COMPACT)
    } else {
        Html.fromHtml(text)
    }
}

fun TextView.setMarkDownText(
    markdownText: String,
    hasLinkUnderline: Boolean = false,
    @ColorRes linkColor: Int = R.color.porto_seguros_100,
    @DimenRes bulletWidth: Int = R.dimen.border_radius_sm
) {
    val context = this.context
    val markdown = Markwon.builder(context)
        .usePlugin(object : AbstractMarkwonPlugin() {
            override fun configureTheme(@NonNull builder: MarkwonTheme.Builder) {
                builder.isLinkUnderlined(hasLinkUnderline)
                    .linkColor(context.getCompatColor(linkColor))
                    .bulletWidth(resources.getDimension(bulletWidth).toInt())
            }

            override fun configureSpansFactory(builder: MarkwonSpansFactory.Builder) {
                builder.setFactory(StrongEmphasis::class.java) { _, _ ->
                    TextAppearanceSpan(
                        DEFAULT_FONT_FAMILY,
                        Typeface.BOLD,
                        0,
                        null,
                        null
                    )
                }
            }
        })
        .build()

    markdown.setMarkdown(this, markdownText.replace("[\\n\\\\]".toRegex(), "\n"))
}

fun TextView.setCustomFontSize(fontSize: Int) {
    this.setTextSize(
        TypedValue.COMPLEX_UNIT_PX,
        context.resources.getDimension(fontSize)
    )
}