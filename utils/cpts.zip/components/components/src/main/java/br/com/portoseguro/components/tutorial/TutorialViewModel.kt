package br.com.portoseguro.components.tutorial

import android.app.Activity
import br.com.portoseguro.components.tutorial.screen.TutorialScreen
import br.com.portoseguro.superapp.core.analytics.Analytics
import br.com.portoseguro.superapp.core.analytics.Analytics.Companion.subSectionList
import br.com.portoseguro.superapp.core.analytics.model.Action
import br.com.portoseguro.superapp.core.analytics.model.ViewItem
import br.com.portoseguro.superapp.core.analytics.utils.AnalyticsConstants
import br.com.portoseguro.superapp.core.infrastructure.BaseViewModel

class TutorialViewModel(val analytics: Analytics) : BaseViewModel() {

    fun trackPageView(activity: Activity?, tutorialScreen: TutorialScreen) =
        trackPageView(
            TutorialAnalyticsData(
                activity = activity,
                itemName = tutorialScreen.itemName,
                section = tutorialScreen.section.name,
                subSections = tutorialScreen.subSections.map { it.name },
                step = tutorialScreen.step,
                product = tutorialScreen.product
            )
        )

    internal fun trackPageView(data: TutorialAnalyticsData) {
        val itemName = data.itemName + data.step?.let { ":$it" }
        val trackItem = ViewItem(
            activity = data.activity,
            itemName = itemName,
            appSection = data.section
        )
        data.subSections?.forEachIndexed { index, subSection ->
            trackItem.add(subSectionList[index], subSection)
        }
        data.step?.let {
            trackItem.add(AnalyticsConstants.Param.STEP, data.step)
        }
        data.product?.let {
            trackItem.add(AnalyticsConstants.Param.PRODUCT, it)
        }

        analytics.trackViewItem(trackItem)
    }

    fun trackClickAction(tutorialScreen: TutorialScreen, step: String, buttonText: String) {
        val itemName = String.format(ITEM_NAME, tutorialScreen.itemName, step)
        val trackAction = Action(
            itemName = itemName,
            appSection = tutorialScreen.section.name,
            evCategory = String.format(EV_CATEGORY, tutorialScreen.product),
            evAction = String.format(EV_ACTION, tutorialScreen.name, buttonText)
        ).apply {
            tutorialScreen.product?.let {
                add(AnalyticsConstants.Param.PRODUCT, it)
            }

            val subsections = tutorialScreen.subSections.map { it.name }
            subsections.forEachIndexed { index, subSection ->
                add(subSectionList[index], subSection)
            }
        }

        analytics.trackAction(trackAction)
    }

    data class TutorialAnalyticsData(
        val activity: Activity?,
        val itemName: String,
        val section: String,
        val subSections: List<String>? = null,
        val step: String? = null,
        val product: String? = null
    )

    companion object {
        const val ITEM_NAME = "%s:%s"
        const val EV_CATEGORY = "app:mundoporto:%s"
        const val EV_ACTION = "click:%s:%s"
    }
}
