package br.com.portoseguro.components.enums

import android.content.Context
import androidx.annotation.DrawableRes
import androidx.annotation.StringRes
import br.com.portoseguro.components.R

enum class Brand(
    @StringRes val stringRes: Int,
    @DrawableRes val imageRes: Int,
    @DrawableRes val secondaryImageRes: Int
) {
    MASTERCARD(R.string.mastercard, R.drawable.ic_mastercard, R.drawable.ic_mastercard),
    VISA(R.string.visa, R.drawable.ic_visa_white, R.drawable.ic_visa);

    companion object {
        fun getByName(brandName: String) = values().find { it.name.contains(brandName, true) }
            ?: throw IllegalArgumentException("Brand not mapped")
    }
}

enum class CardType(val logoCode: String, @StringRes val rawLogoNameRes: Int, val brand: Brand) {
    VISA_INTERNATIONAL(logoCode = "001", rawLogoNameRes = R.string.international, brand = Brand.VISA),
    VISA_GOLD(logoCode = "002", rawLogoNameRes = R.string.gold, brand = Brand.VISA),
    VISA_PLATINUM(logoCode = "003", rawLogoNameRes = R.string.platinum, brand = Brand.VISA),
    VISA_INFINITE(logoCode = "005", rawLogoNameRes = R.string.infinite, brand = Brand.VISA),
    VISA_FREE(logoCode = "006", rawLogoNameRes = R.string.free, brand = Brand.VISA),
    MASTER_INTERNATIONAL(logoCode = "201", rawLogoNameRes = R.string.international, brand = Brand.MASTERCARD),
    MASTER_GOLD(logoCode = "202", rawLogoNameRes = R.string.gold, brand = Brand.MASTERCARD),
    MASTER_PLATINUM(logoCode = "203", rawLogoNameRes = R.string.platinum, brand = Brand.MASTERCARD),
    MASTER_BLACK(logoCode = "204", rawLogoNameRes = R.string.black, brand = Brand.MASTERCARD);

    companion object {

        /**
         * Retrieves the card type by it logo code.
         * If an unknown code is provided it will return [VISA_INTERNATIONAL].
         */
        fun getByLogoCode(code: String?): CardType = values().find {
            it.logoCode.equals(other = code, ignoreCase = true)
        } ?: VISA_INTERNATIONAL

        /**
         * Retrieves the card type by it logo name.
         * The search is case insensitive.
         * If an unknown logo name is provided it will return [VISA_INTERNATIONAL].
         */
        fun getByName(context: Context, name: String?): CardType = values().find {
            context.getString(it.rawLogoNameRes).equals(other = name, ignoreCase = true)
        } ?: VISA_INTERNATIONAL
    }
}