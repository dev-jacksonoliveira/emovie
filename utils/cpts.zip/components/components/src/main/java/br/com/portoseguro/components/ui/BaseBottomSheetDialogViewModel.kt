package br.com.portoseguro.components.ui

import android.app.Activity
import br.com.portoseguro.superapp.core.analytics.Analytics
import br.com.portoseguro.superapp.core.analytics.model.ProductInfo
import br.com.portoseguro.superapp.core.analytics.model.ViewItemError
import br.com.portoseguro.superapp.core.analytics.utils.AnalyticsConstants
import br.com.portoseguro.superapp.core.analytics.utils.Screen
import br.com.portoseguro.superapp.core.infrastructure.BaseAnalyticsViewModel

open class BaseBottomSheetDialogViewModel(
    private val analytics: Analytics
) : BaseAnalyticsViewModel(analytics) {

    fun trackError(activity: Activity?, message: String) {
        val viewItemError = ViewItemError(
            activity = activity,
            itemName = "${AnalyticsTags.ITEM_NAME_ERROR}:${message}",
            appSection = AnalyticsTags.SECTION,
            errorMessage = "${AnalyticsTags.SECTION}:${message}"
        )
            .add(AnalyticsConstants.Param.APP_SUB_SECTION_1, AnalyticsTags.SUB_SECTION_1_ERROR)

        analytics.trackViewItemError(viewItemError)
    }

    fun trackError(
        activity: Activity?,
        screen: Screen?,
        message: String,
        productInfo: ProductInfo?
    ) {
        screen?.let {
            super.trackErrorView(
                activity = activity,
                screen = screen,
                messageError = message,
                product = productInfo
            )
        }
    }

    companion object {

        protected object AnalyticsTags {
            const val ITEM_NAME_ERROR = "login:erro"
            const val SECTION = "login"
            const val SUB_SECTION_1_ERROR = "erro"
        }
    }
}