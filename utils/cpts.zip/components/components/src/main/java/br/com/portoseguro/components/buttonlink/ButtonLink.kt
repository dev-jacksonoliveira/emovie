package br.com.portoseguro.components.buttonlink

import android.content.Context
import android.util.AttributeSet
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.view.isVisible
import br.com.portoseguro.components.R
import br.com.portoseguro.components.setNodeInfoButton
import br.com.portoseguro.components.utils.ComponentsUtils
import br.com.portoseguro.superapp.core.infrastructure.extensions.bindView
import com.airbnb.lottie.LottieAnimationView

class ButtonLink @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : BaseLoadingButton(context, attrs, defStyleAttr) {

    private val loadingView: LottieAnimationView by bindView(R.id.imageLoading)
    override val textViewButton: TextView by bindView(R.id.textview_button_link)
    private val containerButtonLink: LinearLayout by bindView(R.id.text_button_link)
    private val textStart: TextView by bindView(R.id.textview_button_link_start)
    private val textEnd: TextView by bindView(R.id.textview_button_link_end)

    private var margin: Int = resources.getDimensionPixelSize(R.dimen.spacing_xs)

    init {
        inflate(context, R.layout.link_button_view, this)
        attrs?.let { setupView(attrs) }
    }

    private fun setupView(attrs: AttributeSet) {
        val attributes = context.obtainStyledAttributes(attrs, R.styleable.ButtonLink)

        val buttonText: String? =
            attributes.getString(R.styleable.ButtonLink_text_button_link)
        val enableButton: Boolean = attributes.getBoolean(R.styleable.ButtonLink_enable_button_link, true)
        val padding = attributes.getDimensionPixelOffset(R.styleable.ButtonLink_padding_button_link,
            margin
        )
        val marginTopDisable = attributes.getBoolean(R.styleable.ButtonLink_disable_margin_top_button_link, false)

        val drawableStart: String? = attributes.getString(R.styleable.ButtonLink_drawable_start_button_link) ?:""
        val drawableEnd: String? = attributes.getString(R.styleable.ButtonLink_drawable_end_button_link) ?:""
        if (drawableStart!!.isNotEmpty()){
            setDrawable(drawableStart, ButtonLinkDirection.START)
        }else if (drawableEnd!!.isNotEmpty()){
            setDrawable(drawableEnd, ButtonLinkDirection.END)
        }


        buttonText?.let {
            textViewButton.text = it
            textViewButton.contentDescription = it
        }

        setEnable(enableButton)
        setCustomMargin(padding)
        disableMargin(marginTopDisable)

        loadingView.setAnimation(R.raw.loading_button_blue)
        attributes.recycle()

        containerButtonLink.setOnClickListener {  }
    }

    fun setAccessibility(accessibility: Boolean) {
        when(accessibility) {
            true -> containerButtonLink.importantForAccessibility = IMPORTANT_FOR_ACCESSIBILITY_YES
            else -> containerButtonLink.importantForAccessibility = IMPORTANT_FOR_ACCESSIBILITY_NO
        }
    }

    fun setEnable(enable: Boolean) {
        textViewButton.isEnabled = enable
    }

    fun setCustomMargin(margin: Int = resources.getDimensionPixelSize(R.dimen.spacing_xs)) {
        this.margin = margin
    }

    fun disableMargin(disable: Boolean) {
        if (disable) {
            containerButtonLink.setPaddingRelative(
                margin, 1, margin, 1
            )
        } else {
            containerButtonLink.setPaddingRelative(
                margin, margin, margin, margin
            )
        }
    }

    fun setDrawable(drawableLink: String, direct: ButtonLinkDirection) {

        val image =
            ComponentsUtils.setFontIcon(
                drawableLink
            )



        when (direct) {
            ButtonLinkDirection.END -> {
                textEnd.text = image
                textEnd.visibility = View.VISIBLE
                textStart.visibility = View.GONE
            }
            ButtonLinkDirection.START -> {
                textStart.text = image
                textEnd.visibility = View.GONE
                textStart.visibility = View.VISIBLE
            }

        }


    }

    override fun setOnClickListener(onClick: (View) -> Unit) {
        containerButtonLink.setOnClickListener {
            onClick(it)
        }
    }

    override fun setLoading(enable: Boolean) {
        textStart.isVisible = !enable
        textEnd.isVisible = !enable

        loadingView.isVisible = enable
        textViewButton.isVisible = !enable
        super.setLoading(enable)
    }

    override fun setText(text: String) {
        super.setText(text)
        containerButtonLink.contentDescription = text
        containerButtonLink.setNodeInfoButton()
    }
}

enum class ButtonLinkDirection {
    START,
    END
}
