package br.com.portoseguro.components.maps

import android.location.Address
import android.location.Geocoder
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import br.com.portoseguro.components.R
import br.com.portoseguro.superapp.core.infrastructure.extensions.bindView
import br.com.portoseguro.superapp.core.log.Log
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.MapView
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MapStyleOptions
import com.google.android.gms.maps.model.MarkerOptions
import org.koin.android.ext.android.inject
import java.io.IOException
import java.util.Locale

private typealias AddressGenericException = Exception

class CustomMapFragment : Fragment(), OnMapReadyCallback {

    private val addressLabel: TextView by bindView(R.id.fragment_maps_address)
    private lateinit var gMap: GoogleMap
    private var mapView: MapView? = null

    private var latitude: Double = 0.0
    private var longitude: Double = 0.0
    private var showAddress: Boolean? = null

    private val log: Log by inject()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(
            R.layout.fragment_map, container, false
        )

        mapView =
            view.findViewById<View>(R.id.map_view) as MapView

        mapView?.onCreate(savedInstanceState)
        mapView?.let {
            it.getMapAsync(this@CustomMapFragment)
            it.isClickable = false
        }

        return view
    }

    override fun onStart() {
        super.onStart()
        mapView?.onStart()
    }

    override fun onResume() {
        super.onResume()
        mapView?.onResume()
    }

    override fun onPause() {
        super.onPause()
        mapView?.onPause()
    }

    override fun onStop() {
        super.onStop()
        mapView?.onStop()
    }

    override fun onDestroy() {
        super.onDestroy()
        mapView?.onDestroy()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        arguments?.let {
            latitude = it.getDouble(LATITUDE_KEY)
            longitude = it.getDouble(LONGITUDE_KEY)
            showAddress = it.getBoolean(SHOW_ADDRESS_KEY)
        }

        mapView?.onCreate(savedInstanceState)
    }

    override fun onMapReady(map: GoogleMap?) {
        map?.let {
            configureGoogleMaps(it)
            addMarkerAndShowMap(latitude, longitude)
        }
    }

    private fun configureGoogleMaps(it: GoogleMap) {
        gMap = it
        gMap.uiSettings.isMapToolbarEnabled = false
        gMap.uiSettings.isZoomControlsEnabled = false
        gMap.isTrafficEnabled = false
        gMap.setMapStyle(MapStyleOptions.loadRawResourceStyle(activity, R.raw.map_config))
    }

    private fun addMarkerAndShowMap(lat: Double, long: Double) {
        val coordinate = LatLng(lat, long)
        gMap.addMarker(
            MarkerOptions()
                .position(coordinate)
        )
        gMap.moveCamera(CameraUpdateFactory.newLatLng(coordinate))
        getAddress(lat, long)
    }

    private fun getAddress(lat: Double, long: Double) {
        val geoCoder = Geocoder(requireContext(), Locale.getDefault())

        try {
            val addresses: List<Address>? =
                geoCoder.getFromLocation(lat, long, MAPS_MAX_RESULTS)
            val address: String? = addresses?.get(0)?.getAddressLine(0)
            addressLabel.text = address.orEmpty()
            if (showAddress == true) {
                addressLabel.visibility = View.VISIBLE
            }
        } catch (ex: IOException) {
            log.logErrorAndPrintConsole(TAG, ex.message.toString())
            setVisibilityGoneOnMap()
        } catch (ex: AddressGenericException) {
            log.logErrorAndPrintConsole(TAG, ex.message.toString())
            setVisibilityGoneOnMap()
        }
    }

    private fun setVisibilityGoneOnMap() {
        mapView?.visibility = View.GONE
        addressLabel.visibility = View.GONE
    }

    companion object {
        private const val MAPS_MAX_RESULTS = 10
        private const val LATITUDE_KEY = "LATITUDE_KEY"
        private const val LONGITUDE_KEY = "LONGITUDE_KEY"
        private const val SHOW_ADDRESS_KEY = "SHOW_ADDRESS_KEY"
        private const val TAG = "GET_ADDRESS_ERROR"

        fun newInstance(latitude: Double, longitude: Double, showAddress: Boolean): CustomMapFragment {
            val mapFragment = CustomMapFragment()

            val bundle = Bundle()
            bundle.putDouble(LATITUDE_KEY, latitude)
            bundle.putDouble(LONGITUDE_KEY, longitude)
            bundle.putBoolean(SHOW_ADDRESS_KEY, showAddress)

            mapFragment.arguments = bundle

            return mapFragment
        }
    }
}