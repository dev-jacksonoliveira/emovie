package br.com.portoseguro.components.shortcut

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize


enum class ShortcutButtonType {
    SHORTCUT, IN, COMING_SOON, UNKNOWN, SHORTCUT_FILLED, SHORTCUT_LIGHT
}

@Parcelize
data class Shortcut(
    val link: String = "",
    val icon: String = "",
    val description: String = "",
    val type: ShortcutButtonType = ShortcutButtonType.SHORTCUT
) : Parcelable