package br.com.portoseguro.components.designsystem

import android.content.Context
import android.util.AttributeSet
import android.view.View
import android.widget.TextView
import androidx.constraintlayout.widget.ConstraintLayout
import br.com.portoseguro.components.R
import br.com.portoseguro.components.genericloadingbutton.GenericLoadingButton
import br.com.portoseguro.superapp.core.infrastructure.extensions.bindView

class CardErrorGeneric @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : ConstraintLayout(context, attrs, defStyleAttr) {

    private val errorTitle: TextView by bindView(R.id.error_title)
    private val errorIcon: TextView by bindView(R.id.error_icon)
    private val errorButton: GenericLoadingButton by bindView(R.id.card_error_generic_button)

    /**
     * This method set the action of click on button
     *
     * @param () -> Unit
     */
    fun setOnClickButton(body: () -> Unit) {
        errorButton.clickAction = {
            body.invoke()
        }
    }

    fun setTitleMessage(title: String) {
        errorTitle.text = title
    }

    fun setButtonText(buttonText: String) {
        errorButton.setText(buttonText)
    }

    /**
     * Sets or remove the loading state of the button.
     */
    fun isLoading(isLoading: Boolean) {
        errorButton.setLoading(isLoading)
    }

    init {
        View.inflate(context, R.layout.card_error_generic, this)
        attrs?.let { setupView(attrs) }
    }

    private fun setupView(attrs: AttributeSet) {
        val attributes = context.obtainStyledAttributes(attrs, R.styleable.CardErrorGeneric)

        val errorTitleAttrs: String? = attributes.getString(R.styleable.CardErrorGeneric_card_error_title)
        val errorIconAttrs: String? = attributes.getString(R.styleable.CardErrorGeneric_card_error_icon)
        val errorButtonAttrs: String? = attributes.getString(R.styleable.CardErrorGeneric_card_error_button)

        errorTitleAttrs?.let {
            errorTitle.text = it
        }
        errorIconAttrs?.let {
            errorIcon.text = it
        }
        errorButtonAttrs?.let {
            errorButton.setText(it)
        }
        attributes.recycle()
    }
}