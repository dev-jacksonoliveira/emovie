package br.com.portoseguro.components.utils

import android.text.Editable

class CardDueDateFormatter(
    private val onAfterTextChanged: ((String) -> Unit)? = null
) : BaseTextWatcher() {

    override fun afterTextChanged(text: Editable?) {
        val newNumericValue = text.toString().filter { it.isDigit() }

        if (textIsTheSame(newNumericValue, text)) return

        val maskedValue = newNumericValue.foldIndexed(StringBuilder("")) { i, acc, char ->
            when (i) {
                INDEX_BEFORE_SEPARATOR -> {
                    acc.append(SEPARATOR + char)
                }
                MAX_LENGTH -> acc
                else -> acc.append(char)
            }
        }

        text?.replace(0, text.length, maskedValue)
        onAfterTextChanged?.invoke(text.toString())
    }

    companion object {
        const val SEPARATOR = "/"
        const val INDEX_BEFORE_SEPARATOR = 2
        const val MAX_LENGTH = 4
    }
}