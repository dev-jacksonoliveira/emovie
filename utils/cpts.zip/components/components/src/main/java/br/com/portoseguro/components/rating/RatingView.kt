package br.com.portoseguro.components.rating

import android.content.Context
import android.util.AttributeSet
import android.view.LayoutInflater
import android.widget.ImageView
import androidx.constraintlayout.widget.ConstraintLayout
import br.com.portoseguro.components.R
import br.com.portoseguro.components.databinding.RatingViewBinding

class RatingView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleRes: Int = 0
) : ConstraintLayout(context, attrs, defStyleRes) {

    private var binding = RatingViewBinding.inflate(LayoutInflater.from(context), this, true)

    private var starList: List<ImageView>
    private var starAccessibilityList: Array<String>? = null
    private var selectedValue = DEFAULT_VALUE
    var onRatingChangedListener: ((Int) -> Unit)? = null

    init {
        starList = getStarList()
        setContentDescriptions()
        setupListeners()
    }

    fun handleRating(index: Int) {
        clearRating()
        updateRating(index)
        onRatingChangedListener?.invoke(index.plus(1))
    }

    private fun getStarList() = arrayListOf(
        binding.ivStar1,
        binding.ivStar2,
        binding.ivStar3,
        binding.ivStar4,
        binding.ivStar5
    )

    private fun setupListeners() {
        starList.forEachIndexed { index, view ->
            view.setOnClickListener {
                it.contentDescription = context.getString(
                    R.string.rating_view_selected_accessibility,
                    it.contentDescription
                )
                handleRating(index)
            }
        }
    }

    fun clearRating() {
        for (i in 0..STARS_NUMBER) {
            starList[i].setImageResource(R.drawable.ic_star_empty)
        }
        setContentDescriptions()
    }

    private fun setContentDescriptions() {
        starList[FIRST_INDEX].contentDescription =
            starAccessibilityList?.get(FIRST_INDEX)?:context.getString(R.string.rating_view_one_star_accessibility)
        starList[SECOND_INDEX].contentDescription =
            starAccessibilityList?.get(SECOND_INDEX)?:context.getString(R.string.rating_view_two_star_accessibility)
        starList[THIRD_INDEX].contentDescription =
            starAccessibilityList?.get(THIRD_INDEX)?:context.getString(R.string.rating_view_three_star_accessibility)
        starList[FOURTH_INDEX].contentDescription =
            starAccessibilityList?.get(FOURTH_INDEX)?:context.getString(R.string.rating_view_four_star_accessibility)
        starList[FIFTH_INDEX].contentDescription =
            starAccessibilityList?.get(FIFTH_INDEX)?:context.getString(R.string.rating_view_five_star_accessibility)
    }

    fun setSubtitles(firstStarText: String, lastStarText: String) {
        binding.textView3.text = firstStarText
        binding.textView2.text = lastStarText
    }

    fun setStarsAccessibility(list: Array<String>?) {
        starAccessibilityList = list
        setContentDescriptions()
    }

    private fun updateRating(selectedValue: Int) {
        for (i in 0..STARS_NUMBER) {
            if (i <= selectedValue) {
                shouldAnimate(i)
            }
        }
        this.selectedValue = selectedValue
    }

    private fun shouldAnimate(i: Int) {
        if (i <= selectedValue) {
            getStarView(i).setImageResource(R.drawable.ic_star_filled)
        } else {
            handleAnimation(
                getStarView(i),
                getAnimationScale(i),
                getAnimationDuration(i)
            )
        }
    }

    private fun handleAnimation(iv: ImageView, scale: Float, duration: Long) {
        iv.animate()
            .scaleX(scale)
            .scaleY(scale)
            .setDuration(duration)
            .withEndAction {
                iv.animate()
                    .scaleX(BASE_SCALE)
                    .scaleY(BASE_SCALE)
                    .duration = duration
                iv.setImageResource(R.drawable.ic_star_filled)
            }
    }

    private fun getStarView(index: Int) = starList[index]

    private fun getAnimationScale(index: Int) = BASE_SCALE.plus(index.times(ANIMATION_SCALE_INDEX))

    private fun getAnimationDuration(index: Int) = DURATION.times(index)

    fun unregisterListener() {
        onRatingChangedListener = null
    }

    companion object {

        private const val STARS_NUMBER = 4
        private const val BASE_SCALE = 1f
        private const val DURATION = 150L
        private const val DEFAULT_VALUE = 0
        private const val FIRST_INDEX = 0
        private const val SECOND_INDEX = 1
        private const val THIRD_INDEX = 2
        private const val FOURTH_INDEX = 3
        private const val FIFTH_INDEX = 4
        private const val ANIMATION_SCALE_INDEX = 0.1f
    }
}