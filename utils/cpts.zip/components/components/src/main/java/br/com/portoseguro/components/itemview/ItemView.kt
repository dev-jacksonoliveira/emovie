package br.com.portoseguro.components.itemview

import android.content.Context
import android.util.AttributeSet
import android.view.LayoutInflater
import android.view.View
import android.widget.TextView
import androidx.constraintlayout.widget.ConstraintLayout
import br.com.portoseguro.components.R
import br.com.portoseguro.components.databinding.ItemViewBinding
import br.com.portoseguro.components.setNodeInfoButton

class ItemView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleRes: Int = 0
) : ConstraintLayout(context, attrs, defStyleRes) {

    private var binding : ItemViewBinding =
        ItemViewBinding.inflate(LayoutInflater.from(context), this, true)

    private val container: View
    private val icon: TextView
    private val title: TextView
    private val subTitle: TextView

    init {
        binding.also {
            container = it.container
            icon = it.icon
            title = it.titleText
            subTitle = it.subtitleText
        }
        attrs?.let { fillAttributes(it) }
    }

    private fun fillAttributes(attrs: AttributeSet) {
        val attributes = context.obtainStyledAttributes(attrs, R.styleable.ItemView)

        val icon = attributes.getString(R.styleable.ItemView_iv_icon)
        val titleText = attributes.getString(R.styleable.ItemView_iv_title) ?: ""
        val subtitleText: String? = attributes.getString(R.styleable.ItemView_iv_subtitle)

        setupTitleAndSubtitle(titleText, subtitleText)
        icon?.let(::setupIcon)
        attributes.recycle()
    }

    fun setup(iconText: String? = null, titleText: String, subtitleText: String? = null) {
        setupIcon(iconText)
        setupTitleAndSubtitle(titleText, subtitleText)
    }

    private fun setupTitleAndSubtitle(titleText: String, subtitleText: String? = null) {
        title.text = titleText
        adjustSubtitle(subtitleText)
        setupAccessibility(titleText, subtitleText)
    }

    private fun adjustSubtitle(subtitleText: String?) {
        if (subtitleText != null) {
            subTitle.text = subtitleText
            subTitle.visibility = View.VISIBLE
        } else {
            subTitle.visibility = View.GONE
        }
    }

    private fun setupAccessibility(titleText: String, subtitleText: String? = null) {
        container.contentDescription = String.format(
            context.getString(R.string.itemview_accessibility_template),
            titleText,
            subtitleText ?: ""
        ).trim()
        container.setNodeInfoButton()
    }

    private fun setupIcon(iconText: String? = null) {
        if (iconText != null) {
            icon.text = iconText
            icon.visibility = View.VISIBLE
        } else {
            icon.visibility = View.GONE
        }
    }
}