package br.com.portoseguro.components.statepicker

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import br.com.portoseguro.components.R

class StatePickerAdapter(
    context: Context,
    private val listener: StatePickerListener,
    private val withInitials: Boolean = false
) : RecyclerView.Adapter<StatePickerViewHolder>() {

    private val statesFullName = context.resources.getStringArray(R.array.brazil_states).toList()
    private val statesInitials =
        context.resources.getStringArray(R.array.brazil_states_initials).toList()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): StatePickerViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_state_picker, parent, false)

        return StatePickerViewHolder(view, listener)
    }

    override fun getItemCount(): Int = statesFullName.size

    override fun onBindViewHolder(holder: StatePickerViewHolder, position: Int) =
        holder.bind(statesFullName[position], statesInitials[position], withInitials)
}