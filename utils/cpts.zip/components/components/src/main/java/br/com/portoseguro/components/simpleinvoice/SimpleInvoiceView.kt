package br.com.portoseguro.components.simpleinvoice

import android.content.Context
import android.util.AttributeSet
import android.view.View
import android.view.View.OnClickListener
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.view.isInvisible
import br.com.portoseguro.components.R
import br.com.portoseguro.components.error.ErrorView
import br.com.portoseguro.components.genericloadingbutton.GenericLoadingButton
import br.com.portoseguro.components.invoicesection.InvoiceSectionView
import br.com.portoseguro.superapp.core.infrastructure.extensions.bindView

@Deprecated("Use the new component InvoiceView located in br.com.portoseguro.components.designsystem package")
class SimpleInvoiceView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : ConstraintLayout(context, attrs, defStyleAttr) {

    private val invoiceStateView: View by bindView(R.id.simple_invoice_view)
    private val errorStateView: View by bindView(R.id.simple_invoice_error_view)

    private val invoiceSection: InvoiceSectionView by bindView(R.id.simple_invoice_section)

    private val primaryButton: GenericLoadingButton by bindView(R.id.simple_invoice_primary_button)
    private val secondaryButton: GenericLoadingButton by bindView(R.id.simple_invoice_secondary_button)
    private val errorView: ErrorView by bindView(R.id.simple_invoice_internal_error_view)

    init {
        View.inflate(context, R.layout.simple_invoice_view_container, this)
    }

    var state: ViewState = ViewState.OPEN
        set(value) {
            field = value
            setViewState(value)
        }

    var currentValue: String = ""
        set(value) {
            field = value
            updateCurrentValue()
        }

    var currentDate: String = ""
        set(value) {
            field = value
            updateCurrentDate()
        }

    var currency: String = REAL
        set(value) {
            field = value
            updateCurrency()
        }


    var tryAgainAction: (() -> Unit)? = null
        set(value) {
            field = value
            errorView.setOnClickButton(OnClickListener {
                value?.invoke()
            })
        }

    var primaryClickAction: (() -> Unit)? = null
        set(value) {
            field = value
            primaryButton.clickAction = { value?.invoke() }
        }

    var secondaryClickAction: (() -> Unit)? = null
        set(value) {
            secondaryButton.clickAction = { value?.invoke() }
            field = value
        }

    var secondaryButtonVisible: Boolean = true
        set(value) {
            secondaryButton.isInvisible = !value
            field = value
        }

    private fun updateCurrentDate() {
        invoiceSection.currentDate = currentDate
        invoiceSection.seeInvoiceButtonVisible = false
    }

    private fun updateCurrency() {
        invoiceSection.currency = currency
        invoiceSection.seeInvoiceButtonVisible = false
    }

    private fun updateCurrentValue() {
        invoiceSection.currentValue = currentValue
        invoiceSection.seeInvoiceButtonVisible = false
    }

    private fun changeClosedButtonsAccessibility() {
        secondaryButton.setAccessibilityText(
            resources.getString(
                R.string.simple_invoice_accessibility_payment_button
            )
        )
        primaryButton.setAccessibilityText(
            resources.getString(
                R.string.simple_invoice_accessibility_details_button
            )
        )
    }

    private fun setViewState(value: ViewState) {
        when (value) {
            ViewState.CLOSED -> configureClosedState()
            ViewState.OPEN -> configureOpenedState()
            else -> configureErrorView()
        }
    }

    private fun configureErrorView() {
        invoiceSection.state = InvoiceSectionView.ViewState.ERROR
        errorStateView.visibility = View.VISIBLE
        invoiceStateView.visibility = View.GONE
    }

    private fun configureClosedState() {
        invoiceSection.state = InvoiceSectionView.ViewState.CLOSED
        errorStateView.visibility = View.GONE
        invoiceStateView.visibility = View.VISIBLE
        configureClosedInvoiceButtons()
    }

    private fun configureOpenedState() {
        invoiceSection.state = InvoiceSectionView.ViewState.OPEN
        errorStateView.visibility = View.GONE
        invoiceStateView.visibility = View.VISIBLE
        configureOpenInvoiceButtons()

    }

    private fun configureOpenInvoiceButtons() {
        primaryButton.visibility = View.GONE
        secondaryButton.setText(resources.getString(R.string.simple_invoice_button_details))
        configureOpenedStateAcessibilityButton()
    }

    private fun configureClosedInvoiceButtons() {
        primaryButton.visibility = View.VISIBLE
        secondaryButton.setText(resources.getString(R.string.simple_invoice_button_paid))
        changeClosedButtonsAccessibility()
    }

    private fun configureOpenedStateAcessibilityButton() {
        secondaryButton.setAccessibilityText(
            resources.getString(
                R.string.simple_invoice_accessibility_details_button
            )
        )
    }

    fun setPaymentButtonLoading(loadingShouldBeDisplayed: Boolean) {
        secondaryButton.setLoading(loadingShouldBeDisplayed)
    }

    enum class ViewState {
        CLOSED,
        OPEN,
        ERROR
    }

    companion object {
        const val REAL = "R$"
    }
}

