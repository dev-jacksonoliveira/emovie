package br.com.portoseguro.components.genericwebviewbottomsheet

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.util.DisplayMetrics
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import br.com.portoseguro.components.R
import br.com.portoseguro.components.error.GenericErrorBottomSheetDialog
import br.com.portoseguro.components.ui.BaseStaticBottomSheetDialogFragment
import br.com.portoseguro.superapp.core.infrastructure.extensions.bindBundle
import br.com.portoseguro.superapp.core.infrastructure.extensions.bindView
import br.com.portoseguro.superapp.core.infrastructure.extensions.onClick
import com.google.android.material.bottomsheet.BottomSheetDialog

class GenericWebViewBottomSheetDialogFragment : BaseStaticBottomSheetDialogFragment() {

    private val close by bindView<Button>(R.id.close)
    private val webView: WebView by bindView(R.id.web_view)
    private val displayMetrics = DisplayMetrics()
    private val url: String by bindBundle(URL)

    private var trackPageView: (() -> Unit)? = null

    override fun getTheme(): Int = R.style.BottomSheetDialogRoundedWithVerticalAnimationTheme

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        dialog?.setOnShowListener {
            val bottomSheet = it as BottomSheetDialog
            setupFullHeight(bottomSheet)
            removeDrag(it)
        }

        return inflater.inflate(R.layout.terms_dialog, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        activity?.windowManager?.defaultDisplay?.getMetrics(displayMetrics)
        setupWebView()
    }

    override fun onStart() {
        super.onStart()

        close.onClick {
            dismiss()
        }

        trackPageView?.invoke()
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(
                view: WebView?,
                request: WebResourceRequest?
            ): Boolean {
                view?.context?.run {
                    startActivity(
                        Intent(Intent.ACTION_VIEW, request?.url)
                    )
                    return true
                }
                return false
            }

            override fun onReceivedError(
                view: WebView?,
                request: WebResourceRequest?,
                error: WebResourceError?
            ) {
                super.onReceivedError(view, request, error)
                configureError()
            }
        }

        webView.settings.javaScriptEnabled = true
        webView.loadUrl(url)
    }

    private fun configureError() {
        fragmentManager?.run {
            findFragmentByTag(ERROR_DIALOG_TAG)?.let {
                (it as GenericErrorBottomSheetDialog).updateLayoutForState()
                return
            }

            GenericErrorBottomSheetDialog().also { dialog ->
                dialog.setOnCloseListener { this@GenericWebViewBottomSheetDialogFragment.dismiss() }
                dialog.setOnReturnListener { this@GenericWebViewBottomSheetDialogFragment.dismiss() }
                dialog.setOnTryAgainListener { webView.loadUrl(url) }
                dialog.setReturnMessage(getString(R.string.terms_go_back))
                dialog.show(this, ERROR_DIALOG_TAG)
            }
        }
    }

    companion object {
        const val ERROR_DIALOG_TAG = "error_dialog_tag"
        private const val URL = "url"

        fun newInstance(
            url: String,
            trackPageViewHandler: (() -> Unit)? = null
        ): GenericWebViewBottomSheetDialogFragment =
            GenericWebViewBottomSheetDialogFragment().apply {
                trackPageView = trackPageViewHandler
                arguments = Bundle().apply { putString(URL, url) }
            }
    }
}