package br.com.portoseguro.components.enums

internal enum class ComponentsRemoteConfigKey(val key: String) {
    CROSS_SELL_PIN_NOTIFICATION("ab_cross_sell_show_notification")
}