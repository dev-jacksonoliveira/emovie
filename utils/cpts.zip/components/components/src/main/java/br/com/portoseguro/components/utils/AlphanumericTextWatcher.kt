package br.com.portoseguro.components.utils

import android.text.Editable
import android.widget.EditText
import br.com.portoseguro.components.removeSpecialCharacters

class AlphanumericTextWatcher(
    private val editText: EditText,
    private val onAfterTextChanged: ((String) -> Unit)? = null
): BaseTextWatcher() {

    override fun afterTextChanged(text: Editable?) {
        editText.removeTextChangedListener(this)
        text?.replace(0, text.length, text.toString().removeSpecialCharacters())
        onAfterTextChanged?.invoke(text.toString())
        editText.addTextChangedListener(this)
    }
}
