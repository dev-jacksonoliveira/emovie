package br.com.portoseguro.components

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context

private const val LABEL_BARCODE = "barcode"

fun Context.copyToClipboard(text: CharSequence, label: String = LABEL_BARCODE) {
    val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    val clip = ClipData.newPlainText(label, text)
    clipboard.setPrimaryClip(clip)
}