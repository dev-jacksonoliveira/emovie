package br.com.portoseguro.components.designsystem

import android.content.Context
import android.util.AttributeSet
import android.view.Gravity
import android.view.View
import android.widget.TextView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.constraintlayout.widget.ConstraintSet
import androidx.core.view.isVisible
import br.com.portoseguro.components.R
import br.com.portoseguro.superapp.core.infrastructure.extensions.bindView
import kotlin.math.roundToInt
import com.google.android.material.slider.Slider as MaterialSlider

/**
 * Visual element to allow the user to pick a value inside a range and segmented to a step.
 */
class Slider @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : ConstraintLayout(context, attrs, defStyleAttr) {

    private val minTextView: TextView by bindView(R.id.ds_slider_min_label)
    private val maxTextView: TextView by bindView(R.id.ds_slider_max_label)

    private val featuredContainer: ConstraintLayout by bindView(R.id.ds_slider_featured_container)
    private val featuredIndicator: View by bindView(R.id.ds_slider_featured_indicator)
    private val featuredTextView: TextView by bindView(R.id.ds_slider_featured_label)

    private val materialSlider: MaterialSlider by bindView(R.id.ds_slider_slider)

    //#region --- public properties

    /**
     * Label to be displayed on the minimum/left side of the track bar.
     * This is a CharSequence, you can provide formatted texts.
     */
    var minLabel: CharSequence = ""
        set(value) {
            field = value
            if (inflated) {
                minTextView.text = value
            }
        }

    /**
     * Label to be displayed on the maximum/right side of the track bar.
     * This is a CharSequence, you can provide formatted texts.
     */
    var maxLabel: CharSequence = ""
        set(value) {
            field = value
            if (inflated) {
                maxTextView.text = value
            }
        }

    /**
     * Label to be displayed below the track bar.
     * This is a CharSequence, you can provide formatted texts.
     */
    var featuredLabel: CharSequence = ""
        set(value) {
            field = value
            if (inflated) {
                featuredTextView.text = value
                if (isFeaturedLabelVisible) {
                    // when the indicator and/or the featured label are hidden, previous adjusts where ignored.
                    adjustFeaturedLabel()
                }
            }
        }

    /**
     * Controls the visibility of [minLabel]. Default is true/visible.
     */
    var isMinLabelVisible: Boolean = true
        set(value) {
            field = value
            if (inflated) {
                minTextView.isVisible = value
            }
        }

    /**
     * Controls the visibility of the entire component. Default is true/visible.
     */
    var isSliderVisible: Boolean = true
        set(value) {
            field = value
            if (inflated) {
                materialSlider.isVisible = value
                maxTextView.isVisible = value
                minTextView.isVisible = value
                featuredContainer.isVisible = value
                if (value) {
                    moveFeaturedIndicator()
                }
            }
        }

    /**
     * Controls the visibility of [maxLabel]. Default is true/visible.
     */
    var isMaxLabelVisible: Boolean = true
        set(value) {
            field = value
            if (inflated) {
                maxTextView.isVisible = value
            }
        }

    /**
     * Controls the visibility of [featuredLabel] and the above indicator. Default is true/visible.
     */
    var isFeaturedLabelVisible: Boolean = true
        set(value) {
            field = value
            if (inflated) {
                featuredContainer.isVisible = value
                if (value) {
                    // when the indicator and/or the featured label are hidden, previous adjusts where ignored.
                    moveFeaturedIndicator()
                }
            }
        }

    /**
     * Relative position to move the indicator. Must be a value between 0 and 1.
     */
    var featuredValuePosition: Float = 0f
        set(value) {
            field = value
            if (inflated && isFeaturedLabelVisible) {
                moveFeaturedIndicator()
            }
        }

    /**
     * Range to be considered for this slider. This pair represents the lowest and highest values for the track bar.
     * Change this range will cause the [value] to be to the lowest value.
     * Default value is [0f - 100f].
     */
    var valueRange: Pair<Float, Float> = DEFAULT_VALUE_FROM to DEFAULT_VALUE_TO
        set(value) {
            field = value
            if (inflated && !isInEditMode) {
                materialSlider.valueFrom = value.first
                materialSlider.valueTo = value.second
                materialSlider.value = value.first
            }
        }

    /**
     * Current value of the slider. An outside value of the range is allowed, but it will not be represented in the track bar.
     * Default value is 0f.
     */
    var value: Float = DEFAULT_VALUE_FROM
        set(value) {
            field = value
            if (inflated && !isInEditMode) {
                materialSlider.value = normalizeToRange(value)
            }
        }

    /**
     * Value to control the selected value when an user interact with the track bar.
     * Only multiples of [stepSize], and between the [valueRange], will be available to the user select.
     * This property do nothing when [value] is directly provided.
     * Default value is 10f.
     */
    var stepSize: Float = DEFAULT_STEP
        set(value) {
            field = value.coerceAtLeast(MIN_STEP)
        }

    /**
     * Callback to handle changes in the current [value] of this Slider.
     */
    var onChangeListener: OnChangeListener? = null

    //#endregion

    private var inflated = false

    private val internalSliderListener = MaterialSlider.OnChangeListener { slider, value, fromUser ->
        val valueToSet = if (fromUser) {
            // normalize the real value to the most near multiple of "stepSize" to provide a smooth scroll behaviour
            handleAsymmetricalValues(value)
        } else {
            // if the value is generate/provided without the user input, we'll use it as is
            value
        }
        // handle values outside the current range
        val normalizedValueToRange = normalizeToRange(valueToSet)

        slider.value = normalizedValueToRange

        // trigger external listener
        onChangeListener?.onValueChange(this@Slider, normalizedValueToRange, fromUser)
    }

    init {
        View.inflate(context, R.layout.view_design_system_slider, this)
        attrs?.let(::fillAttributes)
    }

    private fun fillAttributes(attrs: AttributeSet) {
        val attributes = context.obtainStyledAttributes(attrs, R.styleable.Slider)

        minLabel = attributes.getString(R.styleable.Slider_minLabel) ?: ""
        maxLabel = attributes.getString(R.styleable.Slider_maxLabel) ?: ""
        featuredLabel = attributes.getString(R.styleable.Slider_featuredLabel) ?: ""

        isMinLabelVisible = attributes.getBoolean(R.styleable.Slider_minLabelVisible, true)
        isMaxLabelVisible = attributes.getBoolean(R.styleable.Slider_maxLabelVisible, true)
        isFeaturedLabelVisible = attributes.getBoolean(R.styleable.Slider_featuredLabelVisible, true)

        featuredValuePosition = attributes.getFloat(R.styleable.Slider_featuredPosition, 0f)

        val valueFrom = attributes.getFloat(R.styleable.Slider_valueFrom, DEFAULT_VALUE_FROM)
        val valueTo = attributes.getFloat(R.styleable.Slider_valueFrom, DEFAULT_VALUE_TO)
        valueRange = valueFrom to valueTo
        value = attributes.getFloat(R.styleable.Slider_value, valueFrom)

        stepSize = attributes.getFloat(R.styleable.Slider_stepSize, DEFAULT_STEP)

        attributes.recycle()
    }

    override fun onFinishInflate() {
        super.onFinishInflate()
        setupValues()
        inflated = true
    }

    private fun setupValues() {
        setupLabels()
        setupBaseSlider()
    }

    private fun setupLabels() {
        minTextView.text = minLabel
        minTextView.isVisible = isMinLabelVisible

        maxTextView.text = maxLabel
        maxTextView.isVisible = isMaxLabelVisible

        featuredTextView.text = featuredLabel
        featuredContainer.isVisible = isFeaturedLabelVisible

        moveFeaturedIndicator()
    }

    private fun setupBaseSlider() {
        if (!isInEditMode) {
            materialSlider.apply {
                valueFrom = valueRange.first
                valueTo = valueRange.second
                value = this@Slider.value
                addOnChangeListener(internalSliderListener)
            }
        }
    }

    private fun moveFeaturedIndicator() {
        val constraintSet = ConstraintSet()
        constraintSet.clone(featuredContainer)
        constraintSet.setHorizontalBias(featuredIndicator.id, featuredValuePosition)
        constraintSet.applyTo(featuredContainer)
        featuredIndicator.invalidate()
        featuredIndicator.post {
            adjustFeaturedLabel()
        }
    }

    private fun adjustFeaturedLabel() {
        // retrieve the current elements positions
        featuredTextView.measure(0, 0)
        val featuredLabelHalfWidth = featuredTextView.measuredWidth / DIVIDER
        val indicatorLeftSpace = featuredIndicator.left
        val indicatorRightSpace = (featuredContainer.width - featuredIndicator.right).coerceAtLeast(0)

        val constraintSet = ConstraintSet()
        constraintSet.clone(featuredContainer)
        when {
            indicatorLeftSpace < featuredLabelHalfWidth -> {
                // featured label is near to the left side of the screen
                constraintSet.connect(featuredTextView.id, ConstraintSet.START, ConstraintSet.PARENT_ID, ConstraintSet.START)
                constraintSet.clear(featuredTextView.id, ConstraintSet.END)
                featuredTextView.gravity = Gravity.START
            }
            indicatorRightSpace < featuredLabelHalfWidth -> {
                // featured label is near to the right side of the screen
                constraintSet.clear(featuredTextView.id, ConstraintSet.START)
                constraintSet.connect(featuredTextView.id, ConstraintSet.END, ConstraintSet.PARENT_ID, ConstraintSet.END)
                featuredTextView.gravity = Gravity.END
            }
            else -> {
                // featured label is between both sides and have enough space to render em both directions
                constraintSet.connect(featuredTextView.id, ConstraintSet.START, featuredIndicator.id, ConstraintSet.START)
                constraintSet.connect(featuredTextView.id, ConstraintSet.END, featuredIndicator.id, ConstraintSet.END)
                featuredTextView.gravity = Gravity.CENTER_HORIZONTAL
            }
        }
        constraintSet.applyTo(featuredContainer)
    }

    private fun handleAsymmetricalValues(rawValue: Float): Float {

        // anchor points are related to itself, and doesn't consider the min/max values. i.e.:
        // if min = 50 and step = 100, then the anchor points will be (0, 100, 200, ...) and not (50, 150, 250, ...)
        // so, with some combination of values, the user will not be allowed to pick the min/max values while sliding the track button

        val isAsymmetricalStart = valueRange.first.rem(stepSize) > 0f
        val isAsymmetricalEnd = valueRange.second.rem(stepSize) > 0f

        val firstAnchorPoint = (valueRange.first / stepSize).roundToInt() * stepSize
        val lastAnchorPoint = (valueRange.second / stepSize).roundToInt() * stepSize

        return when {
            isAsymmetricalStart && rawValue < firstAnchorPoint -> valueRange.first
            isAsymmetricalEnd && rawValue > lastAnchorPoint -> valueRange.second
            else -> (rawValue / stepSize).roundToInt() * stepSize
        }
    }

    private fun normalizeToRange(rawValue: Float): Float =
        rawValue.coerceAtLeast(valueRange.first).coerceAtMost(valueRange.second)

    /**
     * Listener to handle changes with the current value of the [Slider].
     */
    interface OnChangeListener {
        /**
         * The [slider] now have the [value] and this change was triggered by the user if [fromUser] is true.
         */
        fun onValueChange(slider: Slider, value: Float, fromUser: Boolean)
    }

    companion object {
        private const val MIN_STEP = 1f
        private const val DEFAULT_VALUE_FROM = 0f
        private const val DEFAULT_VALUE_TO = 100f
        private const val DEFAULT_STEP = 10f

        private const val DIVIDER = 2
    }
}