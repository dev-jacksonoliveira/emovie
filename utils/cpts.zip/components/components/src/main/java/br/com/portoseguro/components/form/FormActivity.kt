package br.com.portoseguro.components.form

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.viewpager2.widget.ViewPager2
import br.com.portoseguro.components.R
import br.com.portoseguro.components.databinding.ActivityFormBinding
import br.com.portoseguro.components.form.adapter.FormAdapter
import br.com.portoseguro.components.form.data.FormAnalyticsModel
import br.com.portoseguro.components.form.data.FormCPFModel
import br.com.portoseguro.components.form.data.FormModel
import br.com.portoseguro.components.form.data.FormOptionsModel
import br.com.portoseguro.components.form.data.FormParameters
import br.com.portoseguro.components.form.data.FormTextModel
import br.com.portoseguro.components.form.viewmodel.FormViewModel
import br.com.portoseguro.components.ui.BaseActivity
import br.com.portoseguro.superapp.core.infrastructure.extensions.bindBundle
import br.com.portoseguro.superapp.core.infrastructure.extensions.onClick
import org.koin.androidx.viewmodel.ext.android.viewModel

/**
 * It is a form that accepts three type of data.
 *
 * @see [FormCPFModel] [FormTextModel] [FormOptionsModel]
 */
class FormActivity : BaseActivity() {

    private val binding by lazy { ActivityFormBinding.inflate(layoutInflater) }
    private val params: FormParameters by bindBundle(FORM_PARAMS)
    private val viewModel: FormViewModel by viewModel()
    private val formValues = hashMapOf<String, String>()
    private var modelList: List<FormModel> = listOf()
    private var analyticsModel: FormAnalyticsModel? = null
    private var position: Int = 0

    private val adapter = FormAdapter {
        toggleButton(it)
    }

    /*
     * If you want to finish form after conclusion step
     * you need to launch the next screen with this launcher and
     * then Activity.finish() with [FINISH_CODE] must be called.
     *
     */
    private val activityLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        if (it.resultCode == FINISH_CODE) {
            setResult(FINISH_CODE)
            finish()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        modelList = params.modelList
        analyticsModel = params.analyticsModel
        setContentView(binding.root)
        setupViews()
        setupListeners()
        setupViewPager()
    }

    private fun setupListeners() = with(binding) {
        formContinueButton.onClick {
            nextPage()
        }

        formToolbar.setBackButtonAction {
            previousPage()
        }
    }

    private fun saveStepValue(currentPosition: Int) {
        val value = modelList[currentPosition].value
        val key = modelList[currentPosition].key
        formValues[key] = value
    }

    private fun nextPage() = with(binding) {
        val currentPosition = formViewPager.currentItem
        val isAnimating = formProgressBar.isAnimating()
        if (!isAnimating) {
            increaseStep(currentPosition)
        }
    }

    private fun increaseStep(currentPosition: Int) = with(binding) {
        routeActionsTracking(currentPosition)
        if (currentPosition < modelList.size - 1) {
            position = currentPosition + 1
            formViewPager.currentItem = position
            formProgressBar.incrementStep()
            saveStepValue(currentPosition)
        } else {
            saveStepValue(currentPosition)
            finishForm()
        }
    }

    private fun routeActionsTracking(currentPosition: Int) {
        analyticsModel?.let {
            val model = modelList[currentPosition]
            trackFormAction(it, model.value, model.title, currentPosition)
        }
    }

    private fun trackFormAction(analyticsModel: FormAnalyticsModel, value: String, title: String, currentPosition: Int) {
        viewModel.trackFormAction(
            analyticsModel,
            value,
            title,
            currentPosition
        )
    }

    private fun finishForm() {
        successBlock?.invoke(formValues, activityLauncher)
    }

    private fun previousPage() = with(binding) {
        val currentPosition = formViewPager.currentItem
        val isAnimating = formProgressBar.isAnimating()
        if (!isAnimating) {
            decreaseStep(currentPosition)
        }

    }

    private fun decreaseStep(currentPosition: Int) = with(binding) {
        if (currentPosition > 0) {
            position = currentPosition - 1
            formViewPager.currentItem = position
            formProgressBar.decreaseStep()
        } else {
            onBackPressed()
        }
    }

    private fun setupViews() = with(binding) {
        formToolbar.title = params.title
        formProgressBar.setupProgressBar(params.modelList.size)
        disableButton()
    }

    private fun disableButton() = with(binding.formContinueButton) {
        isEnabled = false
        setBackgroundColor(getColor(R.color.brand_support_06))
    }

    private fun enableButton() = with(binding.formContinueButton) {
        isEnabled = true
        setBackgroundColor(getColor(R.color.brand_color_primary))
    }

    private fun setupViewPager() = with(binding) {
        formViewPager.offscreenPageLimit = modelList.size
        formViewPager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                super.onPageSelected(position)
                toggleButton(modelList[position].isValid)
                adapter.updateKeyBoard(position)
                analyticsModel?.let {
                    viewModel.trackFormPageView(this@FormActivity, position, it)
                }
            }
        })

        formViewPager.isUserInputEnabled = false

        adapter.updateItems(modelList)
        formViewPager.adapter = adapter
    }

    private fun toggleButton(enabled: Boolean) = if (enabled) {
        enableButton()
    } else {
        disableButton()
    }

    override fun onBackPressed() {
        if (position > 0) {
            previousPage()
        } else {
            super.onBackPressed()
        }
    }

    companion object {
        private const val FORM_PARAMS = "form_parameters"
        private const val FINISH_CODE = 2021
        private var successBlock: (((HashMap<String, String>), ActivityResultLauncher<Intent>) -> Unit)? = null

        /**
         * Retrieves the form Intent.
         *
         * @param formParameters the list of screens to be displayed.
         *
         * @see [FormParameters.analyticsModel] The basic data form analytics tracking.
         * @see [FormParameters.modelList] There are 3 possibilities [FormCPFModel] [FormTextModel] [FormOptionsModel]
         * @see [FormParameters.title] The title to be displayed.
         *
         * @param finishBlock callback that is responsible to notify when the form is completed.
         */
        fun getLaunchIntent(
            context: Context,
            formParameters: FormParameters,
            finishBlock: (((HashMap<String, String>), ActivityResultLauncher<Intent>) -> Unit)
        ) =
            Intent(context, FormActivity::class.java).apply {
                successBlock = finishBlock
                putExtra(FORM_PARAMS, formParameters)
            }
    }
}