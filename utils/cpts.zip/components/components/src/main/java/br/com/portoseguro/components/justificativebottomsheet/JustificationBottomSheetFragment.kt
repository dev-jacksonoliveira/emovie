package br.com.portoseguro.components.justificativebottomsheet

import android.content.DialogInterface
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager
import br.com.portoseguro.components.databinding.FragmentBottomSheetJustificationBinding
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment

class JustificationBottomSheetFragment : BottomSheetDialogFragment() {

    private var title: String? = null
    private var sendAction: ((idSelected: String?, text: String?) -> Unit)? = null
    private var closeActionListener: (() -> Unit)? = null
    private var list: List<AssessmentData>? = null
    var isDismissFromClose: Boolean = true

    private lateinit var articleAdapter: JustificationAdapter

    private val binding by lazy { FragmentBottomSheetJustificationBinding.inflate(layoutInflater) }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        dialog?.setOnShowListener {
            val dialog = it as BottomSheetDialog
            dialog.behavior.state = BottomSheetBehavior.STATE_EXPANDED
        }
        return binding.root
    }

    override fun getTheme(): Int =
        br.com.portoseguro.components.R.style.BottomSheetDialogRoundedWithVerticalAnimationTheme

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        configureScreen()
        configureListeners()
    }

    private fun configureScreen() {
        title.let {
            binding.title.text = it
        }

        list?.let {
            configureAdapter(it)
            configureRecyclerView()
        }
    }

    private fun configureListeners() {
        configureSendListener()
        configureCloseListener()
    }

    private fun configureCloseListener() {
        binding.closeButton.setOnClickListener {
            isDismissFromClose = true
            dismiss()
        }
    }

    fun configureSendListener() {
        binding.sendButton.setOnClickListener {
            sendAction?.invoke(getSelectedItemId(), getSelectedItemText())
            isDismissFromClose = false
            dismiss()
        }
    }

    private fun configureRecyclerView() {
        binding.recyclerView.apply {
            layoutManager = LinearLayoutManager(context)
            adapter = articleAdapter
        }
    }

    private fun configureAdapter(it: List<AssessmentData>) {
        articleAdapter = JustificationAdapter()
        articleAdapter.setItems(it)
        articleAdapter.onItemSelected = {
            binding.sendButton.setEnableButton(true)
        }
    }

    private fun getSelectedItemId() = articleAdapter.selectedId

    private fun getSelectedItemText() = articleAdapter.selectedText

    override fun onDismiss(dialog: DialogInterface) {
        super.onDismiss(dialog)
        if (isDismissFromClose) {
            closeActionListener?.invoke()
        }
    }

    companion object {
        fun newInstance(
            titleText: String?,
            justificativeList: List<AssessmentData>?,
            onSendClick: ((idSelected: String?, text: String?) -> Unit)?,
            closeAction: (() -> Unit)?
        ): JustificationBottomSheetFragment = JustificationBottomSheetFragment().apply {
            title = titleText
            list = justificativeList
            sendAction = onSendClick
            closeActionListener = closeAction
        }
    }
}