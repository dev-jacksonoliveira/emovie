package br.com.portoseguro.components.shortcut

data class AzulShortCut(
    val shortcut: Shortcut,
    val button: ShortcutButton,
    val isVisible: Boolean
)