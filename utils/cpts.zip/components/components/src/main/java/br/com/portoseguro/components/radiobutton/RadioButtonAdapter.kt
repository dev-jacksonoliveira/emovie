package br.com.portoseguro.components.radiobutton

import android.view.ContextThemeWrapper
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import br.com.portoseguro.components.R

class RadioButtonAdapter(
    private val hasSelector: Boolean = false,
    private val hasBackground: Boolean = false,
    private val highlightSelection: Boolean = false,
    private val onClickListener: (item: RadioItem) -> Unit
) :
    RecyclerView.Adapter<RadioButtonViewHolder>() {

    var items = listOf<RadioItem>()

    fun checkItem(item: RadioItem) =
        items.forEach { currentItem ->
            currentItem.checked = false
        }.run {
            item.checked = true
            notifyDataSetChanged()
        }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RadioButtonViewHolder {
        val theme = parent.resources.newTheme().apply {
            applyStyle(R.style.AppTheme_RadioButton, false)
            if (hasBackground) applyStyle(R.style.AppTheme_RadioButton_Background, true)
            if (hasSelector) applyStyle(R.style.AppTheme_RadioButton_Selector, true)
            if (highlightSelection) applyStyle(R.style.AppTheme_RadioButton_Highlight, true)
        }

        val view = LayoutInflater.from(ContextThemeWrapper(parent.context, theme))
            .inflate(R.layout.radio_button_item, parent, false)

        return RadioButtonViewHolder(view, onClickListener)
    }

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(holder: RadioButtonViewHolder, position: Int) {
        holder.bind(items[position])
    }
}