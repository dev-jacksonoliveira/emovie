package br.com.portoseguro.components.designsystem

import android.content.Context
import android.content.res.ColorStateList
import android.util.AttributeSet
import android.view.LayoutInflater
import android.view.View.OnClickListener
import androidx.annotation.ColorRes
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.content.res.ResourcesCompat
import androidx.core.view.isVisible
import androidx.core.view.updatePadding
import br.com.portoseguro.components.R
import br.com.portoseguro.components.databinding.LimitViewBinding
import br.com.portoseguro.components.error.ErrorInformation
import br.com.portoseguro.components.error.ErrorViewType
import br.com.portoseguro.components.withBoldText
import org.jetbrains.annotations.TestOnly

typealias ButtonAction = () -> Unit

class LimitView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : ConstraintLayout(context, attrs, defStyleAttr) {

    private var inflated = false

    private var currency: String = REAL
        set(value) {
            if (value.isNotBlank()) field = value
        }

    private var availableLimit: String = "0,00"

    private var usedLimit: String = "0,00"

    private var percentageOfUse: Int = 0
        set(value) {
            field = value.coerceIn(MIN_PROGRESS, MAX_PROGRESS)
            configureProgressPercentage(field)
        }

    private var differentiatedLimit: String = "0,00"

    private var limitSituation: Situation = Situation.NORMAL

    private var realLimitSituation: Situation = Situation.NORMAL

    /**
     * Changes and formats the "total limit" label.
     */
    var totalLimit: String = "0,00"
        set(value) {
            field = value
            if (inflated) {
                val color = getValuesColor()
                with(binding) {
                    limitLoaded.limitTotalValue.text = totalLimit.toCurrency(color)
                    limitLoading.limitViewLoadingTotalValue.text = totalLimit.toCurrency(color)
                }
            }
        }

    /**
     * Changes the "adjust limit" button label in both loading and loaded layout.
     */
    var limitLabel: String = resources.getString(R.string.card_list_adjust_limit_text)
        set(value) {
            field = value
            if (inflated) {
                with(binding) {
                    limitLoaded.adjustYourLimitText.text = limitLabel
                    limitLoading.limitViewLoadingAdjustYourLimitText.text = limitLabel
                }
            }
        }

    /**
     * Changes the visibility of "adjust limit" label.
     */
    var isLimitLabelEnabled: Boolean = true
        set(value) {
            field = value
            if (inflated) {
                with(binding) {
                    limitLoaded.adjustLimitGroup.isVisible = isLimitLabelEnabled
                    limitLoading.limitViewLoadingAdjustLimitGroup.isVisible = isLimitLabelEnabled
                }
                updateAccessibility()
            }
        }

    var state: State = State.LOADED
        set(value) {
            field = value
            adjustViewState()
        }

    var tryAgainAction: ButtonAction? = null
        set(value) {
            field = value
            binding.limitError.setOnClickButton(OnClickListener {
                field?.invoke()
            })
        }

    private val binding = LimitViewBinding.inflate(
        LayoutInflater.from(context), this, true
    )

    private var onContentLayoutListener: () -> Unit = {}
    private var onDateNotificationListener: () -> Unit = {}

    init {
        setTextViews()
        setListeners()
    }

    override fun onFinishInflate() {
        super.onFinishInflate()
        inflated = true
    }

    fun setup(model: LimitModel) {
        totalLimit = model.total
        usedLimit = model.used
        availableLimit = model.available
        currency = model.currency
        percentageOfUse = model.usedPercentage
        limitSituation = model.limitSituation
        differentiatedLimit = model.limitDifferentiated
        isLimitLabelEnabled = model.limitLabelEnabled
        limitLabel = model.limitLabel ?: resources.getString(R.string.card_list_adjust_limit_text)

        setDateNotification(model.isUpdated, model.lastUpdate)
        setTextViews()
        adjustRealStatus()
    }

    fun setOnContentLayoutListener(onClick: () -> Unit) {
        onContentLayoutListener = onClick
    }

    fun setOnDateNotificationListener(onClick: () -> Unit) {
        onDateNotificationListener = onClick
    }

    fun updateContainerPadding(paddingTop: Float, paddingBottom: Float) {
        binding.limitContainer.updatePadding(top = paddingTop.toInt(), bottom = paddingBottom.toInt())
    }

    fun configureRoundedBackground(paddingTop: Float, paddingBottom: Float) {
        updateContainerPadding(paddingTop, paddingBottom)
        binding.limitContainer.setBackgroundResource(R.drawable.shape_invoice_view_background)
    }

    fun configureErrorRoundedBackground(padding: Int = 0) = with(binding.limitError) {
        updatePadding(padding, padding, padding, padding)
        setupTryAgainErrorRoundedCorner()
    }

    fun configureWithoutTryAgainErrorRoundedBackground(padding: Int = 0) = with(binding.limitError) {
        updatePadding(padding, padding, padding, padding)
        setupWithoutTryAgainErrorRoundedCorner()
    }

    private fun adjustRealStatus() {
        realLimitSituation = limitSituation
        configureProgressBarAndLimits()
    }

    private fun configureProgressBarAndLimits() = with(binding.limitLoaded) {
        val color = resources.getColor(realLimitSituation.color, null)
        limitUsedValue.setTextColor(color)
        limitProgressBar.progressTintList = ColorStateList.valueOf(color)
    }

    private fun configureProgressPercentage(field: Int) = with(binding.limitLoaded) {
        limitProgressBar.progressDrawable = if (field == MAX_PROGRESS) {
            ResourcesCompat.getDrawable(
                resources,
                R.drawable.limit_view_progressbar_full_rounded_corner,
                null
            )
        } else {
            ResourcesCompat.getDrawable(
                resources,
                R.drawable.limit_view_progressbar_start_rounded_corner,
                null
            )
        }
        limitProgressBar.progress = field
    }

    private fun setDateNotification(
        isUpdated: Boolean?,
        lastUpdate: String?
    ) = with(binding.limitLoaded.limitViewDateNotification) {
        textViewDate.text = lastUpdate
        root.isVisible = isUpdated == false && lastUpdate?.isNotBlank() == true
    }

    private fun setTextViews() = with(binding) {
        val color = getValuesColor()
        limitLoaded.limitTotalValue.text = totalLimit.toCurrency(color)
        limitLoading.limitViewLoadingTotalValue.text = totalLimit.toCurrency(color)
        limitLoaded.limitAvailableValue.text = availableLimit.toCurrency(color)
        limitLoaded.limitUsedValue.text = usedLimit.toCurrency()
        updateAccessibility()
    }

    private fun setListeners() = with(binding.limitLoaded) {
        root.setOnClickListener { onContentLayoutListener.invoke() }
        limitViewDateNotification.root.setOnClickListener { onDateNotificationListener.invoke() }
    }

    private fun getValuesColor() = resources.getColor(R.color.neutral_color_grey_02, null)

    private fun String.toCurrency(color: Int? = null) =
        String.format(CURRENCY_TEMPLATE, currency, this).withBoldText(this, color)

    private fun updateAccessibility() {
        if (state != State.LOADED) {
            contentDescription = String()
            return
        }

        with(binding.limitLoaded) {
            contentDescription = resources.getString(
                R.string.limit_view_content_description,
                limitUsedValue.text,
                limitTotalValue.text,
                limitAvailableValue.text
            )
        }
    }

    private fun adjustViewState() = when (state) {
        State.LOADING -> showState(loading = true)
        State.LOADED -> showState(success = true)
        State.ERROR -> showState(error = true)
        State.ERROR_WITHOUT_TRY_AGAIN -> showState(error = true, showTryAgain = false)
    }

    private fun showState(
        loading: Boolean = false,
        success: Boolean = false,
        error: Boolean = false,
        showTryAgain: Boolean = true
    ) = with(binding) {
        limitLoading.root.isVisible = loading
        limitLoaded.limitViewGroup.isVisible = success
        limitLoaded.adjustLimitGroup.isVisible = success && isLimitLabelEnabled
        limitError.isVisible = error
        if (!showTryAgain) {
            limitError.setup(
                ErrorInformation(
                    type = ErrorViewType.VIEW_WITHOUT_TRY_AGAIN,
                    message = resources.getString(R.string.limit_view_error_message),
                    icon = resources.getString(R.string.icon_alert)
                )
            )
        }
        updateAccessibility()
    }

    companion object {
        private const val MIN_PROGRESS = 0
        private const val MAX_PROGRESS = 100
        private const val REAL = "R$"

        private const val CURRENCY_TEMPLATE = "%s %s"

        @TestOnly
        internal fun build(context: Context) = LimitView(context).apply {
            onFinishInflate()
        }
    }

    enum class Situation(@ColorRes val color: Int, val typeName: String) {
        NORMAL(R.color.brand_support_03, "normal"),
        ATTENTION(R.color.brand_support_02, "aviso"),
        CRITICAL(R.color.brand_support_01, "critico")
    }

    enum class State {
        LOADED,
        LOADING,
        ERROR,
        ERROR_WITHOUT_TRY_AGAIN
    }
}

data class LimitModel(
    val total: String,
    val available: String,
    val used: String,
    val currency: String,
    val usedPercentage: Int,
    val limitSituation: LimitView.Situation,
    val limitDifferentiated: String,
    val limitLabelEnabled: Boolean = true,
    val limitLabel: String? = null,
    val lastUpdate: String? = null,
    val isUpdated: Boolean? = null
)