package br.com.portoseguro.components

import android.os.Bundle
import android.view.View
import android.widget.FrameLayout
import android.widget.FrameLayout.LayoutParams
import androidx.appcompat.app.AppCompatActivity

class CustomViewContainerActivity : AppCompatActivity() {

    private val frameLayout by lazy { findViewById<FrameLayout>(R.id.root_layout) }

    override fun onCreate(savedInstanceState: Bundle?) {
        setTheme(R.style.AppTheme)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_custom_view_wrapper)
    }

    fun addCustomView(view: View, width: Int = LayoutParams.MATCH_PARENT, height: Int = LayoutParams.MATCH_PARENT) {
        view.layoutParams = LayoutParams(width, height)
        runOnUiThread { frameLayout.addView(view) }
    }
}