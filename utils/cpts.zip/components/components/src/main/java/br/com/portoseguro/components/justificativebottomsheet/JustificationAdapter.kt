package br.com.portoseguro.components.justificativebottomsheet

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.ViewGroup
import android.view.accessibility.AccessibilityEvent
import androidx.recyclerview.widget.RecyclerView
import br.com.portoseguro.components.databinding.ItemJustificativeBinding

internal class JustificationAdapter : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    private var items: MutableList<AssessmentData> = mutableListOf()
    private var selectedCheckbox = NO_CHECKBOX_SELECTED
    var onItemSelected: (() -> Unit)? = null
    var selectedId: String? = null
    var selectedText: String? = null

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val itemBinding: ItemJustificativeBinding =
            ItemJustificativeBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ItemViewHolder(itemBinding)
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        if (holder is ItemViewHolder) {
            holder.bind(items[position])
        }
    }

    @SuppressLint("NotifyDataSetChanged")
    fun setItems(list: List<AssessmentData>) {
        items.clear()
        items.addAll(list)
        notifyDataSetChanged()
    }

    fun addItems(list: List<AssessmentData>) {
        val previousSize = items.size
        items.addAll(list)
        notifyItemRangeInserted(previousSize, list.size)
    }

    private inner class ItemViewHolder(
        val binding: ItemJustificativeBinding
    ) : RecyclerView.ViewHolder(binding.root) {

        fun bind(data: AssessmentData) {
            data.description.let {
                binding.item.setup(iconText = null, descriptionText = it, contentDescription = it)
            }
            binding.item.setCheck(adapterPosition == selectedCheckbox)
            binding.item.setOnClickListener {
                selectedCheckbox = adapterPosition
                notifyDataSetChanged()
            }
            binding.item.setOnCheckedChangeListener { isChecked ->
                if (isChecked) {
                    selectedId = data.id
                    selectedText = data.description
                    announceDescription()
                    onItemSelected?.invoke()
                }
            }
        }

        private fun announceDescription() {
            binding.item.apply {
                post {
                    sendAccessibilityEvent(AccessibilityEvent.TYPE_VIEW_FOCUSED)
                    announceForAccessibility(binding.item.contentDescription)
                }
            }
        }
    }

    override fun getItemCount() = items.size

    companion object {
        private const val NO_CHECKBOX_SELECTED = -1
    }
}