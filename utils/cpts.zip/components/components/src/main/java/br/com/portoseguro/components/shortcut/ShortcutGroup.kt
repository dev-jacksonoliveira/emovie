package br.com.portoseguro.components.shortcut

import android.content.Context
import android.util.AttributeSet
import android.view.View
import android.view.View.OnClickListener
import android.widget.TextView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.constraintlayout.widget.ConstraintSet
import androidx.constraintlayout.widget.Guideline
import br.com.portoseguro.components.R
import br.com.portoseguro.components.error.ErrorView
import br.com.portoseguro.components.shortcut.ShortcutGroup.Companion
import br.com.portoseguro.superapp.core.infrastructure.extensions.bindView
import br.com.portoseguro.superapp.core.infrastructure.extensions.onClick

/**
 * View agrupadora de atalhos para um layout dinâmico em [Companion.NUMBER_OF_COLS] colunas.
 *
 * Cada botão terá uma aparência variada a fim de mostrar um layout em quebra-cabeças construído da
 * esquerda para a direita e de cima para baixo.
 */
class ShortcutGroup @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : ConstraintLayout(context, attrs, defStyleAttr) {

    private val mainContainer: ConstraintLayout by bindView(R.id.shortcut_group_main_container)
    private val leftGuideline: Guideline by bindView(R.id.shortcut_group_left_guideline)
    private val rightGuideline: Guideline by bindView(R.id.shortcut_group_right_guideline)

    private val loadedContainer: ConstraintLayout by bindView(R.id.shortcut_group_main_container)
    private val errorContainer: ConstraintLayout by bindView(R.id.shortcut_group_error_container)
    private val loadingContainer: ConstraintLayout by bindView(R.id.shortcut_group_loading_container)
    private val errorView: ErrorView by bindView(R.id.shortcut_group_error_view)

    private val shortcutLabelTextView: TextView by bindView(R.id.shortcut_label)
    private val shorcutLabelBarrier: View by bindView(R.id.shortcut_label_barrier)

    private var ids = mutableListOf<Int>()
    private var shortcuts = listOf<Shortcut>()

    /**
     * Listener de click sobre os botões deste agrupador.
     */
    var onClickListener: ((s: Shortcut) -> Unit)? = null

    /**
     * Variable referencing a component state
     */
    var state: ViewState = ViewState.LOADING
        set(value) {
            configureShortcutGroupState(value)
        }

    /**
     * Try again listener for error button
     */
    var tryAgainListener: (() -> Unit)? = null
        set(value) {
            field = value
            errorView.setOnClickButton(OnClickListener {
                value?.invoke()
            })
        }

    /**
     * Variable referencing to the shortcut group label.
     */
    var shortcutLabel: String = EMPTY
        set(value) {
            setShortcutTitle(value)
            field = value
        }


    init {
        View.inflate(context, R.layout.shortcut_group_container, this)
        handleAttr(context, attrs)
    }

    companion object {
        /**
         * Número de colunas para o qual este agrupador está configurado.
         * Alterar esse valor sem alterar o layout inflado poderá ocasionar problemas
         * na exibição do mesmo.
         */
        const val NUMBER_OF_COLS = 3

        const val EMPTY = ""

        private const val EVEN = 2
    }

    /**
     * Adiciona a lista de atalhos fornecidas ao agrupador.
     * Chamar esse método seguidamente irá remover os ícones anteriores.
     *
     * @param objects Lista de atalhos a serem adicionados ao agrupador.
     */
    fun addShortcuts(objects: List<Shortcut>) {

        removePreviousShortcuts()

        shortcuts = objects
        ids = MutableList(size = objects.size) { 0 }

        var row: Int
        var col: Int
        for (position in objects.indices) {
            // ajusta variáveis de controle de iteração
            row = position / NUMBER_OF_COLS
            col = position % NUMBER_OF_COLS

            val current = objects[position]
            val currentId = View.generateViewId()
            ids[position] = currentId

            // obtém e configura a view a ser adicionada ao agrupador
            val view = ShortcutGroupButton.build(context).apply {
                id = currentId

                // como o estilo do botão é definido pela localização dele dentro do agrupador,
                // iremos ignorar a propriedade "type" de [Shortcut] e atribuir um valor calculado.
                val height = if (position % EVEN == 0) {
                    resources.getDimension(R.dimen.shortcut_group_long_button_height).toInt()
                } else {
                    resources.getDimension(R.dimen.shortcut_group_small_button_height).toInt()
                }
                setShortcut(current)

                layoutParams = LayoutParams(0, height)
            }

            mainContainer.addView(view)

            // ajusta o posicionamento da nova view no agrupador
            val (leftId, rightId) = when (col) {
                0 -> ConstraintSet.PARENT_ID to leftGuideline.id
                1 -> leftGuideline.id to rightGuideline.id
                else -> rightGuideline.id to ConstraintSet.PARENT_ID
            }

            val topId = if (row == 0) {
                shorcutLabelBarrier.id
            } else {
                ids[position - NUMBER_OF_COLS]
            }

            adjustViewLocation(view, leftId, rightId, topId)
            addOnClickListener(view, position)
        }
    }

    private fun removePreviousShortcuts() {
        for (viewId in ids) {
            val view: View = mainContainer.findViewById(viewId)
            mainContainer.removeView(view)
        }
    }

    fun setupErrorWithBackgroundCorner() {
        errorView.setupTryAgainErrorRoundedCorner()
    }

    private fun adjustViewLocation(view: View, leftId: Int, rightId: Int, topId: Int) {
        adjustMargins(view, leftId, topId)
        adjustConstraints(view, leftId, rightId, topId)
    }

    private fun adjustMargins(view: View, leftId: Int, topId: Int) {
        val leftMargin = (if (leftId == ConstraintSet.PARENT_ID) {
            0f
        } else {
            resources.getDimension(R.dimen.spacing_xs)
        }).toInt()

        val topMargin = (if (topId == shorcutLabelBarrier.id) {
            0f
        } else {
            resources.getDimension(R.dimen.spacing_xs)
        }).toInt()

        val lp = view.layoutParams as MarginLayoutParams
        lp.setMargins(leftMargin, topMargin, 0, 0)
        view.layoutParams = lp
    }

    private fun adjustConstraints(view: View, leftId: Int, rightId: Int, topId: Int) {

        val topConstraint = if (topId == ConstraintSet.PARENT_ID) {
            ConstraintSet.TOP
        } else {
            ConstraintSet.BOTTOM
        }

        val constraintSet = ConstraintSet()
        constraintSet.clone(mainContainer)
        constraintSet.connect(view.id, ConstraintSet.LEFT, leftId, ConstraintSet.LEFT)
        constraintSet.connect(view.id, ConstraintSet.RIGHT, rightId, ConstraintSet.RIGHT)
        constraintSet.connect(view.id, ConstraintSet.TOP, topId, topConstraint)
        constraintSet.constrainDefaultWidth(view.id, ConstraintSet.MATCH_CONSTRAINT_SPREAD)
        constraintSet.applyTo(mainContainer)
    }

    private fun addOnClickListener(view: View, position: Int) {
        view.onClick {
            onClickListener?.invoke(shortcuts[position])
        }
    }

    private fun configureShortcutGroupState(state: ViewState) {
        when (state) {
            ViewState.LOADING -> setLoadingState()
            ViewState.ERROR -> setErrorState()
            ViewState.LOADED -> setLoadedState()
        }
    }

    private fun setLoadedState() {
        errorContainer.visibility = View.GONE
        loadingContainer.visibility = View.GONE
        loadedContainer.visibility = View.VISIBLE
    }

    private fun setLoadingState() {
        errorContainer.visibility = View.GONE
        loadedContainer.visibility = View.GONE
        loadingContainer.visibility = View.VISIBLE
    }

    private fun setErrorState() {
        loadingContainer.visibility = View.GONE
        loadedContainer.visibility = View.GONE
        errorContainer.visibility = View.VISIBLE
    }

    private fun setShortcutTitle(shortcutText: String) {
        val expectedVisibility = if (shortcutText.isEmpty()) View.GONE else View.VISIBLE

        shortcutLabelTextView.apply {
            visibility = expectedVisibility
            text = shortcutText
        }

        shorcutLabelBarrier.visibility = expectedVisibility
    }

    private fun handleAttr(context: Context?, attrs: AttributeSet?) {
        if (attrs != null && context != null) {
            val array = context.obtainStyledAttributes(attrs, R.styleable.ShortcutGroup)
            shortcutLabel = array.getString(R.styleable.ShortcutGroup_shortcut_label) ?: EMPTY
            array.recycle()
        }
    }

    enum class ViewState {
        LOADED, LOADING, ERROR
    }
}