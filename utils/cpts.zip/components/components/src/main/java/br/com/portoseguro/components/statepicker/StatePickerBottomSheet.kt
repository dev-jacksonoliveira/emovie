package br.com.portoseguro.components.statepicker

import android.content.DialogInterface
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import br.com.portoseguro.components.R
import br.com.portoseguro.components.ui.BaseStaticBottomSheetDialogFragment
import br.com.portoseguro.superapp.core.infrastructure.extensions.bindBundle
import br.com.portoseguro.superapp.core.infrastructure.extensions.bindView

class StatePickerBottomSheet :
    BaseStaticBottomSheetDialogFragment(), StatePickerListener {

    private var listener: StatePickerListener? = null

    private val stateList by bindView<RecyclerView>(R.id.state_picker_recycler_view)

    private val useInitials: Boolean by bindBundle(USER_INITIALS)

    var dismissListener: (() -> Unit)? = null

    override fun getTheme(): Int = R.style.BottomSheetDialogRoundedWithVerticalAnimationTheme

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? =
        inflater.inflate(R.layout.fragment_state_picker_bottom_sheet_dialog, container, false)


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        context?.let {
            stateList.adapter = StatePickerAdapter(it, this, useInitials)
        }
    }

    override fun onStateClicked(fullName: String, initials: String) {
        this.dismiss()
        listener?.onStateClicked(fullName, initials)
    }

    override fun onDismiss(dialog: DialogInterface) {
        super.onDismiss(dialog)
        dismissListener?.invoke()
    }

    companion object {
        private const val USER_INITIALS = "USER_INITIALS"

        fun newInstance(useInitials: Boolean = false, listener: StatePickerListener) =
            StatePickerBottomSheet().apply {
                this.listener = listener
                arguments = Bundle().apply { putBoolean(USER_INITIALS, useInitials) }
            }
    }
}