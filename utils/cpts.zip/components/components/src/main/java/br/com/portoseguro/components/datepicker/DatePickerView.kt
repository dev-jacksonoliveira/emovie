package br.com.portoseguro.components.datepicker

import android.app.DatePickerDialog
import android.content.Context
import android.content.DialogInterface
import android.util.AttributeSet
import android.view.View
import android.view.ViewGroup
import android.widget.DatePicker
import android.widget.LinearLayout
import android.widget.TextView
import androidx.annotation.ColorRes
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.content.ContextCompat
import androidx.core.view.isVisible
import br.com.portoseguro.components.R
import br.com.portoseguro.components.toPx
import br.com.portoseguro.superapp.core.infrastructure.extensions.bindView
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class DatePickerView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleRes: Int = 0
) : ConstraintLayout(context, attrs, defStyleRes),
    DatePickerDialog.OnDateSetListener, DialogInterface.OnDismissListener {

    private var datePickerDialog: DatePickerDialog? = null
        get() {
            if (field == null) field = buildDatePickerDialog()
            return field
        }

    private var minDate: Long = NO_DATE_SET
    private var maxDate: Long = NO_DATE_SET

    private val clickableView: View by bindView(R.id.view_clickable)
    private val selectedDateInputLayout: TextInputLayout by bindView(R.id.input_layout_selected_date)
    private val selectedDateEditText: TextInputEditText by bindView(R.id.edit_text_selected_date)
    private val strokeColorView: View by bindView(R.id.stroke_view)
    private val errorMessageTextView: TextView by bindView(R.id.text_view_error_message)

    private var datePickerTitle: String? = null
    private var notIncludePastDates: Boolean = false
    private var onSelectedDateListener: (Calendar) -> Unit = {}

    init {
        LinearLayout.inflate(context, R.layout.view_date_picker_component, this)
        fillAttributes(attrs)
        setupListeners()
    }

    private fun fillAttributes(attrs: AttributeSet? = null) {
        if (attrs == null) return

        val attributes = context.obtainStyledAttributes(attrs, R.styleable.DatePickerView)
        attributes.getString(R.styleable.DatePickerView_datePickerView_hint)?.let {
            selectedDateEditText.hint = it
        }
        attributes.getString(R.styleable.DatePickerView_datePickerView_title)?.let {
            datePickerTitle = it
        }
        attributes.getDimensionPixelSize(
            R.styleable.DatePickerView_datePickerView_hintPadding,
            NO_HINT_PADDING_SET
        ).let {
            if (it != NO_HINT_PADDING_SET) selectedDateEditText.setPadding(it, it, it, it)
        }
        notIncludePastDates =
            attributes.getBoolean(
                R.styleable.DatePickerView_datePickerView_notIncludePastDates,
                false
            )
        attributes.recycle()
    }

    private fun setupListeners() {
        clickableView.setOnClickListener {
            showDatePicker()
        }
    }

    private fun showDatePicker() {
        configureDatePickerDialog()
        setFocus(true)
        datePickerDialog?.show()
    }

    private fun configureDatePickerDialog() {
        configureDateLimits()

        datePickerDialog?.setTitle(datePickerTitle)
        datePickerDialog?.setOnDismissListener(this)
    }

    private fun buildDatePickerDialog(): DatePickerDialog {
        val calendar = Calendar.getInstance()

        val year = calendar.get(Calendar.YEAR)
        val month = calendar.get(Calendar.MONTH)
        val day = calendar.get(Calendar.DAY_OF_MONTH)

        return DatePickerDialog(
            context,
            R.style.DatePickerViewStyle,
            this, year, month, day
        )
    }

    private fun configureDateLimits() {
        val nonNullDatePicker = datePickerDialog ?: return

        if (minDate != NO_DATE_SET) {
            nonNullDatePicker.datePicker.minDate = minDate
        } else if (notIncludePastDates) {
            nonNullDatePicker.datePicker.minDate = Calendar.getInstance().timeInMillis
        }

        if (maxDate != NO_DATE_SET) {
            nonNullDatePicker.datePicker.maxDate = maxDate
        }
    }

    private fun setFocus(isFocused: Boolean) {
        selectedDateEditText.isFocusableInTouchMode = isFocused
        if (isFocused) {
            selectedDateEditText.requestFocus()
            setStrokeState(StrokeState.Focused)
        } else {
            selectedDateEditText.clearFocus()
            setStrokeState(StrokeState.Default)
        }
    }

    private fun setStrokeState(state: StrokeState) {
        if (state != StrokeState.Error) {
            clearErrorMessage()
        }
        strokeColorView.setBackgroundColor(ContextCompat.getColor(context, state.strokeColor))
        val layoutParams = strokeColorView.layoutParams
        layoutParams.width = ViewGroup.LayoutParams.MATCH_PARENT
        layoutParams.height = state.strokeSize.toPx()
    }

    override fun onDateSet(view: DatePicker, year: Int, month: Int, dayOfMonth: Int) {
        val calendar = Calendar.getInstance().apply {
            set(year, month, dayOfMonth)
        }
        val simpleDateFormat = SimpleDateFormat(DATE_FORMAT, Locale.getDefault())
        val dateFormatted = simpleDateFormat.format(calendar.time)
        selectedDateEditText.setText(dateFormatted)
        onSelectedDateListener(calendar)
    }

    private fun clearErrorMessage() {
        errorMessageTextView.isVisible = false
    }

    fun clearDatePicker() {
        datePickerDialog = null
        selectedDateEditText.setText("")
    }

    fun setErrorMessage(errorMessage: String) {
        errorMessageTextView.isVisible = true
        errorMessageTextView.text = errorMessage
        setStrokeState(StrokeState.Error)
    }

    override fun onDismiss(dialog: DialogInterface) {
        selectedDateInputLayout.isFocusable = false
        setFocus(false)
    }

    fun setDateSelectedListener(onDateSelected: (Calendar) -> Unit) {
        onSelectedDateListener = onDateSelected
    }

    fun setMinDate(timeInMillis: Long) {
        minDate = timeInMillis
    }

    fun setMaxDate(timeInMillis: Long) {
        maxDate = timeInMillis
    }

    companion object {
        private sealed class StrokeState(@ColorRes val strokeColor: Int, val strokeSize: Int) {
            object Default : StrokeState(R.color.neutral_color_grey_03, STROKE_SIZE_DEFAULT)
            object Focused : StrokeState(R.color.brand_color_primary, STROKE_SIZE_OTHER)
            object Error : StrokeState(R.color.brand_support_01, STROKE_SIZE_OTHER)
        }

        private const val STROKE_SIZE_DEFAULT = 1
        private const val STROKE_SIZE_OTHER = 2
        private const val DATE_FORMAT = "dd/MM/yyyy"
        private const val NO_DATE_SET = -1L
        private const val NO_HINT_PADDING_SET = Int.MIN_VALUE
    }
}
