package br.com.portoseguro.components.ui

import android.os.Bundle
import android.os.PersistableBundle
import androidx.appcompat.app.AppCompatActivity
import br.com.portoseguro.components.R
import br.com.portoseguro.components.error.GenericErrorBottomSheetDialog
import br.com.portoseguro.components.error.GenericErrorType
import br.com.portoseguro.components.theme.InfoBottomSheetDialog
import br.com.portoseguro.superapp.core.infrastructure.exceptions.NoConnectivityException
import br.com.portoseguro.superapp.core.infrastructure.exceptions.NoInternetException

abstract class BaseActivity : AppCompatActivity() {

    var canMakeFragmentTransaction = false
    private set

    var genericErrorDialog: GenericErrorBottomSheetDialog? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        canMakeFragmentTransaction = true
    }

    override fun onPostCreate(savedInstanceState: Bundle?) {
        super.onPostCreate(savedInstanceState)
        canMakeFragmentTransaction = false
    }

    override fun onPostResume() {
        super.onPostResume()
        canMakeFragmentTransaction = true
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        canMakeFragmentTransaction = false
    }

    override fun onSaveInstanceState(outState: Bundle, outPersistentState: PersistableBundle) {
        super.onSaveInstanceState(outState, outPersistentState)
        canMakeFragmentTransaction = false
    }

    override fun onRestoreInstanceState(savedInstanceState: Bundle) {
        super.onRestoreInstanceState(savedInstanceState)
        canMakeFragmentTransaction = true
    }

    override fun onRestoreInstanceState(
        savedInstanceState: Bundle?,
        persistentState: PersistableBundle?
    ) {
        super.onRestoreInstanceState(savedInstanceState, persistentState)
        canMakeFragmentTransaction = true
    }

    /**
     * Method to show internet error or generic errors
     *
     * @param throwable to identify what error screen to show
     * @param genericErrorFunction in case of generic error,
     *  show default generic error screen, and call the function passed as parameter
     *  when user click on try again
     */
    open fun configureError(throwable: Throwable, genericErrorFunction: (() -> Unit)? = null) {
        if (!(throwable is NoConnectivityException || throwable is NoInternetException) &&
            genericErrorFunction != null
        ) {
            genericErrorFunction.invoke()
        } else {
            configureConnectionError()
        }
    }

    private fun configureConnectionError() {
        if (supportFragmentManager.findFragmentByTag(CONNECTION_ERROR_DIALOG) != null) {
            return
        }

        val connectionDialog = InfoBottomSheetDialog.newInstance()
        connectionDialog.setup(resources.getString(R.string.device_not_connected_title),
            resources.getString(R.string.device_not_connected_subtitle))
        connectionDialog.show(supportFragmentManager, CONNECTION_ERROR_DIALOG)

        genericErrorDialog?.setOnNoConnectionBaseBottomShow(resources.getString(R.string.device_not_connected_title))
    }

    fun showGenericErrorDialog(
        tryAgainListener: (() -> Unit)? = null,
        onCloseListener: (() -> Unit)? = null,
        onReturnListener: (() -> Unit)? = null,
        returnMessage: String? = null,
        currentStep: GenericErrorType? = null
    ) {

        if (genericErrorDialog == null || genericErrorDialog?.isVisible == false) {

            addGenericFragmentListener(tryAgainListener,
                onCloseListener,
                onReturnListener,
                returnMessage,
                currentStep
            )
            if (!isFinishing && canMakeFragmentTransaction) {
                val dialog = GenericErrorBottomSheetDialog()
                dialog.show(supportFragmentManager, GENERIC_ERROR_DIALOG_TAG)
            }
        }
    }

    private fun addGenericFragmentListener(
        tryAgainListener: (() -> Unit)?,
        onCloseListener: (() -> Unit)?,
        onReturnListener: (() -> Unit)?,
        returnMessage: String?,
        currentStep: GenericErrorType?
    ) {
        supportFragmentManager.addFragmentOnAttachListener { _, fragment ->
            if(fragment is GenericErrorBottomSheetDialog) {
                genericErrorDialog = fragment
                fragment.apply {
                    onReturnListener?.let { fragment.setOnReturnListener(it) }
                    returnMessage?.let { fragment.setReturnMessage(it) }
                    tryAgainListener?.let { fragment.setOnTryAgainListener(it) }
                    onCloseListener?.let { fragment.setOnCloseListener(it) }
                    currentStep?.let { fragment.setCurrentStep(it) }
                }
            }
        }
    }

    companion object {
        const val CONNECTION_ERROR_DIALOG = "connection_error_dialog"
        const val GENERIC_ERROR_DIALOG_TAG = "generic_error_dialog_tag"
    }
}