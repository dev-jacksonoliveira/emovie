package br.com.portoseguro.components.snackbar

import android.content.Context
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.core.content.ContextCompat
import androidx.core.view.setPadding
import androidx.core.view.updateLayoutParams
import br.com.portoseguro.components.R
import br.com.portoseguro.components.utils.ComponentsUtils
import com.google.android.material.snackbar.BaseTransientBottomBar
import com.google.android.material.snackbar.Snackbar

class CustomSnackBar(
    parent: ViewGroup,
    content: SnackBarView
) : BaseTransientBottomBar<CustomSnackBar>(parent, content, content) {

    init {
        getView().setBackgroundColor(
            ContextCompat.getColor(view.context, android.R.color.transparent)
        )
        getView().setPadding(0)
    }

    override fun show() {
        animationMode = ANIMATION_MODE_FADE
        super.show()
    }

    data class CustomSnackBarData(
        val view: View,
        val message: String,
        val gravity: Int,
    )

    companion object {
        private const val SNACK_BAR_FIVE_SECONDS = 5000
        private const val SNACK_BAR_THREE_SECONDS = 3000
        private const val TRANSLATION_Y = 16f

        fun showSuccessSnackBar(
            data: CustomSnackBarData,
            backgroundColor: Int = R.color.brand_support_03,
            textColor: Int = R.color.neutral_color_white,
            duration: Int = SNACK_BAR_THREE_SECONDS
        ) {
            make(data, backgroundColor, textColor, duration).show()
        }

        fun showErrorSnackBar(
            data: CustomSnackBarData,
            backgroundColor: Int = R.color.brand_support_01,
            textColor: Int = R.color.neutral_color_white,
            duration: Int = SNACK_BAR_FIVE_SECONDS
        ) {
            make(data, backgroundColor, textColor, duration).show()
        }

        fun showNeutralSnackBar(
            data: CustomSnackBarData,
            backgroundColor: Int = R.color.brand_support_09,
            textColor: Int = R.color.neutral_color_darkest,
            duration: Int = SNACK_BAR_THREE_SECONDS
        ) {
            make(data, backgroundColor, textColor, duration).show()
        }

        fun make(
            data: CustomSnackBarData,
            backgroundColor: Int,
            textColor: Int,
            duration: Int = Snackbar.LENGTH_SHORT
        ): CustomSnackBar {
            val parent = data.view.parent as ViewGroup

            val customView = LayoutInflater.from(data.view.context).inflate(
                R.layout.layout_custom_snackbar, parent, false
            ) as SnackBarView

            customView.setMessage(data.message)
            customView.setTextColor(textColor)
            customView.setBackgroundColor(
                ContextCompat.getColor(
                    customView.context,
                    backgroundColor
                )
            )

            val snackBar = CustomSnackBar(parent, customView)
            adjustSnackBarAnimation(data.view.context, snackBar, data.gravity)
            return snackBar.setDuration(duration)
        }

        private fun adjustSnackBarAnimation(
            context: Context,
            snackBar: CustomSnackBar,
            gravity: Int
        ) {
            val viewSnackBar = snackBar.view
            viewSnackBar.updateLayoutParams<FrameLayout.LayoutParams> {
                this.gravity = gravity
            }
            val translationValue = ComponentsUtils.convertDpToPixel(TRANSLATION_Y, context)
            viewSnackBar.animate().translationY(
                if (gravity == Gravity.TOP) {
                    translationValue
                }
                else {
                    -translationValue
                }
            )
        }
    }
}