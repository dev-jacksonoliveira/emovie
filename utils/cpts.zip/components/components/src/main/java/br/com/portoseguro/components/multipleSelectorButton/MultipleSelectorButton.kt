package br.com.portoseguro.components.multipleSelectorButton

import android.content.Context
import android.util.AttributeSet
import android.view.LayoutInflater
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.recyclerview.widget.GridLayoutManager
import br.com.portoseguro.components.R
import br.com.portoseguro.components.databinding.MultipleSelectorViewBinding
import br.com.portoseguro.components.multipleSelectorButton.adapter.MultipleSelectorAdapter
import br.com.portoseguro.components.multipleSelectorButton.model.MultipleSelectorButtonModel

class MultipleSelectorButton @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : ConstraintLayout(context, attrs, defStyleAttr) {

    private val binding = MultipleSelectorViewBinding
        .inflate(LayoutInflater.from(context), this, true)

    init {
        binding.recyclerViewMultipleSelector.addItemDecoration(
            GridSpacingItemDecoration(spacing = getDimensionPixelSize())
        )
    }

    fun initItems(
        selectorModelList: List<MultipleSelectorButtonModel>,
        onSelectedItemListener: (MultipleSelectorButtonModel) -> Unit
    ) {
        initView(selectorModelList, onSelectedItemListener)
    }

    private fun initView(
        selectorModelList: List<MultipleSelectorButtonModel>,
        onSelectedItemListener: (MultipleSelectorButtonModel) -> Unit
    ) {
        binding.recyclerViewMultipleSelector.adapter = MultipleSelectorAdapter(selectorModelList) {
            onSelectedItemListener.invoke(it)
        }
        if (selectorModelList.size >= SPAN_COUNT_3) {
            binding.recyclerViewMultipleSelector.layoutManager = GridLayoutManager(context, SPAN_COUNT_3)
        } else {
            binding.recyclerViewMultipleSelector.layoutManager = GridLayoutManager(context, SPAN_COUNT_2)
        }
    }

    private fun getDimensionPixelSize() =
        resources.getDimensionPixelSize(R.dimen.address_message_top_margin)

    companion object {
        private const val SPAN_COUNT_3 = 3
        private const val SPAN_COUNT_2 = 2
    }
}
