package br.com.portoseguro.components.shortcut

import android.content.Context
import android.util.AttributeSet
import android.view.View
import android.widget.TextView
import androidx.constraintlayout.widget.ConstraintLayout
import br.com.portoseguro.components.R
import br.com.portoseguro.components.setNodeInfoButton
import br.com.portoseguro.components.setUnformattedIcon
import br.com.portoseguro.superapp.core.infrastructure.extensions.bindView

/**
 * Botão para uso em um [ShortcutGroup]
 */
class ShortcutGroupButton @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : BaseShortcutButton(context, attrs, defStyleAttr) {

    private val mainContainer: ConstraintLayout by bindView(R.id.shortcut_group_button_main_container)
    private val iconTextView: TextView by bindView(R.id.shortcut_group_button_icon)
    private val descriptionTextView: TextView by bindView(R.id.shortcut_group_button_description)

    init {
        View.inflate(context, R.layout.shortcut_group_button, this)
    }

    override fun setShortcut(shortcut: Shortcut) {
        iconTextView.setUnformattedIcon(shortcut.icon)
        setupDescriptionAndAutoSize(descriptionTextView, shortcut.description.trim(), shortcut.type)
        mainContainer.contentDescription = retrieveContentDescriptionShortcut(shortcut)
        if(shortcut.type != ShortcutButtonType.COMING_SOON) {
            mainContainer.setNodeInfoButton()
        }
    }

    companion object {
        fun build(context: Context) = ShortcutGroupButton(context).apply { onFinishInflate() }
    }
}