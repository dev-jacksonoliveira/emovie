package br.com.portoseguro.components.statepicker

interface StatePickerListener {
    fun onStateClicked(fullName: String, initials: String)
}