package br.com.portoseguro.components.justificativebottomsheet

data class AssessmentData(var id: String, var description: String)