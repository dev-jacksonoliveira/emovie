package br.com.portoseguro.components.utils

import android.text.Editable
import android.widget.EditText

class CardFormatter(
    private val editText: EditText,
    private val onAfterTextChanged: ((String) -> Unit)? = null
) : BaseTextWatcher() {

    override fun afterTextChanged(text: Editable?) {
        editText.removeTextChangedListener(this)

        val newNumericValue = text.toString().filter { it.isDigit() }

        if (textIsTheSame(newNumericValue, text)) return

        val maskedValue = newNumericValue.foldIndexed(StringBuilder("")) { i, acc, char ->
            when (i) {
                INDEX_4, INDEX_10 -> {
                    acc.append(SEPARATOR + char)
                }
                INDEX_15 -> {
                    acc.append(char)
                    getDefaultCardFormatted(acc.toString().replace("\\s".toRegex(), ""))
                }
                else -> acc.append(char)
            }
        }

        text?.replace(0, text.length, maskedValue)
        onAfterTextChanged?.invoke(text.toString())
        editText.addTextChangedListener(this)
    }

    private fun getDefaultCardFormatted(cardValue: String): StringBuilder {
        val valueFormatted = StringBuilder()
        for ((index, charValue: Char) in cardValue.toCharArray().withIndex()) {
            if (index == INDEX_4 || index == INDEX_8 || index == INDEX_12) {
                valueFormatted.append(" $charValue")
            } else {
                valueFormatted.append(charValue)
            }
        }
        return valueFormatted
    }

    companion object {
        const val SEPARATOR = " "
        const val INDEX_4 = 4
        const val INDEX_10 = 10
        const val INDEX_8 = 8
        const val INDEX_12 = 12
        const val INDEX_15 = 15
    }
}