package br.com.portoseguro.components.statepicker

import android.view.View
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import br.com.portoseguro.components.R
import br.com.portoseguro.superapp.core.infrastructure.extensions.bindView
import br.com.portoseguro.superapp.core.infrastructure.extensions.onClick

class StatePickerViewHolder(
    view: View,
    private val listener: StatePickerListener
) : RecyclerView.ViewHolder(view) {

    private val stateText by bindView<TextView>(R.id.state_picker_item_text)

    fun bind(fullName: String, initial: String, withInitials: Boolean) {
        stateText.text = if (withInitials) initial else fullName
        stateText.onClick {
            listener.onStateClicked(fullName, initial)
        }
    }
}