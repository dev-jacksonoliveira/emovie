package br.com.portoseguro.components.snackbar

import android.content.Context
import android.util.AttributeSet
import android.view.View
import android.widget.FrameLayout
import android.widget.TextView
import androidx.annotation.ColorInt
import androidx.core.content.ContextCompat
import br.com.portoseguro.components.R
import br.com.portoseguro.superapp.core.infrastructure.extensions.bindView
import com.google.android.material.card.MaterialCardView
import com.google.android.material.snackbar.ContentViewCallback

class SnackBarView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : FrameLayout(context, attrs, defStyleAttr), ContentViewCallback {

    private val messageTextView: TextView by bindView(R.id.text_view_message)
    private val rootLayout: MaterialCardView by bindView(R.id.root_layout)

    init {
        View.inflate(context, R.layout.view_custom_snackbar, this)
    }

    fun setMessage(message: String) {
        messageTextView.text = message
    }

    fun setTextColor(color: Int) {
        messageTextView.setTextColor(ContextCompat.getColor(context, color))
    }

    override fun setBackgroundColor(@ColorInt color: Int) {
        rootLayout.setCardBackgroundColor(color)
    }

    override fun animateContentOut(delay: Int, duration: Int) { Unit }

    override fun animateContentIn(delay: Int, duration: Int) { Unit }
}