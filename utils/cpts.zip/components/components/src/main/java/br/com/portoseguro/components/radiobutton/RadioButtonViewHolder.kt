package br.com.portoseguro.components.radiobutton

import android.view.View
import android.widget.CheckBox
import android.widget.TextView
import androidx.core.view.isVisible
import androidx.recyclerview.widget.RecyclerView
import br.com.portoseguro.components.R
import br.com.portoseguro.superapp.core.infrastructure.extensions.bindView

class RadioButtonViewHolder(
    itemView: View,
    private val onClickListener: (item: RadioItem) -> Unit
) : RecyclerView.ViewHolder(itemView) {

    private val label by bindView<TextView>(R.id.radio_button_label)
    private val checkBox by bindView<CheckBox>(R.id.radio_button_checkbox)
    private val icon by bindView<TextView>(R.id.radio_button_icon)

    fun bind(item: RadioItem) {
        label.text = item.label

        checkBox.isChecked = item.checked

        item.icon?.let {
            icon.isVisible = true
            icon.text = it
        }

        itemView.run {
            isEnabled = !item.disabled
            isSelected = item.checked

            setOnClickListener {
                onClickListener.invoke(item)
            }
        }

        setupAccessibility()
    }

    private fun setupAccessibility() =
        itemView.run {
            contentDescription = label.text

            if (checkBox.isChecked.not()) {
                contentDescription = context.getString(
                    R.string.checkbox_circular_accessibility,
                    context.getString(R.string.not_selected),
                    label.text
                )
            }
        }
}