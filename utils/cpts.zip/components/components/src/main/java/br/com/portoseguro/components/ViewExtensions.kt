package br.com.portoseguro.components

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.view.View
import android.view.ViewGroup
import android.view.accessibility.AccessibilityNodeInfo
import android.view.animation.Animation
import android.view.animation.Transformation
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import androidx.core.content.ContextCompat
import androidx.core.view.AccessibilityDelegateCompat
import androidx.core.view.ViewCompat
import androidx.core.view.accessibility.AccessibilityNodeInfoCompat

internal const val ALPHA_TRANSPARENT = 0f
private const val ALPHA_OPACITY = 1f
internal const val DEFAULT_ANIMATION_DURATION = 300L

/**
 * Método para fazer animação de expandir (Ex. ao expandir um card -> expandableCardView)
 */
fun View.expandEffect(): Animation {
    val view = this

    view.measure(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
    val targetHeight = view.measuredHeight
    val finalHeight = ViewGroup.LayoutParams.WRAP_CONTENT

    view.visibility = View.VISIBLE
    val animation = object : Animation() {
        override fun applyTransformation(interpolatedTime: Float, t: Transformation) {
            view.layoutParams.height = if (interpolatedTime == 1f) {
                finalHeight
            } else {
                (targetHeight * interpolatedTime).toInt()
            }
            view.requestLayout()
        }

        override fun willChangeBounds(): Boolean {
            return true
        }
    }

    animation.duration = resources.getInteger(R.integer.config_longAnimTime).toLong()
    return animation
}

/**
 * Método para fazer animação de collpase (Ex. ao retrair um card -> expandableCardView)
 */
fun View.collapseEffect(): Animation {
    val view = this
    val initialHeight = view.measuredHeight

    val animation = object : Animation() {
        override fun applyTransformation(interpolatedTime: Float, t: Transformation) {
            if (interpolatedTime == 1f) {
                view.visibility = View.GONE
            } else {
                view.layoutParams.height =
                    initialHeight - (initialHeight * interpolatedTime).toInt()
                view.requestLayout()
            }
        }

        override fun willChangeBounds(): Boolean {
            return true
        }
    }
    animation.duration = resources.getInteger(R.integer.config_longAnimTime).toLong()
    return animation
}

/**
 * Metodo para adicionar leitura de área clicável na acessibilidade da view.
 * Ex toque duas vezes para ativar..
 * @param actionDescription uma descrição customizada. Ex. abrir (toque duas vezes para abrir)
 * @param readButton padrão true, para fazer a leitura "botao"
 */
fun View.setNodeInfoButton(actionDescription: String? = null, readButton: Boolean = true) {
    ViewCompat.setAccessibilityDelegate(this, object : AccessibilityDelegateCompat() {

        override fun onInitializeAccessibilityNodeInfo(
            host: View?,
            info: AccessibilityNodeInfoCompat
        ) {
            super.onInitializeAccessibilityNodeInfo(host, info)

            if (readButton) {
                info.className = Button::class.java.name
            }

            if (actionDescription.isNullOrEmpty()) {
                info.addAction(AccessibilityNodeInfoCompat.ACTION_CLICK)
            } else {
                info.addAction(
                    AccessibilityNodeInfoCompat.AccessibilityActionCompat(
                        AccessibilityNodeInfo.ACTION_CLICK,
                        actionDescription
                    )
                )
            }
        }
    })
}

/**
 * Metodo para remover leitura de click da acessibilidade da view
 */
fun View.removeNodeInfoButton() {
    ViewCompat.setAccessibilityDelegate(this, object : AccessibilityDelegateCompat() {

        override fun onInitializeAccessibilityNodeInfo(
            host: View?,
            info: AccessibilityNodeInfoCompat
        ) {
            super.onInitializeAccessibilityNodeInfo(host, info)

            info.isClickable = false
            info.removeAction(AccessibilityNodeInfoCompat.AccessibilityActionCompat.ACTION_CLICK)
        }
    })
}

/**
 * Fazer animação de fade in da view
 * @param duration duração total da animação (Se nao informado duração padrao de 300ms)
 */
fun View.fadeIn(duration: Long = DEFAULT_ANIMATION_DURATION) {
    val view = this
    view.apply {
        // Set the content view to 0% opacity but visible, so that it is visible
        // (but fully transparent) during the animation.
        alpha = ALPHA_TRANSPARENT
        visibility = View.VISIBLE

        // Animate the content view to 100% opacity, and clear any animation
        // listener set on the view.
        animate()
            .alpha(ALPHA_OPACITY)
            .setDuration(duration)
            .setListener(null)
    }
}

/**
 * Fazer animação de fade out da view
 * @param duration duração total da animação (Se nao informado duração padrao de 300ms)
 */
fun View.fadeOut(duration: Long = DEFAULT_ANIMATION_DURATION) {
    val view = this
    // Animate the loading view to 0% opacity. After the animation ends,
    // set its visibility to GONE as an optimization step (it won't
    // participate in layout passes, etc.)
    view.animate()
        .alpha(ALPHA_TRANSPARENT)
        .setDuration(duration)
        .setListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: Animator) {
                view.visibility = View.GONE
            }
        })
}

fun View.setHeaderAccessibility(isHeading: Boolean = true) {
    ViewCompat.setAccessibilityDelegate(this, object : AccessibilityDelegateCompat() {
        override fun onInitializeAccessibilityNodeInfo(
            host: View, info: AccessibilityNodeInfoCompat
        ) {
            super.onInitializeAccessibilityNodeInfo(host, info)
            info.isHeading = isHeading
        }
    })
}

fun View.hideKeyboard() {
    val inputMethodManager = ContextCompat.getSystemService(context, InputMethodManager::class.java)
    inputMethodManager?.hideSoftInputFromWindow(windowToken, 0)
}

/**
 * Coloca a view em um estado "não clicável", logo após o click, por um tempo. Pra evitar duplos cliques acidentais
 * @param delay tempo, em millisegundos, que a view não será clicável (Se nao informado duração padrao de 500ms)
 */
inline fun View.setOnThrottledClick(
    delay: Long = 500L,
    crossinline onClick: (View) -> Unit
) {
    setOnClickListener {
        it.isClickable = false
        onClick(this)
        postDelayed({ it.isClickable = true }, delay)
    }
}
