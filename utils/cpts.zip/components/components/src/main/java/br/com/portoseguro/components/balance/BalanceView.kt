package br.com.portoseguro.components.balance

import android.content.Context
import android.util.AttributeSet
import android.view.LayoutInflater
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.view.isVisible
import br.com.portoseguro.components.R
import br.com.portoseguro.components.databinding.BalanceViewBinding
import br.com.portoseguro.components.errorpartial.ErrorPartialSetup
import br.com.portoseguro.components.errorpartial.ErrorPartialView
import br.com.portoseguro.components.theme.ButtonLoading

class BalanceView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleRes: Int = 0
) : ConstraintLayout(context, attrs, defStyleRes), ErrorPartialView.ErrorListener {

    private val binding = BalanceViewBinding.inflate(LayoutInflater.from(context), this, true)

    private var formattedBalance = ""
    var toggleListener: (() -> Unit)? = null
    var tryAgainListener: (() -> Unit)? = null
    var analyticsListener: ((isShowing: Boolean) -> Unit)? = null
    private var isShowingObserver = true
    var isShowing = true
        set(value) {
            if (value) hideBalance() else showBalance()
            field = if (toggleListener == null) !value else field
        }

    var isShowPartialErrorLoading = false

    var isError = false
        set(value) {
            if (value) showError(isShowPartialErrorLoading) else hideError()
            field = value
        }

    init {
        setupListeners()
        setupError()
    }

    fun clearAnalyticsListener() {
        analyticsListener = null
    }

    fun setBalance(formattedBalance: String) {
        this.formattedBalance = formattedBalance
        binding.balanceContainer.balanceTextView.text = formattedBalance
    }

    fun setLoading(isLoading: Boolean) {
        if (isLoading) showLoading() else hideLoading()
    }

    fun setContainerVisibility(isVisible: Boolean) {
        binding.balanceContainer.root.isVisible = isVisible
    }

    fun showLoading() {
        binding.shimmerView.root.isVisible = true
        setContainerVisibility(false)
        hideError()
    }

    fun hideLoading() {
        binding.shimmerView.root.isVisible = false
    }

    override fun tryAgainAction() {
        tryAgainListener?.invoke()
    }

    override fun expiredAttemptAction() {
        // do nothing
    }

    fun setTryAgainVisibility(hasTryAgain: Boolean) {
        binding.errorView.findViewById<ButtonLoading>(R.id.error_partial_button).isVisible = hasTryAgain
    }

    private fun setupListeners() = with(binding.balanceContainer) {
        visibleImageView.setOnClickListener {
            toggleListener?.invoke()
            analyticsListener?.invoke(isShowingObserver)
        }

        balanceTextView.setOnClickListener {
            toggleListener?.invoke()
            analyticsListener?.invoke(isShowingObserver)
        }
    }

    private fun showBalance() = with(binding.balanceContainer) {
        visibleImageView.setImageResource(R.drawable.ic_eye_closed)
        balanceTextView.text = formattedBalance
        isShowingObserver = true
    }

    private fun hideBalance() = with(binding.balanceContainer) {
        visibleImageView.setImageResource(R.drawable.ic_eye_open)
        balanceTextView.setText(R.string.balance_hidden_value)
        isShowingObserver = false
    }

    private fun setupError() {
        binding.errorView.setup(getErrorPartialSetup())
    }

    private fun getErrorPartialSetup(): ErrorPartialSetup {
        val message = context.getString(R.string.balance_view_error_message)
        val buttonText = context.getString(R.string.update)
        val icon = context.getString(R.string.icon_ea77)
        return ErrorPartialSetup(
            icon = icon,
            errorListener = this,
            attemptNumber = RETRY_ATTEMPT_COUNT,
            message = message,
            lastMessage = message,
            firstTextButton = buttonText,
            lastTextButton = buttonText
        )
    }

    private fun hideError() {
        binding.errorView.isVisible = false
    }

    private fun showError(isLoading: Boolean) {
        binding.errorView.loading(isLoading)
        binding.errorView.isVisible = true
        hideLoading()
        setContainerVisibility(false)
    }

    companion object {

        private const val RETRY_ATTEMPT_COUNT = 3
    }
}