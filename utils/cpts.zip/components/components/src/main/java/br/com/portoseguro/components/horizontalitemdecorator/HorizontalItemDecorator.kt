package br.com.portoseguro.components.horizontalitemdecorator

import android.graphics.Rect
import android.view.View
import androidx.recyclerview.widget.RecyclerView

class HorizontalItemDecorator(
    private val sideMarginSpace: Int,
    private val defaultSpace: Int,
    private val firstPosition: Int,
    private val lastPosition: Int
) : RecyclerView.ItemDecoration() {

    override fun getItemOffsets(
        outRect: Rect,
        view: View,
        parent: RecyclerView,
        state: RecyclerView.State
    ) {
        when (parent.getChildAdapterPosition(view)) {
            firstPosition -> {
                outRect.left = sideMarginSpace
            }
            lastPosition -> {
                outRect.right = sideMarginSpace
            }
            else -> {
                outRect.left = defaultSpace
            }
        }
    }
}