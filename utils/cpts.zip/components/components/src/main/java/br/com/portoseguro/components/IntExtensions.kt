package br.com.portoseguro.components

import android.content.res.Resources

/**
 * Get the pixel number from integer
 * @return integer value of pixel
 */
fun Int.toPx(): Int =
    (this * Resources.getSystem().displayMetrics.density).toInt()