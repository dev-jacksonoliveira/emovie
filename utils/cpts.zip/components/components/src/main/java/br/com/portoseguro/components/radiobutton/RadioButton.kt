package br.com.portoseguro.components.radiobutton

import android.content.Context
import android.graphics.Rect
import android.util.AttributeSet
import android.view.View
import android.widget.FrameLayout
import androidx.recyclerview.widget.RecyclerView
import br.com.portoseguro.components.R
import br.com.portoseguro.superapp.core.infrastructure.extensions.bindView

typealias RadioButtonCallback = (RadioItem) -> Unit

class RadioButton @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : FrameLayout(context, attrs, defStyleAttr) {

    private var callback: RadioButtonCallback? = null

    private val radioGroupRecycler by bindView<RecyclerView>(R.id.radio_group)

    private var hasBackground = false
    private var selectorEnable = false
    private var selectionHighlight = false

    init {
        inflate(context, R.layout.radio_button, this)
        attrs?.let { setupView(attrs) }
        radioGroupRecycler.adapter =
            RadioButtonAdapter(
                hasBackground = hasBackground,
                hasSelector = selectorEnable,
                highlightSelection = selectionHighlight
            ) { itemSelected ->
                (radioGroupRecycler.adapter as RadioButtonAdapter).checkItem(itemSelected)
                callback?.invoke(itemSelected)
            }.apply {
                setHasStableIds(true)
            }
        radioGroupRecycler.addItemDecoration(RadioButtonDecorator())
    }

    private fun setupView(attrs: AttributeSet) {
        val attributes = context.obtainStyledAttributes(attrs, R.styleable.RadioButton)
        hasBackground = attributes.getBoolean(R.styleable.RadioButton_hasBackground, false)
        selectorEnable = attributes.getBoolean(R.styleable.RadioButton_selectorIndicator, false)
        selectionHighlight =
            attributes.getBoolean(R.styleable.RadioButton_selectionHighlight, false)

        attributes.recycle()
    }

    /**
     * Configura os Radio Buttons
     *
     * @param items lista com os botões que devem ser apresentados
     */
    fun setRadioItems(items: List<RadioItem>) {
        (radioGroupRecycler.adapter as RadioButtonAdapter).apply {
            this.items = items
            notifyDataSetChanged()
        }
    }

    /**
     * Configura callback para click do botão
     *
     * @param callback função a ser chamada quando item for clicado.
     */
    fun onRadioItemChecked(callback: RadioButtonCallback) {
        this.callback = callback
    }

    /**
     * Procura item selecionado do RadioGroup
     *
     * @return retorna o item selecionado ou nulo se não houver nenhum
     */
    fun getSelectedItem(): RadioItem? =
        (radioGroupRecycler.adapter as RadioButtonAdapter).items.firstOrNull { it.checked }

    fun checkItem (item: RadioItem) {
        (radioGroupRecycler.adapter as RadioButtonAdapter).checkItem(item)
    }

    fun getSelectedItemLabel() = getSelectedItem()?.label?.toString().orEmpty()

    private inner class RadioButtonDecorator : RecyclerView.ItemDecoration() {

        override fun getItemOffsets(
            outRect: Rect,
            view: View,
            parent: RecyclerView,
            state: RecyclerView.State
        ) {
            val position = parent.getChildAdapterPosition(view)
            if (position != parent.adapter?.itemCount?.minus(1)) {
                outRect.bottom = context.resources.getDimension(R.dimen.spacing_xs).toInt()
            }
        }
    }
}
