package br.com.portoseguro.components

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Typeface
import android.text.SpannableString
import android.text.Spanned
import android.text.style.TextAppearanceSpan
import androidx.annotation.ColorInt
import androidx.annotation.StyleRes
import java.text.Normalizer

private const val ONLY_NUMBER_AND_LETTERS_REGEX = "[^A-Za-z0-9 ]"
private const val UNACCENT_REGEX = "\\p{InCombiningDiacriticalMarks}+"
private const val OPEN_SANS_BOLD_STYLE = "open_sans_bold"

fun CharSequence.removeSpecialCharacters(): String {
    val regex = UNACCENT_REGEX.toRegex()
    val text = Normalizer.normalize(this, Normalizer.Form.NFD)
    val regexOnlyNumberAndLetters = Regex(ONLY_NUMBER_AND_LETTERS_REGEX)
    val finalText = regexOnlyNumberAndLetters.replace(text, "")
    return regex.replace(finalText, "")
}

/**
 * Procura pelo texto desejado e o coloca em negrito.
 * @param textToBeBold Texto a ser tratado em negrito.
 * @param color Cor para o negrito.
 * @param style Style para o formatação do texto.
 * @param context Context corrente.
 * @return Este texto com o trecho desejado em negrito.
 */
fun CharSequence.withBoldText(
    textToBeBold: String?,
    @ColorInt color: Int? = null,
    context: Context? = null,
    @StyleRes appearance: Int? = null
): CharSequence {
    val spannableString = SpannableString(this)

    if (!textToBeBold.isNullOrBlank()) {
        val start = indexOf(textToBeBold)
        if (start != -1) {
            val end = start + textToBeBold.length
            val colorState = color?.let {
                ColorStateList.valueOf(color)
            }
            val tf = if (appearance != null && context != null) {
                TextAppearanceSpan(context, appearance)
            } else {
                TextAppearanceSpan(OPEN_SANS_BOLD_STYLE, Typeface.BOLD, 0, colorState, null)
            }

            spannableString.setSpan(
                tf, start, end, Spanned.SPAN_INCLUSIVE_INCLUSIVE
            )
        }
    }

    return spannableString
}
