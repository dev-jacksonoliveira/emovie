package br.com.portoseguro.components.comingsoonview

import android.content.Context
import android.util.AttributeSet
import android.view.LayoutInflater
import androidx.constraintlayout.widget.ConstraintLayout
import br.com.portoseguro.components.R
import br.com.portoseguro.components.databinding.ComingSoonViewBinding
import br.com.portoseguro.components.error.ErrorInformation
import br.com.portoseguro.components.error.ErrorViewType
import br.com.portoseguro.components.labelmessage.LabelMessage
import br.com.portoseguro.components.labelmessage.LabelMessageType

class ComingSoonView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleRes: Int = 0
) : ConstraintLayout(context, attrs, defStyleRes) {
    private val binding: ComingSoonViewBinding =
        ComingSoonViewBinding.inflate(LayoutInflater.from(context), this, true)

    init {
        applyCustomAttributes(context, attrs)
    }

    private fun applyCustomAttributes(context: Context, attrs: AttributeSet?) {
        val typedArray =
            context.theme.obtainStyledAttributes(attrs, R.styleable.ComingSoonView, 0, 0)
        try {
            val icon =
                typedArray.getString(R.styleable.ComingSoonView_comingSoonView_icon).orEmpty()
            val title =
                typedArray.getString(R.styleable.ComingSoonView_comingSoonView_title).orEmpty()
            val labelMessageIcon =
                typedArray.getString(R.styleable.ComingSoonView_comingSoonView_labelMessage_icon)
                    .orEmpty()
            val labelMessageTitle =
                typedArray.getString(R.styleable.ComingSoonView_comingSoonView_labelMessage_title)
                    .orEmpty()
            val labelMessage = LabelMessage(
                LabelMessageType.INFORMATION,
                labelMessageIcon,
                "",
                labelMessageTitle
            )
            val errorMessage =
                typedArray.getString(R.styleable.ComingSoonView_comingSoonView_errorView_message)
                    .orEmpty()
            val errorInformation = ErrorInformation(
                ErrorViewType.VIEW_WITHOUT_TRY_AGAIN,
                errorMessage
            )
            setIcon(icon)
            setTitle(title)
            setLabelMessageView(labelMessage)
            setErrorView(errorInformation)
        } finally {
            typedArray.recycle()
        }

    }

    fun setIcon(icon: String) {
        binding.textViewIcon.text = icon
    }

    fun setTitle(title: String) {
        binding.textViewTitle.text = title
    }

    fun setLabelMessageView(labelMessage: LabelMessage) {
        binding.labelMessageDescription.setup(labelMessage)
    }

    fun setErrorView(errorInformation: ErrorInformation) {
        binding.errorView.setup(errorInformation)
    }

    fun getTitle(): String = binding.textViewTitle.text.toString()

}