package br.com.portoseguro.components.loading

import android.content.Context
import android.util.AttributeSet
import android.widget.LinearLayout
import br.com.portoseguro.components.R
import br.com.portoseguro.components.R.layout
import com.airbnb.lottie.LottieDrawable
import kotlinx.android.synthetic.main.view_loading.view.*

class LoadingView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : LinearLayout(context, attrs) {

    init {
        inflate(context, layout.view_loading, this)

        attrs?.let {
            val attributes = context.obtainStyledAttributes(attrs, R.styleable.LoadingView)
            var attrsRepeat = attributes.getBoolean(R.styleable.LoadingView_lottie_loop, true)
            attributes.recycle()
            config(attrsRepeat)
        }

    }

    private fun config(repeat: Boolean){
        animationView.setAnimation(R.raw.loading_default)
        if(repeat) {
            animationView.repeatCount = LottieDrawable.INFINITE
        }
    }

    fun start() {
        animationView.playAnimation()
    }

    fun resume() {
        animationView.resumeAnimation()
    }

    fun pause() {
        animationView.pauseAnimation()
    }

    fun reverse() {
        animationView.reverseAnimationSpeed()

        if(!isRunning()){
            this.start()
        }
    }

    fun stop() {
        animationView.setProgress(0F)
        animationView.cancelAnimation()
    }

    fun isRunning() = animationView.isAnimating
}