package br.com.portoseguro.components.genericimagebutton

import android.content.Context
import android.util.AttributeSet
import android.util.TypedValue
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.TextView
import androidx.appcompat.content.res.AppCompatResources
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.view.isVisible
import br.com.portoseguro.components.R
import br.com.portoseguro.superapp.core.infrastructure.extensions.bindView
import com.airbnb.lottie.LottieAnimationView

class GenericImageButton @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : FrameLayout(context, attrs, defStyleAttr) {

    private val loadingView: LottieAnimationView by bindView(R.id.generic_loading_button_image)
    private val genericButton: Button by bindView(R.id.generic_image_button)
    private val genericIconButton: TextView by bindView(R.id.generic_image_button_icon)
    private val genericTextButton: TextView by bindView(R.id.generic_image_button_text)
    private val genericImageButtonContainer: ConstraintLayout by bindView(R.id.generic_image_button_container)

    private lateinit var buttonText: CharSequence
    private var accessibilityText: String? = null

    var buttonEnabled: Boolean
    get() = genericButton.isEnabled
    set(value) {
        genericButton.isEnabled = value
    }

    var clickAction: (() -> Unit)? = null
        set(value) {
            field = value
            genericButton.setOnClickListener { value?.invoke() }
        }

    init {
        View.inflate(context, R.layout.generic_image_button_layout, this)
        attrs?.let { setupView(attrs) }
    }

    private fun setupView(attrs: AttributeSet) {
        val attributes = context.obtainStyledAttributes(attrs, R.styleable.GenericImageButton)

        val textColor = attributes.getColor(
            R.styleable.GenericImageButton_generic_image_button_text_color,
            resources.getColor(R.color.brand_color_primary, null)
        )

        buttonText = attributes.getText(
            R.styleable.GenericImageButton_generic_image_button_text
        )

        val animation = attributes.getResourceId(
            R.styleable.GenericImageButton_generic_button_animation_loading,
            R.raw.white_loading_button_animation
        )

        val backgroundResource =
            attributes.getDrawable(R.styleable.GenericImageButton_generic_image_button_background_drawable)

        val buttonIcon =
            attributes.getText(
                R.styleable.GenericImageButton_generic_image_button_image
            )

        val fontSize =
            attributes.getDimensionPixelSize(R.styleable.GenericImageButton_generic_image_button_text_size, NO_SIZE_PASSED)

        genericButton.apply {
            background = backgroundResource
        }

        genericTextButton.apply {
            text = buttonText
            setTextColor(textColor)
        }

        genericIconButton.apply {
            text = buttonIcon
            setTextColor(textColor)
        }

        if (!isInEditMode) {
            loadingView.setAnimation(animation)
        }

        setupTextSize(fontSize)

        attributes.recycle()
    }

    fun setInformativeButton(contentDescription: String) {
        accessibilityText = contentDescription
        genericButton.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
        genericButton.contentDescription = ""
        genericImageButtonContainer.contentDescription = accessibilityText
        genericImageButtonContainer.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_YES
    }

    fun setAccessibilityButton(contentDescription: String) {
        accessibilityText = contentDescription
        genericImageButtonContainer.contentDescription = ""
        genericImageButtonContainer.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO

        genericButton.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_YES
        genericButton.contentDescription = accessibilityText

    }

    fun setText(text: String) {
        buttonText = text
        genericTextButton.text = buttonText
    }

    fun setIcon(icon: String) {
        genericIconButton.text = icon
    }

    fun setTextColor(resourceColor: Int) {
        genericTextButton.setTextColor(resources.getColor(resourceColor, null))
    }

    fun setIconColor(resourceColor: Int) {
        genericIconButton.setTextColor(resources.getColor(resourceColor, null))
    }

    fun setButtonBackground(resourceBackground: Int) {
        genericButton.background = AppCompatResources.getDrawable(context, resourceBackground)
    }

    fun setLoading(enable: Boolean) {
        if (enable) {
            loadingView.isVisible = true
            genericTextButton.isVisible = false
            genericIconButton.isVisible = false
            genericButton.isEnabled = false
            genericButton.contentDescription = resources.getString(R.string.loading)
        } else {
            loadingView.isVisible = false
            genericButton.isEnabled = true
            genericTextButton.isVisible = true
            genericIconButton.isVisible = true
            genericButton.contentDescription = if (accessibilityText.isNullOrEmpty()) {
                buttonText
            } else {
                accessibilityText
            }
        }
    }

    fun getButtonText(): CharSequence = buttonText

    private fun setupTextSize(textSize: Int) {
        if (textSize != NO_SIZE_PASSED) {
            genericTextButton.setTextSize(TypedValue.COMPLEX_UNIT_PX, textSize.toFloat())
        }
    }

    companion object {
        private const val NO_SIZE_PASSED = 0
    }
}