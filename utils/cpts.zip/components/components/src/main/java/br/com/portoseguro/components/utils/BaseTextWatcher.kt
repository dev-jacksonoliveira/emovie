package br.com.portoseguro.components.utils

import android.text.Editable
import android.text.TextWatcher

open class BaseTextWatcher : TextWatcher {
    var currentNumericValue: String? = ""
    var currentStringSize: Int? = 0

    override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
        currentNumericValue = s?.toString()?.filter { it.isDigit() }
        currentStringSize = s?.length
    }

    override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
        // do nothing
    }
    override fun afterTextChanged(p0: Editable?) {
        // do nothing
    }

    fun textIsTheSame(newNumericValue: String, text: Editable?) =
        currentNumericValue == newNumericValue && currentStringSize == text?.length
}