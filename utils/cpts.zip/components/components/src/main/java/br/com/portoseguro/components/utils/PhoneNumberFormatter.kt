package br.com.portoseguro.components.utils

import android.text.Editable

/**
 * This class is a telephone number formatter that applies a mask to BR phones, new and old format.
 * Example: (##) ####-#### , (##) #####-####
 */

class PhoneNumberFormatter(
    private val onAfterTextChanged: ((String) -> Unit)? = null
) : BaseTextWatcher() {

    companion object {
        const val MAX_LENGTH = 11
        const val CLOSE_BRACKETS_WITH_SPACE = ") "
        const val SEPARATOR = "-"
        const val INDEX_BEFORE_CLOSE_BRACKETS = 2
        const val INDEX_BEFORE_SEPARATOR_OLD = 6
        const val INDEX_BEFORE_SEPARATOR_NEW = 7
    }

    override fun afterTextChanged(text: Editable?) {
        val newValue = text.toString().filter { it.isDigit() }

        if (textIsTheSame(newValue, text)) return

        if (newValue.isEmpty()) {
            text?.clear()
            return
        }

        val indexBeforeSeparator =
            if (newValue.length == MAX_LENGTH) INDEX_BEFORE_SEPARATOR_NEW else INDEX_BEFORE_SEPARATOR_OLD

        val masked = newValue.foldIndexed(StringBuilder("(")) { i, acc, char ->
            when (i) {
                INDEX_BEFORE_CLOSE_BRACKETS -> {
                    acc.append(CLOSE_BRACKETS_WITH_SPACE + char)
                }
                indexBeforeSeparator -> {
                    acc.append(SEPARATOR + char)
                }
                MAX_LENGTH -> acc
                else -> acc.append(char)
            }
        }

        text?.replace(0, text.length, masked)
        onAfterTextChanged?.invoke(text.toString())
    }
}