package br.com.portoseguro.components.di

import br.com.portoseguro.components.form.viewmodel.FormViewModel
import br.com.portoseguro.components.genericwebview.GenericWebViewViewModel
import br.com.portoseguro.components.phones.activity.PhoneViewModel
import br.com.portoseguro.components.phones.adapter.PhoneModelFactory
import br.com.portoseguro.components.phones.adapter.PhoneModelFactoryDefault
import br.com.portoseguro.components.tutorial.TutorialViewModel
import br.com.portoseguro.components.ui.BaseBottomSheetDialogViewModel
import br.com.portoseguro.components.utils.RedirectUtil
import org.koin.androidx.viewmodel.dsl.viewModel
import org.koin.dsl.module

val componentModules = module {
    viewModel { BaseBottomSheetDialogViewModel(get()) }
    viewModel { GenericWebViewViewModel(get()) }
    viewModel { TutorialViewModel(get()) }
    viewModel { FormViewModel(get()) }
    viewModel { PhoneViewModel(get()) }
    factory { RedirectUtil() }
    factory<PhoneModelFactory> { PhoneModelFactoryDefault(get()) }
}