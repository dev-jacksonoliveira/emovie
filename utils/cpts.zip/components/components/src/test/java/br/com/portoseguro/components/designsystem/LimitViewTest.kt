package br.com.portoseguro.components.designsystem

import android.content.Context
import android.content.res.ColorStateList
import android.os.Build
import android.view.View
import androidx.core.content.ContextCompat
import androidx.test.platform.app.InstrumentationRegistry
import br.com.portoseguro.components.R
import kotlinx.android.synthetic.main.error_view_with_try_again.view.errorButton
import kotlinx.android.synthetic.main.limit_view.view.limit_error
import kotlinx.android.synthetic.main.limit_view.view.limit_loading
import kotlinx.android.synthetic.main.limit_view_loaded.view.adjust_limit_group
import kotlinx.android.synthetic.main.limit_view_loaded.view.adjust_your_limit_text
import kotlinx.android.synthetic.main.limit_view_loaded.view.limit_available_value
import kotlinx.android.synthetic.main.limit_view_loaded.view.limit_progress_bar
import kotlinx.android.synthetic.main.limit_view_loaded.view.limit_total_value
import kotlinx.android.synthetic.main.limit_view_loaded.view.limit_used_value
import kotlinx.android.synthetic.main.limit_view_loaded.view.limit_view_group
import org.junit.Assert.assertEquals
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [Build.VERSION_CODES.P], qualifiers = "br")
class LimitViewTest {

    private val context: Context = InstrumentationRegistry.getInstrumentation().targetContext.applicationContext

    private lateinit var limitView: LimitView

    @Before
    fun setup() {
        limitView = LimitView.build(context)
    }

    @Test
    fun onInit_shouldHaveAllEmptyViews() {
        // ASSERT
        assertEquals(LimitView.State.LOADED, limitView.state)

        assertEquals(null, limitView.tryAgainAction)

        assertEquals("R$ 0,00", limitView.limit_total_value.text.toString())
        assertEquals("R$ 0,00", limitView.limit_used_value.text.toString())
        assertEquals("R$ 0,00", limitView.limit_available_value.text.toString())

        assertEquals(0, limitView.limit_progress_bar.progress)

        assertEquals(View.VISIBLE, limitView.limit_view_group.visibility)
        assertEquals(View.VISIBLE, limitView.adjust_limit_group.visibility)
        assertEquals(View.GONE, limitView.limit_loading.visibility)
        assertEquals(View.GONE, limitView.limit_error.visibility)
    }

    @Test
    fun setupTotalLimit_viewShouldHaveTotalValue() {
        // ARRANGE
        val model = mountViewData(total = "1.000,00")

        // ACT
        limitView.setup(model)

        // ASSERT
        assertEquals("R$ 1.000,00", limitView.limit_total_value.text.toString())
    }

    @Test
    fun setAvailableLimit_viewShouldHaveAvailableValue() {
        // ARRANGE
        val model = mountViewData(available = "800,00")

        // ACT
        limitView.setup(model)

        // ASSERT
        assertEquals("R$ 800,00", limitView.limit_available_value.text.toString())
    }

    @Test
    fun setUsedLimit_viewShouldHaveUsedValue() {
        // ARRANGE
        val model = mountViewData(used = "2.000,00")

        // ACT
        limitView.setup(model)

        // ASSERT
        assertEquals("R$ 2.000,00", limitView.limit_used_value.text.toString())
    }

    @Test
    fun onLimitLabelEnabled_withTrue_shouldShowLimitGroup() {
        // ARRANGE
        val model = mountViewData(limitLabelEnabled = true)

        // ACT
        limitView.setup(model)

        // ASSERT
        assertEquals(View.VISIBLE, limitView.adjust_limit_group.visibility)
    }

    @Test
    fun onLimitLabelEnabled_withFalse_shouldHideLimitGroup() {
        // ARRANGE
        val model = mountViewData(limitLabelEnabled = false)

        // ACT
        limitView.setup(model)

        // ASSERT
        assertEquals(View.GONE, limitView.adjust_limit_group.visibility)
    }

    @Test
    fun updateAccessibility_withCriticalLimit_andAdjustLimitLabel_shouldShowCompleteInfo() {
        // ARRANGE
        val model = mountViewData(
            currency = "R$",
            total = "1.000,00",
            available = "800,00",
            used = "2.000,00",
            limitDifferentiated = "150,00",
            limitLabelEnabled = true
        )

        // ACT
        limitView.setup(model)

        // ASSERT
        assertEquals(
            "Seu limite utilizado é de: R\$ 2.000,00. O limite total é de: R\$ 1.000,00 e seu limite disponível hoje é de: R\$ 800,00. Ver mais detalhes",
            limitView.contentDescription
        )
    }

    @Test
    fun updateAccessibility_withoutCriticalLimit_andAdjustLimitLabel_shouldShowOnlyValuesInfo() {
        // ARRANGE
        val model = mountViewData(
            currency = "R$",
            total = "1.000,00",
            available = "800,00",
            used = "2.000,00",
            limitDifferentiated = "150,00",
            limitLabelEnabled = false
        )

        // ACT
        limitView.setup(model)

        // ASSERT
        assertEquals(
            "Seu limite utilizado é de: R\$ 2.000,00. O limite total é de: R\$ 1.000,00 e seu limite disponível hoje é de: R\$ 800,00. Ver mais detalhes",
            limitView.contentDescription
        )
    }

    @Test
    fun updateAccessibility_onLoading_shouldSetEmptyAccessibility() {
        // ARRANGE
        val model = mountViewData()

        // ACT
        limitView.setup(model)
        limitView.state = LimitView.State.LOADING

        // ASSERT
        assertEquals("", limitView.contentDescription)
    }

    @Test
    fun updateAccessibility_onError_shouldSetEmptyAccessibility() {
        // ARRANGE
        val model = mountViewData()

        // ACT
        limitView.setup(model)
        limitView.state = LimitView.State.ERROR

        // ASSERT
        assertEquals("", limitView.contentDescription)
    }

    @Test
    fun setCurrency_shouldShowDifferentCurrencyOnValue() {
        // ARRANGE
        val model = mountViewData(currency = "U$", total = "1.000,00")

        // ACT
        limitView.setup(model)

        // ASSERT
        assertEquals("U$ 1.000,00", limitView.limit_total_value.text.toString())
    }

    @Test
    fun setProgressPercentage_onValidValue_shouldShowExactlyProgress() {
        // ARRANGE
        val model = mountViewData(usedPercentage = 80)

        // ACT
        limitView.setup(model)

        // ASSERT
        assertEquals(80, limitView.limit_progress_bar.progress)
        assertEquals(
            R.drawable.limit_view_progressbar_start_rounded_corner,
            Shadows.shadowOf(limitView.limit_progress_bar.progressDrawable).createdFromResId
        )
    }

    @Test
    fun setProgressPercentage_onNegativeValue_shouldShowZeroProgress() {
        // ARRANGE
        val model = mountViewData(usedPercentage = -10)

        // ACT
        limitView.setup(model)

        // ASSERT
        assertEquals(0, limitView.limit_progress_bar.progress)
        assertEquals(
            R.drawable.limit_view_progressbar_start_rounded_corner,
            Shadows.shadowOf(limitView.limit_progress_bar.progressDrawable).createdFromResId
        )
    }

    @Test
    fun setProgressPercentage_onCriticalValue_shouldShowZeroProgress() {
        // ARRANGE
        val model = mountViewData(usedPercentage = 5000)

        // ACT
        limitView.setup(model)

        // ASSERT
        assertEquals(100, limitView.limit_progress_bar.progress)
        assertEquals(
            R.drawable.limit_view_progressbar_full_rounded_corner,
            Shadows.shadowOf(limitView.limit_progress_bar.progressDrawable).createdFromResId
        )
    }

    @Test
    fun setLimitLabel_withCustomText_shouldShowUpdatedText() {
        // ARRANGE
        val model = mountViewData(limitLabel = "Detalhes")

        // ACT
        limitView.setup(model)

        // ASSERT
        assertEquals("Detalhes", limitView.adjust_your_limit_text.text)
    }

    @Test
    fun setLimitLabel_withNullText_shouldShowDefaultText() {
        // ARRANGE
        val model = mountViewData(limitLabel = null)

        // ACT
        limitView.setup(model)

        // ASSERT
        assertEquals("Ajustar limite", limitView.adjust_your_limit_text.text)
    }

    @Test
    fun configureProgressBarAndLimits_onNormalSituation_shouldShowNormalColorState() {
        // ARRANGE
        val model = mountViewData(limitSituation = LimitView.Situation.NORMAL)

        // ACT
        limitView.setup(model)

        // ASSERT
        val color = ContextCompat.getColor(context, R.color.brand_support_03)

        assertEquals(color, limitView.limit_used_value.currentTextColor)
        assertEquals(
            ColorStateList.valueOf(color),
            limitView.limit_progress_bar.progressTintList
        )
    }

    @Test
    fun configureProgressBarAndLimits_onAttentionSituation_shouldShowAttentionColorState() {
        // ARRANGE
        val model = mountViewData(limitSituation = LimitView.Situation.ATTENTION)

        // ACT
        limitView.setup(model)

        // ASSERT
        val color = ContextCompat.getColor(context, R.color.brand_support_02)

        assertEquals(color, limitView.limit_used_value.currentTextColor)
        assertEquals(
            ColorStateList.valueOf(color),
            limitView.limit_progress_bar.progressTintList
        )
    }

    @Test
    fun configureProgressBarAndLimits_onCriticalSituation_shouldShowCriticalColorState() {
        // ARRANGE
        val model = mountViewData(limitSituation = LimitView.Situation.CRITICAL)

        // ACT
        limitView.setup(model)

        // ASSERT
        val color = ContextCompat.getColor(context, R.color.brand_support_01)

        assertEquals(color, limitView.limit_used_value.currentTextColor)
        assertEquals(
            ColorStateList.valueOf(color),
            limitView.limit_progress_bar.progressTintList
        )
    }

    @Test
    fun setupTryAgainClick_onClick_shouldExecuteAction() {
        // ARRANGE
        var clicked = false
        limitView.tryAgainAction = { clicked = true }

        // ACT
        limitView.errorButton.callOnClick()

        // ASSERT
        assertEquals(true, clicked)
    }

    @Test
    fun setupTryAgainClick_onNullValue_onClick_shouldWorkWithoutAnyWork() {
        // ARRANGE
        var clicked = false
        limitView.tryAgainAction = { clicked = true }

        // ACT
        limitView.tryAgainAction = null
        limitView.errorButton.callOnClick()

        // ASSERT
        assertEquals(false, clicked)
    }

    @Test
    fun adjustViewState_onLoaded_withLimitLabelEnabled_shouldShowLoadedViews() {
        // ARRANGE
        val model = mountViewData(limitLabelEnabled = true)

        // ACT
        limitView.setup(model)
        limitView.state = LimitView.State.LOADED

        // ASSERT
        assertEquals(View.VISIBLE, limitView.limit_view_group.visibility)
        assertEquals(View.VISIBLE, limitView.adjust_limit_group.visibility)
        assertEquals(View.GONE, limitView.limit_loading.visibility)
        assertEquals(View.GONE, limitView.limit_error.visibility)
    }

    @Test
    fun adjustViewState_onLoaded_withLimitLabelDisabled_shouldShowLoadedViews() {
        // ARRANGE
        val model = mountViewData(limitLabelEnabled = false)

        // ACT
        limitView.setup(model)
        limitView.state = LimitView.State.LOADED

        // ASSERT
        assertEquals(View.VISIBLE, limitView.limit_view_group.visibility)
        assertEquals(View.GONE, limitView.adjust_limit_group.visibility)
        assertEquals(View.GONE, limitView.limit_loading.visibility)
        assertEquals(View.GONE, limitView.limit_error.visibility)
    }

    @Test
    fun adjustViewState_onLoading_shouldShowLoadingView() {
        // ACT
        limitView.state = LimitView.State.LOADING

        // ASSERT
        assertEquals(View.GONE, limitView.limit_view_group.visibility)
        assertEquals(View.GONE, limitView.adjust_limit_group.visibility)
        assertEquals(View.VISIBLE, limitView.limit_loading.visibility)
        assertEquals(View.GONE, limitView.limit_error.visibility)
    }


    @Test
    fun adjustViewState_onError_shouldShowLoadingView() {
        // ACT
        limitView.state = LimitView.State.ERROR

        // ASSERT
        assertEquals(View.GONE, limitView.limit_view_group.visibility)
        assertEquals(View.GONE, limitView.adjust_limit_group.visibility)
        assertEquals(View.GONE, limitView.limit_loading.visibility)
        assertEquals(View.VISIBLE, limitView.limit_error.visibility)
    }

    private fun mountViewData(
        total: String = "3.000,00",
        available: String = "1.200,00",
        used: String = "1.800,00",
        currency: String = "R$",
        usedPercentage: Int = 50,
        limitSituation: LimitView.Situation = LimitView.Situation.NORMAL,
        limitDifferentiated: String = "50,00",
        limitLabelEnabled: Boolean = true,
        limitLabel: String? = null
    ) = LimitModel(
        total = total,
        available = available,
        used = used,
        currency = currency,
        usedPercentage = usedPercentage,
        limitSituation = limitSituation,
        limitDifferentiated = limitDifferentiated,
        limitLabelEnabled = limitLabelEnabled,
        limitLabel = limitLabel
    )
}