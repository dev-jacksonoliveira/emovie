package br.com.portoseguro.components.tutorial

import android.app.Activity
import android.os.Build
import br.com.portoseguro.components.tutorial.screen.TutorialScreen
import br.com.portoseguro.superapp.core.analytics.Analytics
import br.com.portoseguro.superapp.core.analytics.model.Action
import br.com.portoseguro.superapp.core.analytics.model.ViewItem
import br.com.portoseguro.superapp.core.analytics.utils.Section
import br.com.portoseguro.superapp.core.analytics.utils.SubSection
import io.mockk.MockKAnnotations
import io.mockk.every
import io.mockk.impl.annotations.MockK
import io.mockk.slot
import io.mockk.verify
import org.junit.Assert.assertEquals
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [Build.VERSION_CODES.P], qualifiers = "br")
class TutorialViewModelTest {
    private lateinit var viewModel: TutorialViewModel

    @MockK
    private lateinit var analyticsMock: Analytics

    @MockK
    private lateinit var contextMock: Activity

    private val viewItemCaptor = slot<ViewItem>()

    private val actionItemCaptor = slot<Action>()

    @Before
    fun setup() {
        MockKAnnotations.init(this)
        viewModel = TutorialViewModel(analyticsMock)
    }

    @Test
    fun trackViewItem_whenOpenScreen_shouldTrackRightData() {
        every { analyticsMock.trackViewItem(any()) } answers { nothing }

        val newScreen = screen
        newScreen.step = "2"

        viewModel.trackPageView(contextMock, newScreen)

        verify { analyticsMock.trackViewItem(capture(viewItemCaptor)) }
        val result = viewItemCaptor.captured

        assertEquals("a:b:c:2", result.getData()["item_name"])
        assertEquals("a", result.getData()["app_section"])
        assertEquals("b", result.getData()["app_sub_section_1"])
        assertEquals("c", result.getData()["app_sub_section_2"])
        assertEquals("e", result.getData()["product"])
        assertEquals("2", result.getData()["step"])
    }

    @Test
    fun trackClickAction_whenTapOnTutorialButton_shouldTrackRightData() {
        every { analyticsMock.trackAction(any()) } answers { nothing }
        val textButton = "apenas teste"

        viewModel.trackClickAction(screen, "2", textButton)

        verify { analyticsMock.trackAction(capture(actionItemCaptor)) }
        val result = actionItemCaptor.captured

        assertEquals("a:b:c:2", result.getData()["item_name"])
        assertEquals("a", result.getData()["app_section"])
        assertEquals("b", result.getData()["app_sub_section_1"])
        assertEquals("c", result.getData()["app_sub_section_2"])
        assertEquals("app:mundoporto:e", result.getData()["ev_category"])
        assertEquals("click:d:apenas-teste", result.getData()["ev_action"])
        assertEquals("e", result.getData()["product"])
    }

    private val screen = TutorialScreen(
        Section("a"),
        SubSection("b"),
        SubSection("c"),
        name = "d",
        product = "e"
    )

}
