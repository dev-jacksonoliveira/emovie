package br.com.portoseguro.components.phones

import android.content.Context
import android.os.Build
import androidx.test.core.app.ApplicationProvider
import br.com.portoseguro.components.phones.adapter.PhoneModelFactoryDefault
import org.junit.Assert.assertEquals
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [Build.VERSION_CODES.P], qualifiers = "br")
class PhoneModelFactoryDefaultTest {

    private lateinit var factory: PhoneModelFactoryDefault

    @Before
    fun setup() {
        val context: Context = ApplicationProvider.getApplicationContext()
        factory = PhoneModelFactoryDefault(context)
    }

    @Test
    fun getPhoneList_shouldReturnCorrectlyPhoneList() {
        // ACT
        val phoneList = factory.getPhoneList()

        // ASSERT
        assertEquals(5, phoneList.size)

        assertEquals("4004 3600", phoneList[0].phoneNumber)
        assertEquals("Capitais e regiões metropolitanas", phoneList[0].subtitle)
        assertEquals("capitais", phoneList[0].label)

        assertEquals("0800 727 7477", phoneList[1].phoneNumber)
        assertEquals("Demais localidades", phoneList[1].subtitle)
        assertEquals("demais-localidades", phoneList[1].label)

        assertEquals("0800 701 5582", phoneList[2].phoneNumber)
        assertEquals("Atendimento exclusivo para pessoas com deficiências auditiva, realizado somente por um telefone especial", phoneList[2].subtitle)
        assertEquals("exclusivo-para-deficientes", phoneList[2].label)

        assertEquals("55 11 3366 3126", phoneList[3].phoneNumber)
        assertEquals("Central de relacionamentos no exterior", phoneList[3].subtitle)
        assertEquals("exterior", phoneList[3].label)

        assertEquals("0800 727 2769", phoneList[4].phoneNumber)
        assertEquals("SAC - Canal para continuidade de atendimentos com protocolos já abertos", phoneList[4].subtitle)
        assertEquals("sac", phoneList[4].label)
    }
}