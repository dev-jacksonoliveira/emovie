package br.com.portoseguro.components

import org.junit.Assert.assertEquals
import org.junit.Test

class RemoveSpecialCharactersTest {

    private val accents = "È,É,Ê,Ë,Û,Ù,Ï,Î,À,Â,Ô,è,é,ê,ë,û,ù,ï,î,à,â,ô,Ç,ç,Ã,ã,Õ,õ"
    private val expected = "EEEEUUIIAAOeeeeuuiiaaoCcAaOo"

    private val accents2 = "çÇáéíóúýÁÉÍÓÚÝàèìòùÀÈÌÒÙãõñäëïöüÿÄËÏÖÜÃÕÑâêîôûÂÊÎÔÛ"
    private val expected2 = "cCaeiouyAEIOUYaeiouAEIOUaonaeiouyAEIOUAONaeiouAEIOU"

    private val accents3 =
        "João Almeida da silva Orlão .@# aéióú@."
    private val expected3 =
        "Joao Almeida da silva Orlao  aeiou"

    private val accents4 =
        "/Users/test/arquivos-user/Test/Test_Unaccent-1.23.40.exe"
    private val expected4 =
        "UserstestarquivosuserTestTestUnaccent12340exe"

    @Test
    fun replacingAllSpecialCharacters() {
        assertEquals(expected, accents.removeSpecialCharacters())
        assertEquals(expected2, accents2.removeSpecialCharacters())
        assertEquals(expected3, accents3.removeSpecialCharacters())
        assertEquals(expected4, accents4.removeSpecialCharacters())
    }
}