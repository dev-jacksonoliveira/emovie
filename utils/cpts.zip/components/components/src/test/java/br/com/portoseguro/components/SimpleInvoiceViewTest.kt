package br.com.portoseguro.components

import android.os.Build
import android.view.View
import androidx.test.platform.app.InstrumentationRegistry
import br.com.portoseguro.components.invoicesection.InvoiceSectionView
import br.com.portoseguro.components.simpleinvoice.SimpleInvoiceView
import kotlinx.android.synthetic.main.generic_loading_button_layout.view.generic_loading_button
import kotlinx.android.synthetic.main.invoice_section_view.view.invoice_section_date
import kotlinx.android.synthetic.main.invoice_section_view.view.invoice_section_group_detail_invoice
import kotlinx.android.synthetic.main.invoice_section_view.view.invoice_section_group_see_invoice
import kotlinx.android.synthetic.main.invoice_section_view.view.invoice_section_value
import kotlinx.android.synthetic.main.simple_invoice_view.view.simple_invoice_primary_button
import kotlinx.android.synthetic.main.simple_invoice_view.view.simple_invoice_secondary_button
import kotlinx.android.synthetic.main.simple_invoice_view.view.simple_invoice_section
import kotlinx.android.synthetic.main.simple_invoice_view_container.view.simple_invoice_error_view
import kotlinx.android.synthetic.main.simple_invoice_view_container.view.simple_invoice_view
import org.junit.Assert.assertEquals
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [Build.VERSION_CODES.P], qualifiers = "br")
class SimpleInvoiceViewTest {

    private val context =
        InstrumentationRegistry.getInstrumentation().targetContext.applicationContext

    private lateinit var simpleInvoiceView: SimpleInvoiceView

    @Before
    fun setUp() {
        simpleInvoiceView = SimpleInvoiceView(context)
    }

    @Test
    fun onSimplesInvoiceView_whenSetStateToOpen_shouldShowOpenState() {
        // ARRANGE
        val invoiceSection = simpleInvoiceView.simple_invoice_section
        val errorStateView = simpleInvoiceView.simple_invoice_error_view
        val invoiceView = simpleInvoiceView.simple_invoice_view
        val primaryButton = simpleInvoiceView.simple_invoice_primary_button
        val secondaryButton = simpleInvoiceView.simple_invoice_secondary_button.generic_loading_button

        // ACT
        simpleInvoiceView.state = SimpleInvoiceView.ViewState.OPEN

        // ASSERT
        assertEquals(invoiceSection.state, InvoiceSectionView.ViewState.OPEN)
        assertEquals(errorStateView.visibility, View.GONE)
        assertEquals(invoiceView.visibility, View.VISIBLE)
        assertEquals(primaryButton.visibility, View.GONE)
        assertEquals(secondaryButton.text.toString(), "Detalhes")
        assertEquals(secondaryButton.contentDescription.toString(), "Detalhes da fatura")
    }

    @Test
    fun onSimplesInvoiceView_whenSetStateToClose_shouldShowCloseState() {
        // ARRANGE
        val invoiceSection = simpleInvoiceView.simple_invoice_section
        val errorStateView = simpleInvoiceView.simple_invoice_error_view
        val invoiceView = simpleInvoiceView.simple_invoice_view
        val primaryButton = simpleInvoiceView.simple_invoice_primary_button.generic_loading_button
        val secondaryButton = simpleInvoiceView.simple_invoice_secondary_button.generic_loading_button

        // ACT
        simpleInvoiceView.state = SimpleInvoiceView.ViewState.CLOSED

        // ASSERT
        assertEquals(invoiceSection.state, InvoiceSectionView.ViewState.CLOSED)
        assertEquals(errorStateView.visibility, View.GONE)
        assertEquals(invoiceView.visibility, View.VISIBLE)
        assertEquals(primaryButton.visibility, View.VISIBLE)
        assertEquals(secondaryButton.text.toString(), "Pagar")
        assertEquals(secondaryButton.contentDescription.toString(), "Pagar fatura")
        assertEquals(primaryButton.contentDescription.toString(), "Detalhes da fatura")
    }

    @Test
    fun onSimplesInvoiceView_whenSetStateToError_shouldShowErrorState() {
        // ARRANGE
        val invoiceSection = simpleInvoiceView.simple_invoice_section
        val errorStateView = simpleInvoiceView.simple_invoice_error_view
        val invoiceView = simpleInvoiceView.simple_invoice_view

        // ACT
        simpleInvoiceView.state = SimpleInvoiceView.ViewState.ERROR

        // ASSERT
        assertEquals(invoiceSection.state, InvoiceSectionView.ViewState.ERROR)
        assertEquals(errorStateView.visibility, View.VISIBLE)
        assertEquals(invoiceView.visibility, View.GONE)
    }

    @Test
    fun onSimplesInvoiceView_whenSetSecondaryButtonVisibleToFalse_shouldReflectOnView() {
        // ARRANGE
        val secondaryButton = simpleInvoiceView.simple_invoice_secondary_button

        // ACT
        simpleInvoiceView.secondaryButtonVisible = false

        // ASSERT
        assertEquals(secondaryButton.visibility, View.INVISIBLE)
    }

    @Test
    fun onSimplesInvoiceView_whenSetCurrentValue_shouldReflectOnView() {
        // ARRANGE
        val invoiceSectionValue = simpleInvoiceView.simple_invoice_section.invoice_section_value
        val groupSeeInvoice = simpleInvoiceView.simple_invoice_section.invoice_section_group_see_invoice
        val groupDetailInvoice = simpleInvoiceView.simple_invoice_section.invoice_section_group_detail_invoice
        val value = "10.00"
        val formattedValue = String.format(CURRENCY_TEMPLATE, CURRENCY, value)

        // ACT
        simpleInvoiceView.currentValue = value

        // ASSERT
        assertEquals(invoiceSectionValue.text.toString(), formattedValue)
        assertEquals(groupSeeInvoice.visibility, View.GONE)
        assertEquals(groupDetailInvoice.visibility, View.VISIBLE)
    }

    @Test
    fun onSimplesInvoiceView_whenSetCurrentDate_shouldReflectOnView() {
        // ARRANGE
        val invoiceSectionDate = simpleInvoiceView.simple_invoice_section.invoice_section_date
        val groupSeeInvoice = simpleInvoiceView.simple_invoice_section.invoice_section_group_see_invoice
        val groupDetailInvoice = simpleInvoiceView.simple_invoice_section.invoice_section_group_detail_invoice
        val date = "08/03/1997"

        // ACT
        simpleInvoiceView.currentDate = date

        // ASSERT
        assertEquals(invoiceSectionDate.text.toString(), date)
        assertEquals(groupSeeInvoice.visibility, View.GONE)
        assertEquals(groupDetailInvoice.visibility, View.VISIBLE)
    }

    companion object {
        private const val CURRENCY = "R$"
        private const val CURRENCY_TEMPLATE = "%s %s"
    }
}