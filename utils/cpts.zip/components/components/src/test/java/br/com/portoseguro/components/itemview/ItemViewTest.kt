package br.com.portoseguro.components.itemview

import android.os.Build
import android.view.View
import androidx.test.platform.app.InstrumentationRegistry
import br.com.portoseguro.components.R
import org.junit.Assert.assertEquals
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [Build.VERSION_CODES.P], qualifiers = "br")
class ItemViewTest {

    private val context =
        InstrumentationRegistry.getInstrumentation().targetContext.applicationContext

    private lateinit var itemView: ItemView

    @Before
    fun setUp() {
        itemView = ItemView(context)
    }

    @Test
    fun onSetup_withoutSubtitle_AccessibilityShouldReadTitleOnly() {
        itemView.setup(titleText = "somente o titulo")

        assertEquals("somente o titulo", itemView.findViewById<View>(R.id.container).contentDescription)
    }

    @Test
    fun onSetup_withTitleAndSubtitle_AccessibilityShouldReadTitleAndSubtitle() {
        itemView.setup(titleText = "titulo", subtitleText = "e subtitulo")

        assertEquals("titulo e subtitulo", itemView.findViewById<View>(R.id.container).contentDescription)
    }

}