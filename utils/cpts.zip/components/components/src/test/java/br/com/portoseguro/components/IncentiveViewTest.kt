package br.com.portoseguro.components

import android.os.Build
import androidx.test.platform.app.InstrumentationRegistry
import br.com.portoseguro.components.incentiveview.IncentiveView
import kotlinx.android.synthetic.main.incentive_view.view.incentive_view_container
import kotlinx.android.synthetic.main.incentive_view.view.incentive_view_icon
import kotlinx.android.synthetic.main.incentive_view.view.incentive_view_text
import org.junit.Assert.assertEquals
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [Build.VERSION_CODES.P], qualifiers = "br")
class IncentiveViewTest {

    private val context =
        InstrumentationRegistry.getInstrumentation().targetContext.applicationContext

    private lateinit var incentiveView: IncentiveView

    @Before
    fun setUp() {
        incentiveView = IncentiveView(context)
    }

    @Test
    fun onIncentiveView_whenInflatedAsDefaultState_shouldShowDefaultProperties() {
        // ARRANGE
        val incentiveViewMessageTextView = incentiveView.incentive_view_text
        val incentiveViewIcon = incentiveView.incentive_view_icon

        // ASSERT
        assertEquals(incentiveViewMessageTextView.text.toString(), "Este cartão está bloqueado.\nDesbloquear este cartão?")
        assertEquals(incentiveViewIcon.text.toString(), context.getString(R.string.icon_lock))
    }

    @Test
    fun onIncentiveView_onSetMessage_shouldSetMessageAndContentDescription() {
        // ARRANGE
        val incentiveViewMessageTextView = incentiveView.incentive_view_text
        val containerView = incentiveView.incentive_view_container

        // ACT
        incentiveView.setMessage("Will Smith")

        // ASSERT
        assertEquals(incentiveViewMessageTextView.text.toString(), "Will Smith")
        assertEquals(containerView.contentDescription.toString(), "Will Smith")
    }

    @Test
    fun onIncentiveView_onSetAccessibility_shouldSetContentDescription() {
        // ARRANGE
        val containerView = incentiveView.incentive_view_container

        // ACT
        incentiveView.setAccessibility("Lucas Tesla")

        // ASSERT
        assertEquals(containerView.contentDescription.toString(), "Lucas Tesla")
    }

    @Test
    fun onIncentiveView_onSetIcon_shouldSetIcon() {
        // ARRANGE
        val icon = incentiveView.incentive_view_icon

        // ACT
        incentiveView.setIcon("A")

        // ASSERT
        assertEquals(icon.text.toString(), "A")
    }
}