package br.com.portoseguro.components

import android.app.Activity
import android.os.Build
import br.com.portoseguro.components.alertdialog.AlertDialogData
import br.com.portoseguro.components.genericwebview.GenericWebViewViewModel
import br.com.portoseguro.superapp.core.analytics.Analytics
import br.com.portoseguro.superapp.core.analytics.model.Action
import br.com.portoseguro.superapp.core.analytics.model.ViewItem
import br.com.portoseguro.superapp.core.analytics.utils.Screen
import br.com.portoseguro.superapp.core.analytics.utils.Section
import br.com.portoseguro.superapp.core.analytics.utils.SubSection
import io.mockk.MockKAnnotations
import io.mockk.every
import io.mockk.impl.annotations.MockK
import io.mockk.slot
import io.mockk.verify
import org.junit.Assert.assertEquals
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [Build.VERSION_CODES.P], qualifiers = "br")
class GenericWebViewViewModelTest {

    private lateinit var viewModel: GenericWebViewViewModel

    @MockK
    private lateinit var analyticsMock: Analytics

    @MockK
    private lateinit var contextMock: Activity

    private val viewItemCaptor = slot<ViewItem>()

    @Before
    fun setup() {
        MockKAnnotations.init(this)
        viewModel = GenericWebViewViewModel(analyticsMock)
    }

    @Test
    fun trackViewItem_onOpenChatBot_ShouldTrackRightData() {
        every { analyticsMock.trackViewItem(any()) } answers { nothing }

        viewModel.trackPageView(activity = contextMock, screen = setScreen)
        verify { analyticsMock.trackViewItem(capture(viewItemCaptor)) }
        val resultViewItem = viewItemCaptor.captured
        assertEquals(
            3,
            resultViewItem.getData().size()
        )
        assertEquals(
            "atendimento:chat",
            resultViewItem.getData()["item_name"]
        )
        assertEquals("atendimento", resultViewItem.getData()["app_section"])
        assertEquals("webview", resultViewItem.getData()["app_platform"])
    }

    private  val setScreen = Screen(name="chat", section = Section("atendimento"))

    private val baseAlertDialogData = AlertDialogData("title alert", "alert", "btn1", "btn2")

    @Test
    fun trackAlertView_withoutData_doNothing() {
        // arrange
        val dialogData = baseAlertDialogData.copy(screen = null)
        every { analyticsMock.trackViewItem(any()) } answers { nothing }

        // act
        viewModel.trackAlertView(contextMock, dialogData)

        // assert
        verify(exactly = 0) { analyticsMock.trackViewItem(any()) }
    }

    @Test
    fun trackAlertView_withData_shouldTrackViewItem() {
        // arrange
        val subSections = listOf(SubSection("s1"), SubSection("s2"), SubSection("s3")).toTypedArray()
        val screen = Screen(Section("section"), name = "nome_dialog", subSections = *subSections)
        val dialogData = baseAlertDialogData.copy(screen = screen)
        every { analyticsMock.trackViewItem(any()) } answers { nothing }

        // act
        viewModel.trackAlertView(contextMock, dialogData)

        // assert
        verify { analyticsMock.trackViewItem(capture(viewItemCaptor)) }
        val viewItem = viewItemCaptor.captured
        assertEquals("section:s1:s2:s3:nome_dialog", viewItem.itemName)
        assertEquals("nativo", viewItem.getData()["app_platform"])
        assertEquals("section:s1:s2:s3:nome_dialog", viewItem.getData()["item_name"])
        assertEquals("section", viewItem.getData()["app_section"])
        assertEquals("s1", viewItem.getData()["app_sub_section_1"])
        assertEquals("s2", viewItem.getData()["app_sub_section_2"])
        assertEquals("s3", viewItem.getData()["app_sub_section_3"])
    }

    @Test
    fun trackClickFirstButtonAlert_withoutData_doNothing() {
        // arrange
        val dialogData = baseAlertDialogData.copy(screen = null)
        every { analyticsMock.trackAction(any()) } answers { nothing }

        // act
        viewModel.trackClickFirstButtonAlert(dialogData)

        // assert
        verify(exactly = 0) { analyticsMock.trackAction(any()) }
    }

    @Test
    fun trackClickFirstButtonAlert_withData_shouldTrackViewItem() {
        // arrange
        val subSections = listOf(SubSection("s1"), SubSection("s2")).toTypedArray()
        val screen = Screen(Section("section"), name = "nome_dialog", subSections = *subSections)
        val dialogData = baseAlertDialogData.copy(screen = screen)
        every { analyticsMock.trackAction(any()) } answers { nothing }

        // act
        viewModel.trackClickFirstButtonAlert(dialogData)

        // assert
        val actionCaptor = slot<Action>()
        verify { analyticsMock.trackAction(capture(actionCaptor)) }
        val action = actionCaptor.captured
        assertEquals("nativo", action.getData()["app_platform"])
        assertEquals("section:s1:s2:nome_dialog", action.getData()["item_name"])
        assertEquals("section", action.getData()["app_section"])
        assertEquals("s1", action.getData()["app_sub_section_1"])
        assertEquals("s2", action.getData()["app_sub_section_2"])
        assertEquals("click:s1:btn1", action.getData()["ev_action"])
        assertEquals("app:mundoporto:section", action.getData()["ev_category"])
    }

    @Test
    fun trackClickSecondButtonAlert_withoutData_doNothing() {
        // arrange
        val dialogData = baseAlertDialogData.copy(screen = null)
        every { analyticsMock.trackAction(any()) } answers { nothing }

        // act
        viewModel.trackClickSecondButtonAlert(dialogData)

        // assert
        verify(exactly = 0) { analyticsMock.trackAction(any()) }
    }

    @Test
    fun trackClickSecondButtonAlert_withData_shouldTrackViewItem() {
        // arrange
        val subSections = listOf(SubSection("s1"), SubSection("s2"), SubSection("s3")).toTypedArray()
        val screen = Screen(Section("section"), name = "nome_dialog", subSections = *subSections)
        val dialogData = baseAlertDialogData.copy(screen = screen)
        every { analyticsMock.trackAction(any()) } answers { nothing }

        // act
        viewModel.trackClickSecondButtonAlert(dialogData)

        // assert
        val actionCaptor = slot<Action>()
        verify { analyticsMock.trackAction(capture(actionCaptor)) }
        val action = actionCaptor.captured
        assertEquals("nativo", action.getData()["app_platform"])
        assertEquals("section:s1:s2:s3:nome_dialog", action.getData()["item_name"])
        assertEquals("section", action.getData()["app_section"])
        assertEquals("s1", action.getData()["app_sub_section_1"])
        assertEquals("s2", action.getData()["app_sub_section_2"])
        assertEquals("s3", action.getData()["app_sub_section_3"])
        assertEquals("click:s1:btn2", action.getData()["ev_action"])
        assertEquals("app:mundoporto:section", action.getData()["ev_category"])
    }

}
