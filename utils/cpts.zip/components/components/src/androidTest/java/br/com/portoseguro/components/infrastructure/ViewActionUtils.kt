package br.com.portoseguro.components.infrastructure

import android.view.View
import androidx.test.espresso.UiController
import androidx.test.espresso.ViewAction
import androidx.test.espresso.matcher.ViewMatchers.isAssignableFrom
import androidx.test.espresso.matcher.ViewMatchers.isDisplayed
import org.hamcrest.CoreMatchers.allOf
import org.hamcrest.Matcher

object ViewActionUtils {

    fun takeScreenshot(filename: String): ViewAction {
        return object : ViewAction {
            override fun getDescription(): String {
                return "tira o screenshot da view : $filename"
            }

            override fun getConstraints(): Matcher<View> {
                return allOf(isAssignableFrom(View::class.java), isDisplayed())
            }

            override fun perform(uiController: UiController, view: View) {
                view.recordView(filename)
            }
        }
    }

    fun waitFor(delay: Long = 1000): ViewAction {
        return object : ViewAction {
            override fun perform(uiController: UiController?, view: View?) {
                uiController?.loopMainThreadForAtLeast(delay)
            }

            override fun getConstraints(): Matcher<View> {
                return isAssignableFrom(View::class.java)
            }

            override fun getDescription(): String {
                return "espera por ${delay}ms"
            }
        }
    }
}