package br.com.portoseguro.components.snapshot

import android.os.Bundle
import androidx.fragment.app.testing.launchFragmentInContainer
import androidx.test.espresso.intent.Intents
import androidx.test.ext.junit.runners.AndroidJUnit4
import br.com.portoseguro.components.R
import br.com.portoseguro.components.infrastructure.KoinTestRule
import br.com.portoseguro.components.robot.TutorialRobot
import br.com.portoseguro.components.tutorial.TutorialDialogFragment
import br.com.portoseguro.components.tutorial.TutorialViewModel
import br.com.portoseguro.components.tutorial.data.ScreenTutorial
import br.com.portoseguro.components.tutorial.data.Tutorial
import br.com.portoseguro.components.tutorial.screen.TutorialScreen
import br.com.portoseguro.superapp.core.analytics.Analytics
import br.com.portoseguro.superapp.core.analytics.utils.Section
import br.com.portoseguro.superapp.core.analytics.utils.SubSection
import io.mockk.mockk
import org.junit.After
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.koin.androidx.viewmodel.dsl.viewModel
import org.koin.core.context.loadKoinModules
import org.koin.dsl.module

@RunWith(AndroidJUnit4::class)
class TutorialDialogFragmentTest {

    @get:Rule
    val koinTestRule = KoinTestRule()

    private val analytics: Analytics = mockk(relaxed = true)
    private val robot: TutorialRobot = TutorialRobot()

    @Before
    fun setup() {
        Intents.init()

        loadKoinModules(module {
            single { analytics }
            viewModel { TutorialViewModel(get()) }
        })
    }

    @After
    fun cleanUp() {
        Intents.release()
    }

    @Test
    fun tutorialActivity_firstStepValidation() {
        // ACT
        launchFragment()

        // ASSERT
        robot.takeHomeBottomSheetScreenshot("TUTORIAL_FIRST_STEP")
    }

    @Test
    fun tutorialActivity_secondStepValidation() {
        // ACT
        launchFragment()
        robot.swipeToNextStep(1)

        // ASSERT
        robot.takeHomeBottomSheetScreenshot("TUTORIAL_SECOND_STEP")
    }

    @Test
    fun tutorialActivity_thirdStepValidation() {
        // ACT
        launchFragment()
        robot.swipeToNextStep(2)

        // ASSERT
        robot.takeHomeBottomSheetScreenshot("TUTORIAL_THIRD_STEP")
    }

    @Test
    fun tutorialActivity_fourthStepValidation() {
        // ACT
        launchFragment()
        robot.swipeToNextStep(3)

        // ASSERT
        robot.takeHomeBottomSheetScreenshot("TUTORIAL_FOURTH_STEP")
    }

    private fun launchFragment() =
        launchFragmentInContainer<TutorialDialogFragment>(themeResId = R.style.AppTheme, fragmentArgs = getBundle())

    private fun getTutorialModel(): Tutorial =
        Tutorial(
            getScreenTutorialList(), "Comece a usar",
            TutorialScreen(Section(name = "shellbox"), SubSection(""), name = "shellbox")
        )

    private fun getScreenTutorialList(): List<ScreenTutorial> =
        arrayListOf(
            ScreenTutorial(
                "Vá até um Posto Shell",
                R.drawable.shellbox_location,
                "Procure por postos participantes com o símbolo Shell Box."
            ), ScreenTutorial(
                "Digite o código de pagamento",
                R.drawable.shellbox_token,
                "Cada bomba tem o seu código e você digita ele antes de abastecer."
            ),
            ScreenTutorial(
                "Autorize o Abastecimento",
                R.drawable.shellbox_autorized,
                "Você precisa autorizar antes do final do abastecimento."
            ),
            ScreenTutorial(
                "Pronto!",
                R.drawable.shellbox_fuel,
                "Após finalizar o abastecimento o pagamento será feito automaticamente."
            )
        )

    private fun getBundle() = Bundle().apply { putParcelable(TUTORIAL_KEY, getTutorialModel()) }

    companion object {
        private const val TUTORIAL_KEY = "TUTORIAL_PARAMS"
    }
}