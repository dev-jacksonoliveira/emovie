package br.com.portoseguro.components.component

import android.content.Intent
import androidx.arch.core.executor.testing.InstantTaskExecutorRule
import androidx.test.espresso.Espresso
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.rule.ActivityTestRule
import br.com.portoseguro.components.alertdialog.AlertDialogData
import br.com.portoseguro.components.genericwebview.GenericWebViewActivity
import br.com.portoseguro.components.genericwebview.GenericWebViewViewModel
import br.com.portoseguro.components.infrastructure.KoinTestRule
import br.com.portoseguro.components.robot.genericWebViewRobot
import br.com.portoseguro.superapp.core.analytics.Analytics
import io.mockk.mockk
import org.junit.After
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.koin.androidx.viewmodel.dsl.viewModel
import org.koin.core.context.loadKoinModules
import org.koin.dsl.module

@RunWith(AndroidJUnit4::class)
class GenericWebViewTest {

    @Rule
    @JvmField
    val activityRule = ActivityTestRule(GenericWebViewActivity::class.java, true, false)

    @Rule
    @JvmField
    val instantTaskExecutorRule = InstantTaskExecutorRule()

    @get:Rule
    val koinTestRule = KoinTestRule()

    private val analytics: Analytics = mockk(relaxed = true)

    private lateinit var activity: GenericWebViewActivity

    @Before
    fun setup() {
        loadKoinModules(module {
            single { analytics }
            viewModel { GenericWebViewViewModel(get()) }
        })
    }

    @After
    fun tearDown() {
        activityRule.finishActivity()
    }

    @Test
    fun validateGenericWebViewActivity_onClickReturn_shouldShowConfirmation() {
        // ARRANGE
        setParametersActivity(showAlert = true)

        // ACT
        genericWebViewRobot {
            clickOnReturn()

            // ASSERT
            isVisibleAlert()
        }
    }

    @Test
    fun validateGenericWebViewActivity_onPressBack_shouldShowConfirmation() {
        // ARRANGE
        setParametersActivity(showAlert = true)

        // ACT
        genericWebViewRobot {
            Espresso.pressBack()

            // ASSERT
            isVisibleAlert()
        }
    }

    @Test
    fun validateGenericWebViewActivity_onClickReturn_shouldShowConfirmation_onClickYes() {
        // ARRANGE
        setParametersActivity(showAlert = true)

        // ACT
        genericWebViewRobot {
            clickOnReturn()
            isVisibleAlert()
            clickOnAlertYes()
        }

        // ASSERT
        activityRule.activity.isFinishing
    }

    @Test
    fun validateGenericWebViewActivity_onClickReturn_shouldShowConfirmation_onClickNo() {
        // ARRANGE
        setParametersActivity(showAlert = true)

        // ACT
        genericWebViewRobot {
            clickOnReturn()
            isVisibleAlert()
            clickOnAlertNo()
        }

        // ASSERT
        !activityRule.activity.isFinishing
    }

    @Test
    fun validateGenericWebViewActivity_onClickReturn_notShouldShowConfirmation() {
        // ARRANGE
        setParametersActivity(showAlert = false)

        // ACT
        genericWebViewRobot { clickOnReturn() }

        // ASSERT
        activityRule.activity.isFinishing
    }

    private fun setAlertDialogExitChat() =
        AlertDialogData(
            text = "Você tem certeza que deseja sair do chat?",
            textBold = "",
            firstButtonText = "Sim",
            secondButtonText = "Não"
        )

    private fun setParametersActivity(showAlert: Boolean) {
        activity = activityRule.launchActivity(
            Intent()
                .putExtra(URL_EXTRA, "https://www.google.com.br")
                .putExtra(TITLE_EXTRA, "Chat Atendimento")
                .putExtra(ALERT_EXTRA, if (showAlert) setAlertDialogExitChat() else null)
                .putExtra(UPLOAD_TOGGLE, false)
        )
    }

    private companion object {
        const val URL_EXTRA = "url_extra"
        const val TITLE_EXTRA = "title_extra"
        const val ALERT_EXTRA = "alert_extra"
        const val UPLOAD_TOGGLE = "upload"
    }
}