package br.com.portoseguro.components.robot

import androidx.test.espresso.Espresso.onView
import androidx.test.espresso.action.ViewActions.click
import androidx.test.espresso.matcher.ViewMatchers.withId
import br.com.portoseguro.components.R
import br.com.portoseguro.components.infrastructure.BaseRobot
import com.facebook.testing.screenshot.internal.TestNameDetector

fun alertDialogRobot(func: AlertDialogRobot.() -> Unit) = AlertDialogRobot().apply { func() }

class AlertDialogRobot: BaseRobot() {

    fun clickOnFirstButton() {
        onView(withId(R.id.logout_alert_dialog_first_button)).perform(click())
    }

    fun clickOnSecondButton() {
        onView(withId(R.id.logout_alert_dialog_second_button)).perform(click())
    }

    fun takeScreenShotLogoutDialog() {
        val fileName = TestNameDetector.getTestClass() + TestNameDetector.getTestName()
        takeLayoutScreenshot(R.id.logout_dialog_container, fileName)
    }
}