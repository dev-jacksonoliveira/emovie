package br.com.portoseguro.components.infrastructure

import android.app.Activity
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.view.children
import com.facebook.testing.screenshot.Screenshot

internal fun Activity.recordActivity(fileName: String, timeout: Long = 1000) {
    hideCursors()
    Thread.sleep(timeout)
    Screenshot.snapActivity(this).setName(fileName).record()
}

internal fun View.recordView(fileName: String, timeout: Long = 750) {
    if (this.parent is ViewGroup) {
        val viewGroup = this.parent as ViewGroup
        viewGroup.hideCursors()
    } else if (this is ViewGroup) {
        val viewGroup = this
        viewGroup.hideCursors()
    }
    Thread.sleep(timeout)
    Screenshot.snap(this).setName(fileName).record()
}

private fun Activity.hideCursors() {
    runOnUiThread { findViewById<ViewGroup>(android.R.id.content).hideCursors() }
}

private fun ViewGroup.hideCursors() {
    for (child in children) {
        if (child is ViewGroup) child.hideCursors()
        if (child is TextView) child.isCursorVisible = false
    }
}