package br.com.portoseguro.components.snapshot

import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import androidx.test.rule.ActivityTestRule
import br.com.portoseguro.components.CustomViewContainerActivity
import br.com.portoseguro.components.infrastructure.KoinTestRule
import br.com.portoseguro.components.story.ProductShortCut
import br.com.portoseguro.components.story.ProductShortCut.Type
import br.com.portoseguro.components.story.Story
import br.com.portoseguro.superapp.core.toggle.FeatureToggle
import com.facebook.testing.screenshot.Screenshot
import io.mockk.every
import io.mockk.mockk
import org.junit.After
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.koin.core.context.loadKoinModules
import org.koin.dsl.module

@RunWith(AndroidJUnit4::class)
class ProductShortCutTest {

    @Rule
    @JvmField
    val activityRule = ActivityTestRule(CustomViewContainerActivity::class.java, true, false)

    private lateinit var productShortCut: ProductShortCut

    private val featureToggleMock: FeatureToggle = mockk()

    @get:Rule
    val koinTestRule = KoinTestRule()

    @Before
    fun setup() {
        loadKoinModules(module {
            single { featureToggleMock }
        })

        productShortCut = ProductShortCut(InstrumentationRegistry.getInstrumentation().targetContext)
        productShortCut.setViewWidth(100F)
    }

    @After
    fun onFinish() {
        activityRule.finishActivity()
    }

    @Test
    fun storiesActive_setStory_screenshotValidation() {
        // ARRANGE
        every { featureToggleMock.getValue(AB_CROSS_SELL_SHOW_NOTIFICATION) } returns false
        setupProductShortCut(icon = "&#xe9d1;", description = "Cartão de crédito", type = Type.SELECTED)

        // ACT
        attachCustomView()

        // ASSERT
        Screenshot.snap(productShortCut).record()
    }

    @Test
    fun storiesAvailable_setStory_screenshotValidation() {
        // ARRANGE
        every { featureToggleMock.getValue(AB_CROSS_SELL_SHOW_NOTIFICATION) } returns false
        setupProductShortCut(icon = "&#xe9e0;", description = "Auto móvel", type = Type.NOT_SELECTED)

        // ACT
        attachCustomView()

        // ASSERT
        Screenshot.snap(productShortCut).record()
    }

    @Test
    fun storiesNotRead_setStory_screenshotValidation() {
        // ARRANGE
        every { featureToggleMock.getValue(AB_CROSS_SELL_SHOW_NOTIFICATION) } returns false
        setupProductShortCut(icon = "&#xe95c;", description = "Residência extra", type = Type.NOT_READ)

        // ACT
        attachCustomView()

        // ASSERT
        Screenshot.snap(productShortCut).record()
    }

    @Test
    fun storiesNotRead_pinIsEnabled_redCircleShouldAppear() {
        // ARRANGE
        every { featureToggleMock.getValue(AB_CROSS_SELL_SHOW_NOTIFICATION) } returns true
        setupProductShortCut(icon = "&#xe95c;", description = "Residência extra", type = Type.NOT_READ)

        // ACT
        attachCustomView()

        // ASSERT
        Screenshot.snap(productShortCut).record()
    }

    @Test
    fun storiesRead_setStory_screenshotValidation() {
        // ARRANGE
        every { featureToggleMock.getValue(AB_CROSS_SELL_SHOW_NOTIFICATION) } returns false
        setupProductShortCut(icon = "&#xe969;", description = "Residência", type = Type.READ)

        // ACT
        attachCustomView()

        // ASSERT
        Screenshot.snap(productShortCut).record()
    }

    @Test
    fun storiesRead_pinIsEnabled_noRedCircleShouldAppear() {
        // ARRANGE
        every { featureToggleMock.getValue(AB_CROSS_SELL_SHOW_NOTIFICATION) } returns true
        setupProductShortCut(icon = "&#xe969;", description = "Residência", type = Type.READ)

        // ACT
        attachCustomView()

        // ASSERT
        Screenshot.snap(productShortCut).record()
    }

    private fun setupProductShortCut(icon: String, description: String, type: Type) {
        val story = Story(icon = icon, text = description, type = type)
        productShortCut.setup(story)
    }

    private fun attachCustomView(width: Int = DEFAULT_WIDTH, height: Int = DEFAULT_HEIGHT) {
        activityRule.launchActivity(null)
        activityRule.activity.addCustomView(productShortCut, width, height)
        InstrumentationRegistry.getInstrumentation().waitForIdleSync()
    }

    companion object {
        private const val DEFAULT_WIDTH = 300
        private const val DEFAULT_HEIGHT = 300
        private const val AB_CROSS_SELL_SHOW_NOTIFICATION = "ab_cross_sell_show_notification"
    }
}