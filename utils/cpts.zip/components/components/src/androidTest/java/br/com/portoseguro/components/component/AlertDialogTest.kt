package br.com.portoseguro.components.component

import androidx.arch.core.executor.testing.InstantTaskExecutorRule
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import androidx.test.rule.ActivityTestRule
import br.com.portoseguro.components.CustomViewContainerActivity
import br.com.portoseguro.components.alertdialog.AlertDialog
import br.com.portoseguro.components.alertdialog.AlertDialogData
import br.com.portoseguro.components.infrastructure.KoinTestRule
import br.com.portoseguro.components.robot.alertDialogRobot
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TestRule
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class AlertDialogTest {

    @Rule
    @JvmField
    val activityRule = ActivityTestRule(CustomViewContainerActivity::class.java, true, false)

    @Rule
    @JvmField
    val rule: TestRule = InstantTaskExecutorRule()

    @get:Rule
    val koinTestRule = KoinTestRule()

    private lateinit var alertDialog: AlertDialog

    @Before
    fun setup() {
        activityRule.launchActivity(null)
    }

    @After
    fun tearDown() {
        activityRule.finishActivity()
    }

    @Test
    fun onAlertDialog_whenTouchOnFirstButton_shouldCloseAlertDialog() {
        // ARRANGE
        val alertData = buildAlertData()

        // ACT
        showAlertDialog(alertData)
        InstrumentationRegistry.getInstrumentation().waitForIdleSync()
        alertDialogRobot { clickOnFirstButton() }

        // ASSERT
        assertEquals(alertDialog.isShowing, false)
    }

    @Test
    fun onAlertDialog_whenTouchOnSecondButton_shouldCloseAlertDialog() {
        // ARRANGE
        val alertData = buildAlertData()

        // ACT
        showAlertDialog(alertData)
        InstrumentationRegistry.getInstrumentation().waitForIdleSync()
        alertDialogRobot { clickOnSecondButton() }

        // ASSERT
        assertEquals(alertDialog.isShowing, false)
    }

    private fun showAlertDialog(alertData: AlertDialogData) {
        activityRule.activity.runOnUiThread {
            alertDialog = AlertDialog(activityRule.activity, alertData)
            alertDialog.show()
        }
    }

    private fun buildAlertData(): AlertDialogData {
        return AlertDialogData(
            text = "Este canal é exclusivo para atualizar seu cadastro. Deseja continuar?",
            textBold = "Deseja continuar?",
            firstButtonText = "Sim, continuar",
            secondButtonText = "Não, cancelar"
        )
    }
}
