package br.com.portoseguro.components.snapshot

import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import androidx.test.rule.ActivityTestRule
import br.com.portoseguro.components.CustomViewContainerActivity
import br.com.portoseguro.components.comingsoonview.ComingSoonView
import br.com.portoseguro.components.error.ErrorInformation
import br.com.portoseguro.components.error.ErrorViewType
import br.com.portoseguro.components.infrastructure.KoinTestRule
import br.com.portoseguro.components.labelmessage.LabelMessage
import br.com.portoseguro.components.labelmessage.LabelMessageType
import br.com.portoseguro.components.utils.ComponentsUtils
import com.facebook.testing.screenshot.Screenshot
import org.junit.After
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class ComingSoonViewTest {

    @Rule
    @JvmField
    val activityRule = ActivityTestRule(CustomViewContainerActivity::class.java, true, false)

    private lateinit var comingSoonView: ComingSoonView

    @get:Rule
    val koinTestRule = KoinTestRule()

    @Before
    fun setup() {
        activityRule.launchActivity(null)
        val context = activityRule.activity.application
        comingSoonView = ComingSoonView(context)
    }

    @After
    fun onFinish() {
        activityRule.finishActivity()
    }

    @Test
    fun comingSoonView_screenValidation() {
        // ARRANGE
        setupComingSoonView()

        // ACT
        activityRule.activity.addCustomView(comingSoonView)
        InstrumentationRegistry.getInstrumentation().waitForIdleSync()

        // ASSERT
        Screenshot.snap(comingSoonView).record()
    }

    private fun setupComingSoonView() {
        val errorInformation = ErrorInformation(ErrorViewType.VIEW_WITHOUT_TRY_AGAIN, ERROR_MESSAGE)
        val labelMessage = LabelMessage(LabelMessageType.INFORMATION, "&#xe906;", "", LABEL_MESSAGE)
        comingSoonView.setIcon(ComponentsUtils.setFontIcon("&#xe9d2;").toString())
        comingSoonView.setTitle(TITLE)
        comingSoonView.setErrorView(errorInformation)
        comingSoonView.setLabelMessageView(labelMessage)
    }

    companion object {
        private const val ERROR_MESSAGE = "Caso tenha contratado recentemente seu seguro, aguarde até 72h para que você possa acessá-lo."
        private const val LABEL_MESSAGE = "Em breve teremos novidades e mais serviços Porto Seguro liberados por aqui."
        private const val TITLE = "Fique tranquilo! Estamos carregando os dados do seu seguro."
    }
}