package br.com.portoseguro.components.robot

import androidx.test.espresso.Espresso.onView
import androidx.test.espresso.action.ViewActions.swipeLeft
import androidx.test.espresso.matcher.ViewMatchers.withId
import br.com.portoseguro.components.R
import br.com.portoseguro.components.infrastructure.ViewActionUtils

class TutorialRobot {

    fun takeHomeBottomSheetScreenshot(fileName: String) {
        onView(withId(R.id.tutorial_fragment_container))
            .perform(ViewActionUtils.takeScreenshot(fileName))
    }

    fun swipeToNextStep(times: Int) {
        for (i in 1..times) {
            onView(withId(R.id.view_pager)).perform(swipeLeft(), ViewActionUtils.waitFor())
        }
    }
}