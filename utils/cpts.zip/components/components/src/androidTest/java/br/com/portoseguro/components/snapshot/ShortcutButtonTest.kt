package br.com.portoseguro.components.snapshot

import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import androidx.test.rule.ActivityTestRule
import br.com.portoseguro.components.CustomViewContainerActivity
import br.com.portoseguro.components.infrastructure.KoinTestRule
import br.com.portoseguro.components.shortcut.Shortcut
import br.com.portoseguro.components.shortcut.ShortcutButton
import br.com.portoseguro.components.shortcut.ShortcutButtonType
import com.facebook.testing.screenshot.Screenshot
import org.junit.After
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class ShortcutButtonTest {

    @Rule
    @JvmField
    val activityRule = ActivityTestRule(CustomViewContainerActivity::class.java, true, false)

    private lateinit var shortcutButton: ShortcutButton

    @get:Rule
    val koinTestRule = KoinTestRule()

    @Before
    fun setup() {
        shortcutButton = ShortcutButton(InstrumentationRegistry.getInstrumentation().targetContext)
    }

    @After
    fun onFinish() {
        activityRule.finishActivity()
    }

    @Test
    fun shortcutButton_setShortcutType_screenshotValidation() {
        // ARRANGE
        setupShortcutButton(icon = "&#xea01;", description = "Ver Fatura", type = ShortcutButtonType.SHORTCUT)

        // ACT
        attachCustomView()

        // ASSERT
        Screenshot.snap(shortcutButton).record()
    }

    @Test
    fun shortcutButton_setShortcutIn_screenshotValidation() {
        // ARRANGE
        setupShortcutButton(icon = "&#xe903;", description = "Mais", type = ShortcutButtonType.IN)

        // ACT
        attachCustomView()

        // ASSERT
        Screenshot.snap(shortcutButton).record()
    }

    @Test
    fun shortcutButton_setShortcutComingSoon_screenshotValidation() {
        // ARRANGE
        setupShortcutButton(icon = "&#xe91d;", description = "Em breve", type = ShortcutButtonType.COMING_SOON)

        // ACT
        attachCustomView()

        // ASSERT
        Screenshot.snap(shortcutButton).record()
    }

    private fun setupShortcutButton(icon: String, description: String, type: ShortcutButtonType) {
        val shortcut = Shortcut(icon = icon, description = description, type = type)
        shortcutButton.setShortcut(shortcut)
    }

    private fun attachCustomView() {
        activityRule.launchActivity(null)
        activityRule.activity.addCustomView(shortcutButton, DEFAULT_WIDTH, DEFAULT_HEIGHT)
        InstrumentationRegistry.getInstrumentation().waitForIdleSync()
    }

    companion object {
        private const val DEFAULT_WIDTH = 300
        private const val DEFAULT_HEIGHT = 300
    }
}