package br.com.portoseguro.components.snapshot

import androidx.arch.core.executor.testing.InstantTaskExecutorRule
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import androidx.test.rule.ActivityTestRule
import br.com.portoseguro.components.CustomViewContainerActivity
import br.com.portoseguro.components.R
import br.com.portoseguro.components.feedbackbottomsheet.FeedbackBottomSheetFragment
import com.facebook.testing.screenshot.Screenshot
import org.junit.After
import org.junit.Before
import org.junit.Ignore
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TestRule
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class FeedbackBottomSheetFragmentTest {

    @Rule
    @JvmField
    val activityRule = ActivityTestRule(CustomViewContainerActivity::class.java, true, false)

    @Rule
    @JvmField
    var rule: TestRule = InstantTaskExecutorRule()

    @Before
    fun setup() {
        activityRule.launchActivity(null)
    }

    @After
    fun onFinish() {
        activityRule.finishActivity()
    }

    @Test
    @Ignore("ignorado para análise posterior")
    fun onLoadActivity_whenTouchFeedbackBottomSheet_shouldShowFeedbackBottomSheet() {
        // ACT
        val fragment = FeedbackBottomSheetFragment
            .newInstance(
                R.raw.plane_animation,"Título de teste","Descrição de teste" +
                    " Descrição de teste Descrição de teste Descrição de " +
                    "teste Descrição de teste Descrição de teste", null)
        fragment.show(activityRule.activity.supportFragmentManager, "feedbakc_bottomsheet")

        InstrumentationRegistry.getInstrumentation().waitForIdleSync()

        // ASSERT
        Screenshot.snap(fragment.view).record()
    }
}