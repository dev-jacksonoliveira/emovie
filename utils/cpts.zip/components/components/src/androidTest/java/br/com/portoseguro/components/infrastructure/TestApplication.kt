package br.com.portoseguro.components.infrastructure

import android.app.Application
import br.com.portoseguro.components.R

class TestApplication : Application() {

    override fun onCreate() {
        super.onCreate()
        setTheme(R.style.AppTheme)
    }
}
