package br.com.portoseguro.components.snapshot

import androidx.arch.core.executor.testing.InstantTaskExecutorRule
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import androidx.test.rule.ActivityTestRule
import br.com.portoseguro.components.CustomViewContainerActivity
import br.com.portoseguro.components.alertdialog.AlertDialog
import br.com.portoseguro.components.alertdialog.AlertDialogData
import br.com.portoseguro.components.robot.alertDialogRobot
import org.junit.After
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TestRule
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class AlertDialogTest {

    @Rule
    @JvmField
    val activityRule = ActivityTestRule(CustomViewContainerActivity::class.java, true, false)

    @Rule
    @JvmField
    var rule: TestRule = InstantTaskExecutorRule()

    @Before
    fun setup() {
        activityRule.launchActivity(null)
    }

    @After
    fun onFinish() {
        activityRule.finishActivity()
    }

    @Test
    fun onLoadActivity_whenTouchOnAlertDialog_shouldShowAlertDialog() {
        // ARRANGE
        val alertData = buildAlertData()

        // ACT
        showAlertDialog(alertData)
        InstrumentationRegistry.getInstrumentation().waitForIdleSync()

        // ASSERT
        alertDialogRobot { takeScreenShotLogoutDialog() }
    }

    private fun showAlertDialog(alertData: AlertDialogData) {
        activityRule.activity.runOnUiThread {
            val alert = AlertDialog(activityRule.activity, alertData)
            alert.show()
        }
    }

    private fun buildAlertData(): AlertDialogData {
        return AlertDialogData(
            text = "Este canal é exclusivo para atualizar seu cadastro. Deseja continuar?",
            textBold = "Deseja continuar?",
            firstButtonText = "Sim, continuar",
            secondButtonText = "Não, cancelar"
        )
    }
}