package br.com.portoseguro.components.snapshot

import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.internal.runner.junit4.statement.UiThreadStatement.runOnUiThread
import androidx.test.platform.app.InstrumentationRegistry
import androidx.test.rule.ActivityTestRule
import br.com.portoseguro.components.CustomViewContainerActivity
import br.com.portoseguro.components.R
import br.com.portoseguro.components.expandablecard.ExpandableCardView
import br.com.portoseguro.components.expandablecard.HeaderExpandableCardView
import br.com.portoseguro.components.infrastructure.KoinTestRule
import br.com.portoseguro.superapp.core.toggle.FeatureToggle
import com.facebook.testing.screenshot.Screenshot
import io.mockk.mockk
import org.junit.After
import org.junit.Before
import org.junit.Ignore
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.koin.core.context.loadKoinModules
import org.koin.dsl.module

@RunWith(AndroidJUnit4::class)
class ExpandableCardViewTest {

    @Rule
    @JvmField
    val activityRule = ActivityTestRule(CustomViewContainerActivity::class.java, true, false)

    @get:Rule
    val koinTestRule = KoinTestRule()

    private lateinit var expandableCardView: ExpandableCardView

    @Before
    fun setup() {
        setupKoin()
        activityRule.launchActivity(null)

        runOnUiThread { expandableCardView = ExpandableCardView(activityRule.activity) }
        InstrumentationRegistry.getInstrumentation().waitForIdleSync()
    }

    @After
    fun onFinish() {
        activityRule.finishActivity()
    }

    @Ignore("Teste com screenshot quebrando")
    @Test
    fun expandableCardView_expandCollapseCardClick_validation() {
        // ARRANGE
        val header = HeaderExpandableCardView(
            brandImage = R.drawable.ic_visa,
            title = "International 1234 12•• •••• 1234",
            description = "Titular | João",
            isExpanded = true
        )
        expandableCardView.setViewExpanded(R.layout.item_card_content)
        expandableCardView.setViewHeader(header)

        // ACT
        attachCustomView()

        // ASSERT
        Screenshot.snap(expandableCardView).record()
    }

    @Test
    fun expandableCardView_oneCardCollapsed_screenshotValidation() {
        // ARRANGE
        val header = HeaderExpandableCardView(
            brandImage = R.drawable.ic_visa,
            title = "International 1234 12•• •••• 1234",
            description = "Titular | João"
        )
        expandableCardView.setViewHeader(header)

        // ACT
        attachCustomView()

        // ASSERT
        Screenshot.snap(expandableCardView).record()
    }

    @Test
    fun expandableCardView_oneCardCollapsedWithLongDescription_screenshotValidation() {
        // ARRANGE
        val header = HeaderExpandableCardView(
            brandImage = R.drawable.ic_visa,
            title = "Platinum Internacional 2.0 International",
            description = "Titular | João"
        )
        expandableCardView.setViewHeader(header)

        // ACT
        attachCustomView()

        // ASSERT
        Screenshot.snap(expandableCardView).record()
    }

    private fun setupKoin() {
        loadKoinModules(module { single { mockk<FeatureToggle>(relaxed = true) } })
    }

    private fun attachCustomView() {
        activityRule.activity.addCustomView(expandableCardView)
        InstrumentationRegistry.getInstrumentation().waitForIdleSync()
    }
}