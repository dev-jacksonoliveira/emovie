package br.com.portoseguro.components.robot

import android.view.View
import androidx.test.espresso.Espresso.onView
import androidx.test.espresso.action.ViewActions.click
import androidx.test.espresso.action.ViewActions.closeSoftKeyboard
import androidx.test.espresso.action.ViewActions.replaceText
import androidx.test.espresso.matcher.ViewMatchers.isDescendantOfA
import androidx.test.espresso.matcher.ViewMatchers.isDisplayed
import androidx.test.espresso.matcher.ViewMatchers.withId
import br.com.portoseguro.components.R
import br.com.portoseguro.components.infrastructure.BaseRobot
import org.hamcrest.Description
import org.hamcrest.Matcher
import org.hamcrest.Matchers.allOf
import org.hamcrest.TypeSafeMatcher

fun formRobot(func: FormActivityRobot.() -> Unit) = FormActivityRobot().apply { func() }

class FormActivityRobot : BaseRobot() {

    fun fillTextField(value: String) {
        val textField = onView(
            allOf(
                withId(R.id.edit_text),
                isDescendantOfA(withId(R.id.form_text_field)),
                isDisplayed()
            )
        )
            .perform(click())

        textField.perform(replaceText(value))
        closeKeyboard()
    }

    private fun closeKeyboard() {
        onView(
            allOf(
                withId(R.id.edit_text),
                isDescendantOfA(withId(R.id.form_text_field)),
                isDisplayed()
            )
        ).perform(closeSoftKeyboard())
    }

    fun clickContinueButton() {
        onView(withId(R.id.form_continue_button)).perform(click())
    }

    fun selectOption(index: Int) {
        onView(withIndex(withId(R.id.radio_button_item), index)).perform(click())
    }

    private fun withIndex(matcher: Matcher<View?>, index: Int): Matcher<View?>? {
        return object : TypeSafeMatcher<View?>() {
            var currentIndex = 0
            override fun describeTo(description: Description) {
                description.appendText("with index: ")
                description.appendValue(index)
                matcher.describeTo(description)
            }

            override fun matchesSafely(view: View?): Boolean {
                return matcher.matches(view) && currentIndex++ == index
            }
        }
    }
}