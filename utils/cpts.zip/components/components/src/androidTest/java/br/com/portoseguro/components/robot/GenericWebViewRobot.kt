package br.com.portoseguro.components.robot

import androidx.test.espresso.Espresso.onView
import androidx.test.espresso.action.ViewActions
import androidx.test.espresso.assertion.ViewAssertions.matches
import androidx.test.espresso.matcher.ViewMatchers.isDisplayed
import androidx.test.espresso.matcher.ViewMatchers.withId
import br.com.portoseguro.components.R
import br.com.portoseguro.components.infrastructure.BaseRobot

fun genericWebViewRobot(func: GenericWebViewRobot.() -> Unit) = GenericWebViewRobot().apply(func)

class GenericWebViewRobot: BaseRobot() {
    fun clickOnReturn(){
        onView(withId(R.id.back_button)).perform(forceClick())
    }

    fun isVisibleAlert(){
        onView(withId(R.id.logout_dialog_container)).check(matches(isDisplayed()))
    }

    fun clickOnAlertYes(){
        onView(withId(R.id.logout_alert_dialog_first_button)).perform(ViewActions.click())
    }

    fun clickOnAlertNo(){
        onView(withId(R.id.logout_alert_dialog_second_button)).perform(ViewActions.click())
    }
}