package br.com.portoseguro.components.snapshot

import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import androidx.test.rule.ActivityTestRule
import br.com.portoseguro.components.CustomViewContainerActivity
import br.com.portoseguro.components.infrastructure.KoinTestRule
import br.com.portoseguro.components.phones.PhoneView
import com.facebook.testing.screenshot.Screenshot
import org.junit.After
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class PhoneViewTest {

    @Rule
    @JvmField
    val activityRule = ActivityTestRule(CustomViewContainerActivity::class.java, true, false)

    private lateinit var phoneView: PhoneView

    @get:Rule
    val koinTestRule = KoinTestRule()

    @Before
    fun setup() {
        val context = InstrumentationRegistry.getInstrumentation().targetContext
        phoneView = PhoneView(context)
    }

    @After
    fun onFinish() {
        activityRule.finishActivity()
    }

    @Test
    fun phoneView_screenValidation() {
        // ACT
        activityRule.launchActivity(null)
        activityRule.activity.addCustomView(phoneView)
        InstrumentationRegistry.getInstrumentation().waitForIdleSync()

        // ASSERT
        Screenshot.snap(phoneView).record()
    }
}