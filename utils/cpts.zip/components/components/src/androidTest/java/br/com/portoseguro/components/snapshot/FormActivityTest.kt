package br.com.portoseguro.components.snapshot

import android.app.Activity
import android.content.Context
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import androidx.test.rule.ActivityTestRule
import br.com.portoseguro.components.form.FormActivity
import br.com.portoseguro.components.form.data.FormAnalyticsModel
import br.com.portoseguro.components.form.data.FormBirthDateModel
import br.com.portoseguro.components.form.data.FormCPFModel
import br.com.portoseguro.components.form.data.FormModel
import br.com.portoseguro.components.form.data.FormOptionsModel
import br.com.portoseguro.components.form.data.FormParameters
import br.com.portoseguro.components.form.data.FormTextModel
import br.com.portoseguro.components.form.viewmodel.FormViewModel
import br.com.portoseguro.components.infrastructure.KoinTestRule
import br.com.portoseguro.components.infrastructure.recordActivity
import br.com.portoseguro.components.robot.FormActivityRobot
import br.com.portoseguro.superapp.core.analytics.Analytics
import br.com.portoseguro.superapp.core.log.Log
import com.facebook.testing.screenshot.Screenshot
import io.mockk.mockk
import org.junit.After
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.koin.androidx.viewmodel.dsl.viewModel
import org.koin.core.context.loadKoinModules
import org.koin.dsl.module
import org.koin.test.KoinTest

@RunWith(AndroidJUnit4::class)
class FormActivityTest : KoinTest {

    @Rule
    @JvmField
    val activityRule = ActivityTestRule(FormActivity::class.java, true, false)

    @get:Rule
    val koinTestRule = KoinTestRule()

    private val robot = FormActivityRobot()

    private val analytics: Analytics = mockk(relaxed = true)
    private val log: Log = mockk(relaxed = true)

    private val context: Context = InstrumentationRegistry.getInstrumentation().targetContext


    @Before
    fun setup() {

        val testModule = module {
            single { analytics }
            single { log }
            viewModel { FormViewModel(get()) }
        }

        loadKoinModules(testModule)
    }

    @Test
    fun formActivity_CPFStepSuccessValidation_firstStepValidation() {
        // ARRANGE
        val model = getFormParameters()

        // ACT
        val activity = launchActivity(model)

        robot.fillTextField(USER_CPF)

        // ASSERT
        activity.recordActivity("formActivity_CPFStepSuccessValidation_firstStepValidation")
    }

    @Test
    fun formActivity_TextStepSuccessValidation_firstStepValidation() {
        // ARRANGE
        val model = getFormParameters()

        // ACT
        val activity = launchActivity(model)

        robot.apply {
            fillTextField(USER_CPF)
            clickContinueButton()
            fillTextField(USER_NAME)
        }

        // ASSERT
        activity.recordActivity("formActivity_TextStepSuccessValidation_firstStepValidation")
    }

    @Test
    fun formActivity_TextStepFailValidation_firstStepValidation() {
        // ARRANGE
        val model = getFormParameters()

        // ACT
        val activity = launchActivity(model)

        robot.apply {
            fillTextField(USER_CPF)
            clickContinueButton()
            fillTextField(USER_INVALID_NAME)
        }

        // ASSERT
        activity.recordActivity("formActivity_TextStepFailValidation_firstStepValidation")
    }

    @Test
    fun formActivity_OptionStepSuccessValidation_firstStepValidation() {
        // ARRANGE
        val model = getFormParameters()

        // ACT
        val activity = launchActivity(model)

        robot.apply {
            fillTextField(USER_CPF)
            clickContinueButton()
            fillTextField(USER_NAME)
            clickContinueButton()
            selectOption(0)
        }

        // ASSERT
        activity.recordActivity("formActivity_OptionStepSuccessValidation_firstStepValidation")
    }

    @Test
    fun formActivity_withLessThen12Years_firstStepValidation() {
        // ARRANGE
        val model = getFormParameters()

        // ACT
        val activity = launchActivity(model)

        robot.apply {
            fillTextField(USER_CPF)
            clickContinueButton()
            fillTextField(USER_NAME)
            clickContinueButton()
            selectOption(0)
            clickContinueButton()
            fillTextField(LESS_TWELVE_YEARS)
        }

        // ASSERT
        activity.recordActivity("formActivity_withLessThen12Years_firstStepValidation")
    }

    @Test
    fun formActivity_OptionStepEmptyValidation_firstStepValidation() {
        // ARRANGE
        val model = getFormParameters()

        // ACT
        val activity = launchActivity(model)

        robot.apply {
            fillTextField(USER_CPF)
            clickContinueButton()
            fillTextField(USER_NAME)
            clickContinueButton()
        }

        // ASSERT
        activity.recordActivity("formActivity_OptionStepEmptyValidation_firstStepValidation")
    }

    @After
    fun tearDown() {
        activityRule.finishActivity()
    }

    private fun launchActivity(formModel: FormParameters): Activity {
        val intent = FormActivity.getLaunchIntent(context, formModel) { _, _ ->
            // do nothing
        }
        return activityRule.launchActivity(intent)
    }

    private fun getFormParameters(): FormParameters =
        FormParameters(
            "Form Title",
            FormAnalyticsModel(
                "analytics_section",
                listOf("analytics_sub_section_01", "analytics_sub_section_02"),
                "analytics_product"
            ),
            getModelList()
        )

    private fun getModelList(): List<FormModel> =
        listOf(
            FormCPFModel(
                "CPF Model Question",
                "question_01",
                listOf("CPF Model Error"),
                listOf("CPF Model Description")
            ),
            FormTextModel(
                "Form Model Question",
                "question_02",
                listOf("Form Model Error"),
                listOf("Form Model Description", "Form Model Description 02"),
                "^[A-Z][A-z]+\\s([A-z]\\s?)*[A-Z][A-z]+\$",
                charLimit = 19
            ),
            FormOptionsModel(
                "CheckBox Model",
                "question_02",
                listOf("checkbox option 01", "checkbox option 02", "check box option 04", "check box option 05")
            ),
            FormBirthDateModel(
                "Form Birth Data Question",
                "question_03",
                listOf("Form Model Error"),
                listOf("Form Model Description", "Form Model Description 02"),
                minAgeErrorMessage = "min age error",
                minAge = 12
            )
        )

    companion object {
        private const val LESS_TWELVE_YEARS = "19/09/2012"
        private const val USER_NAME = "Jhon Due"
        private const val USER_INVALID_NAME = "Jhon Duã"
        private const val USER_CPF = "57780349039"
    }
}