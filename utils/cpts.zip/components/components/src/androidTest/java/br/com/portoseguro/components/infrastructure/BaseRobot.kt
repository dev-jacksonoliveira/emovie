package br.com.portoseguro.components.infrastructure

import android.view.View
import androidx.test.espresso.Espresso.onView
import androidx.test.espresso.UiController
import androidx.test.espresso.ViewAction
import androidx.test.espresso.matcher.ViewMatchers.withId
import androidx.test.espresso.matcher.ViewMatchers.isClickable
import androidx.test.espresso.matcher.ViewMatchers.isEnabled
import androidx.test.espresso.matcher.ViewMatchers.isDisplayed
import androidx.test.espresso.matcher.ViewMatchers.isAssignableFrom
import com.facebook.testing.screenshot.Screenshot
import org.hamcrest.CoreMatchers
import org.hamcrest.Matcher

open class BaseRobot {

    protected fun takeLayoutScreenshot(layout: Int, fileName: String) {
        onView(withId(layout)).perform(takeScreenshotWithName(fileName))
    }

    protected fun forceClick(): ViewAction {
        return object : ViewAction {
            override fun getConstraints(): Matcher<View> {
                return CoreMatchers.allOf(isClickable(), isEnabled(), isDisplayed())
            }

            override fun getDescription(): String {
                return "force click"
            }

            override fun perform(uiController: UiController, view: View) {
                view.performClick() // perform click without checking view coordinates.
                uiController.loopMainThreadUntilIdle()
            }
        }
    }

    private fun takeScreenshotWithName(filename: String): ViewAction {
        return object : ViewAction {
            override fun getDescription(): String {
                return "tira o screenshot da view : $filename"
            }

            override fun getConstraints(): Matcher<View> {
                return CoreMatchers.allOf(isAssignableFrom(View::class.java), isDisplayed())
            }

            override fun perform(uiController: UiController, view: View) {
                view.recordView(filename)
            }
        }
    }

    private fun View.recordView(fileName: String) {
        Screenshot.snap(this).setName(fileName).record()
    }
}